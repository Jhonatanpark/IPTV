package a.a.a;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import java.util.List;

public interface b extends IInterface {
   Bundle extraCommand(String var1, Bundle var2);

   boolean mayLaunchUrl(a.a.a.a var1, Uri var2, Bundle var3, List var4);

   boolean newSession(a.a.a.a var1);

   int postMessage(a.a.a.a var1, String var2, Bundle var3);

   boolean requestPostMessageChannel(a.a.a.a var1, Uri var2);

   boolean updateVisuals(a.a.a.a var1, Bundle var2);

   boolean validateRelationship(a.a.a.a var1, int var2, Uri var3, Bundle var4);

   boolean warmup(long var1);

   public abstract static class a extends Binder implements b {
      private static final String DESCRIPTOR = "android.support.customtabs.ICustomTabsService";
      static final int TRANSACTION_extraCommand = 5;
      static final int TRANSACTION_mayLaunchUrl = 4;
      static final int TRANSACTION_newSession = 3;
      static final int TRANSACTION_postMessage = 8;
      static final int TRANSACTION_requestPostMessageChannel = 7;
      static final int TRANSACTION_updateVisuals = 6;
      static final int TRANSACTION_validateRelationship = 9;
      static final int TRANSACTION_warmup = 2;

      public a() {
         this.attachInterface(this, "android.support.customtabs.ICustomTabsService");
      }

      public static b asInterface(IBinder var0) {
         if (var0 == null) {
            return null;
         } else {
            IInterface var1 = var0.queryLocalInterface("android.support.customtabs.ICustomTabsService");
            return (b)(var1 != null && var1 instanceof b ? (b)var1 : new b.a.a(var0));
         }
      }

      public IBinder asBinder() {
         return this;
      }

      public boolean onTransact(int var1, Parcel var2, Parcel var3, int var4) {
         if (var1 != 1598968902) {
            switch(var1) {
            case 2:
               var2.enforceInterface("android.support.customtabs.ICustomTabsService");
               byte var5 = this.warmup(var2.readLong());
               var3.writeNoException();
               var3.writeInt(var5);
               return true;
            case 3:
               var2.enforceInterface("android.support.customtabs.ICustomTabsService");
               byte var6 = this.newSession(a.a.a.a.a.asInterface(var2.readStrongBinder()));
               var3.writeNoException();
               var3.writeInt(var6);
               return true;
            case 4:
               var2.enforceInterface("android.support.customtabs.ICustomTabsService");
               a.a.a.a var7 = a.a.a.a.a.asInterface(var2.readStrongBinder());
               Uri var8;
               if (var2.readInt() != 0) {
                  var8 = (Uri)Uri.CREATOR.createFromParcel(var2);
               } else {
                  var8 = null;
               }

               int var9 = var2.readInt();
               Bundle var10 = null;
               if (var9 != 0) {
                  var10 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
               }

               byte var11 = this.mayLaunchUrl(var7, var8, var10, var2.createTypedArrayList(Bundle.CREATOR));
               var3.writeNoException();
               var3.writeInt(var11);
               return true;
            case 5:
               var2.enforceInterface("android.support.customtabs.ICustomTabsService");
               String var12 = var2.readString();
               int var13 = var2.readInt();
               Bundle var14 = null;
               if (var13 != 0) {
                  var14 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
               }

               Bundle var15 = this.extraCommand(var12, var14);
               var3.writeNoException();
               if (var15 != null) {
                  var3.writeInt(1);
                  var15.writeToParcel(var3, 1);
                  return true;
               }

               var3.writeInt(0);
               return true;
            case 6:
               var2.enforceInterface("android.support.customtabs.ICustomTabsService");
               a.a.a.a var16 = a.a.a.a.a.asInterface(var2.readStrongBinder());
               int var17 = var2.readInt();
               Bundle var18 = null;
               if (var17 != 0) {
                  var18 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
               }

               byte var19 = this.updateVisuals(var16, var18);
               var3.writeNoException();
               var3.writeInt(var19);
               return true;
            case 7:
               var2.enforceInterface("android.support.customtabs.ICustomTabsService");
               a.a.a.a var20 = a.a.a.a.a.asInterface(var2.readStrongBinder());
               int var21 = var2.readInt();
               Uri var22 = null;
               if (var21 != 0) {
                  var22 = (Uri)Uri.CREATOR.createFromParcel(var2);
               }

               byte var23 = this.requestPostMessageChannel(var20, var22);
               var3.writeNoException();
               var3.writeInt(var23);
               return true;
            case 8:
               var2.enforceInterface("android.support.customtabs.ICustomTabsService");
               a.a.a.a var24 = a.a.a.a.a.asInterface(var2.readStrongBinder());
               String var25 = var2.readString();
               int var26 = var2.readInt();
               Bundle var27 = null;
               if (var26 != 0) {
                  var27 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
               }

               int var28 = this.postMessage(var24, var25, var27);
               var3.writeNoException();
               var3.writeInt(var28);
               return true;
            case 9:
               var2.enforceInterface("android.support.customtabs.ICustomTabsService");
               a.a.a.a var29 = a.a.a.a.a.asInterface(var2.readStrongBinder());
               int var30 = var2.readInt();
               Uri var31;
               if (var2.readInt() != 0) {
                  var31 = (Uri)Uri.CREATOR.createFromParcel(var2);
               } else {
                  var31 = null;
               }

               int var32 = var2.readInt();
               Bundle var33 = null;
               if (var32 != 0) {
                  var33 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
               }

               byte var34 = this.validateRelationship(var29, var30, var31, var33);
               var3.writeNoException();
               var3.writeInt(var34);
               return true;
            default:
               return super.onTransact(var1, var2, var3, var4);
            }
         } else {
            var3.writeString("android.support.customtabs.ICustomTabsService");
            return true;
         }
      }

      private static class a implements b {
         private IBinder a;

         a(IBinder var1) {
            this.a = var1;
         }

         public IBinder asBinder() {
            return this.a;
         }

         public Bundle extraCommand(String var1, Bundle var2) {
            Parcel var3 = Parcel.obtain();
            Parcel var4 = Parcel.obtain();

            Bundle var7;
            label197: {
               Throwable var10000;
               label201: {
                  boolean var10001;
                  try {
                     var3.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
                     var3.writeString(var1);
                  } catch (Throwable var27) {
                     var10000 = var27;
                     var10001 = false;
                     break label201;
                  }

                  if (var2 != null) {
                     try {
                        var3.writeInt(1);
                        var2.writeToParcel(var3, 0);
                     } catch (Throwable var26) {
                        var10000 = var26;
                        var10001 = false;
                        break label201;
                     }
                  } else {
                     try {
                        var3.writeInt(0);
                     } catch (Throwable var25) {
                        var10000 = var25;
                        var10001 = false;
                        break label201;
                     }
                  }

                  try {
                     this.a.transact(5, var3, var4, 0);
                     var4.readException();
                     if (var4.readInt() != 0) {
                        var7 = (Bundle)Bundle.CREATOR.createFromParcel(var4);
                        break label197;
                     }
                  } catch (Throwable var24) {
                     var10000 = var24;
                     var10001 = false;
                     break label201;
                  }

                  var7 = null;
                  break label197;
               }

               Throwable var5 = var10000;
               var4.recycle();
               var3.recycle();
               throw var5;
            }

            var4.recycle();
            var3.recycle();
            return var7;
         }

         public boolean mayLaunchUrl(a.a.a.a var1, Uri var2, Bundle var3, List var4) {
            Parcel var5 = Parcel.obtain();
            Parcel var6 = Parcel.obtain();

            byte var9;
            int var11;
            label565: {
               Throwable var10000;
               label569: {
                  boolean var10001;
                  try {
                     var5.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
                  } catch (Throwable var83) {
                     var10000 = var83;
                     var10001 = false;
                     break label569;
                  }

                  IBinder var8;
                  if (var1 != null) {
                     try {
                        var8 = var1.asBinder();
                     } catch (Throwable var82) {
                        var10000 = var82;
                        var10001 = false;
                        break label569;
                     }
                  } else {
                     var8 = null;
                  }

                  try {
                     var5.writeStrongBinder(var8);
                  } catch (Throwable var81) {
                     var10000 = var81;
                     var10001 = false;
                     break label569;
                  }

                  var9 = 1;
                  if (var2 != null) {
                     try {
                        var5.writeInt(var9);
                        var2.writeToParcel(var5, 0);
                     } catch (Throwable var80) {
                        var10000 = var80;
                        var10001 = false;
                        break label569;
                     }
                  } else {
                     try {
                        var5.writeInt(0);
                     } catch (Throwable var79) {
                        var10000 = var79;
                        var10001 = false;
                        break label569;
                     }
                  }

                  if (var3 != null) {
                     try {
                        var5.writeInt(var9);
                        var3.writeToParcel(var5, 0);
                     } catch (Throwable var78) {
                        var10000 = var78;
                        var10001 = false;
                        break label569;
                     }
                  } else {
                     try {
                        var5.writeInt(0);
                     } catch (Throwable var77) {
                        var10000 = var77;
                        var10001 = false;
                        break label569;
                     }
                  }

                  label542:
                  try {
                     var5.writeTypedList(var4);
                     this.a.transact(4, var5, var6, 0);
                     var6.readException();
                     var11 = var6.readInt();
                     break label565;
                  } catch (Throwable var76) {
                     var10000 = var76;
                     var10001 = false;
                     break label542;
                  }
               }

               Throwable var7 = var10000;
               var6.recycle();
               var5.recycle();
               throw var7;
            }

            if (var11 == 0) {
               var9 = 0;
            }

            var6.recycle();
            var5.recycle();
            return (boolean)var9;
         }

         public boolean newSession(a.a.a.a var1) {
            Parcel var2 = Parcel.obtain();
            Parcel var3 = Parcel.obtain();
            boolean var9 = false;

            int var6;
            try {
               var9 = true;
               var2.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
               var2.writeStrongBinder(var1.asBinder());
               this.a.transact(3, var2, var3, 0);
               var3.readException();
               var6 = var3.readInt();
               var9 = false;
            } finally {
               if (var9) {
                  var3.recycle();
                  var2.recycle();
               }
            }

            boolean var7 = false;
            if (var6 != 0) {
               var7 = true;
            }

            var3.recycle();
            var2.recycle();
            return var7;
         }

         public int postMessage(a.a.a.a var1, String var2, Bundle var3) {
            Parcel var4 = Parcel.obtain();
            Parcel var5 = Parcel.obtain();

            int var9;
            label339: {
               Throwable var10000;
               label343: {
                  boolean var10001;
                  try {
                     var4.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
                  } catch (Throwable var51) {
                     var10000 = var51;
                     var10001 = false;
                     break label343;
                  }

                  IBinder var7;
                  if (var1 != null) {
                     try {
                        var7 = var1.asBinder();
                     } catch (Throwable var50) {
                        var10000 = var50;
                        var10001 = false;
                        break label343;
                     }
                  } else {
                     var7 = null;
                  }

                  try {
                     var4.writeStrongBinder(var7);
                     var4.writeString(var2);
                  } catch (Throwable var49) {
                     var10000 = var49;
                     var10001 = false;
                     break label343;
                  }

                  if (var3 != null) {
                     try {
                        var4.writeInt(1);
                        var3.writeToParcel(var4, 0);
                     } catch (Throwable var48) {
                        var10000 = var48;
                        var10001 = false;
                        break label343;
                     }
                  } else {
                     try {
                        var4.writeInt(0);
                     } catch (Throwable var47) {
                        var10000 = var47;
                        var10001 = false;
                        break label343;
                     }
                  }

                  label321:
                  try {
                     this.a.transact(8, var4, var5, 0);
                     var5.readException();
                     var9 = var5.readInt();
                     break label339;
                  } catch (Throwable var46) {
                     var10000 = var46;
                     var10001 = false;
                     break label321;
                  }
               }

               Throwable var6 = var10000;
               var5.recycle();
               var4.recycle();
               throw var6;
            }

            var5.recycle();
            var4.recycle();
            return var9;
         }

         public boolean requestPostMessageChannel(a.a.a.a var1, Uri var2) {
            Parcel var3 = Parcel.obtain();
            Parcel var4 = Parcel.obtain();

            byte var7;
            int var9;
            label368: {
               Throwable var10000;
               label372: {
                  boolean var10001;
                  try {
                     var3.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
                  } catch (Throwable var51) {
                     var10000 = var51;
                     var10001 = false;
                     break label372;
                  }

                  IBinder var6;
                  if (var1 != null) {
                     try {
                        var6 = var1.asBinder();
                     } catch (Throwable var50) {
                        var10000 = var50;
                        var10001 = false;
                        break label372;
                     }
                  } else {
                     var6 = null;
                  }

                  try {
                     var3.writeStrongBinder(var6);
                  } catch (Throwable var49) {
                     var10000 = var49;
                     var10001 = false;
                     break label372;
                  }

                  var7 = 1;
                  if (var2 != null) {
                     try {
                        var3.writeInt(var7);
                        var2.writeToParcel(var3, 0);
                     } catch (Throwable var48) {
                        var10000 = var48;
                        var10001 = false;
                        break label372;
                     }
                  } else {
                     try {
                        var3.writeInt(0);
                     } catch (Throwable var47) {
                        var10000 = var47;
                        var10001 = false;
                        break label372;
                     }
                  }

                  label350:
                  try {
                     this.a.transact(7, var3, var4, 0);
                     var4.readException();
                     var9 = var4.readInt();
                     break label368;
                  } catch (Throwable var46) {
                     var10000 = var46;
                     var10001 = false;
                     break label350;
                  }
               }

               Throwable var5 = var10000;
               var4.recycle();
               var3.recycle();
               throw var5;
            }

            if (var9 == 0) {
               var7 = 0;
            }

            var4.recycle();
            var3.recycle();
            return (boolean)var7;
         }

         public boolean updateVisuals(a.a.a.a var1, Bundle var2) {
            Parcel var3 = Parcel.obtain();
            Parcel var4 = Parcel.obtain();

            byte var7;
            int var9;
            label212: {
               Throwable var10000;
               label216: {
                  boolean var10001;
                  try {
                     var3.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
                  } catch (Throwable var29) {
                     var10000 = var29;
                     var10001 = false;
                     break label216;
                  }

                  IBinder var6;
                  if (var1 != null) {
                     try {
                        var6 = var1.asBinder();
                     } catch (Throwable var28) {
                        var10000 = var28;
                        var10001 = false;
                        break label216;
                     }
                  } else {
                     var6 = null;
                  }

                  try {
                     var3.writeStrongBinder(var6);
                  } catch (Throwable var27) {
                     var10000 = var27;
                     var10001 = false;
                     break label216;
                  }

                  var7 = 1;

                  label199:
                  try {
                     var3.writeInt(var7);
                     var2.writeToParcel(var3, 0);
                     this.a.transact(6, var3, var4, 0);
                     var4.readException();
                     var9 = var4.readInt();
                     break label212;
                  } catch (Throwable var26) {
                     var10000 = var26;
                     var10001 = false;
                     break label199;
                  }
               }

               Throwable var5 = var10000;
               var4.recycle();
               var3.recycle();
               throw var5;
            }

            if (var9 == 0) {
               var7 = 0;
            }

            var4.recycle();
            var3.recycle();
            return (boolean)var7;
         }

         public boolean validateRelationship(a.a.a.a var1, int var2, Uri var3, Bundle var4) {
            Parcel var5 = Parcel.obtain();
            Parcel var6 = Parcel.obtain();

            byte var9;
            int var11;
            label565: {
               Throwable var10000;
               label569: {
                  boolean var10001;
                  try {
                     var5.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
                  } catch (Throwable var83) {
                     var10000 = var83;
                     var10001 = false;
                     break label569;
                  }

                  IBinder var8;
                  if (var1 != null) {
                     try {
                        var8 = var1.asBinder();
                     } catch (Throwable var82) {
                        var10000 = var82;
                        var10001 = false;
                        break label569;
                     }
                  } else {
                     var8 = null;
                  }

                  try {
                     var5.writeStrongBinder(var8);
                     var5.writeInt(var2);
                  } catch (Throwable var81) {
                     var10000 = var81;
                     var10001 = false;
                     break label569;
                  }

                  var9 = 1;
                  if (var3 != null) {
                     try {
                        var5.writeInt(var9);
                        var3.writeToParcel(var5, 0);
                     } catch (Throwable var80) {
                        var10000 = var80;
                        var10001 = false;
                        break label569;
                     }
                  } else {
                     try {
                        var5.writeInt(0);
                     } catch (Throwable var79) {
                        var10000 = var79;
                        var10001 = false;
                        break label569;
                     }
                  }

                  if (var4 != null) {
                     try {
                        var5.writeInt(var9);
                        var4.writeToParcel(var5, 0);
                     } catch (Throwable var78) {
                        var10000 = var78;
                        var10001 = false;
                        break label569;
                     }
                  } else {
                     try {
                        var5.writeInt(0);
                     } catch (Throwable var77) {
                        var10000 = var77;
                        var10001 = false;
                        break label569;
                     }
                  }

                  label542:
                  try {
                     this.a.transact(9, var5, var6, 0);
                     var6.readException();
                     var11 = var6.readInt();
                     break label565;
                  } catch (Throwable var76) {
                     var10000 = var76;
                     var10001 = false;
                     break label542;
                  }
               }

               Throwable var7 = var10000;
               var6.recycle();
               var5.recycle();
               throw var7;
            }

            if (var11 == 0) {
               var9 = 0;
            }

            var6.recycle();
            var5.recycle();
            return (boolean)var9;
         }

         public boolean warmup(long var1) {
            Parcel var3 = Parcel.obtain();
            Parcel var4 = Parcel.obtain();
            boolean var10 = false;

            int var7;
            try {
               var10 = true;
               var3.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
               var3.writeLong(var1);
               this.a.transact(2, var3, var4, 0);
               var4.readException();
               var7 = var4.readInt();
               var10 = false;
            } finally {
               if (var10) {
                  var4.recycle();
                  var3.recycle();
               }
            }

            boolean var8 = false;
            if (var7 != 0) {
               var8 = true;
            }

            var4.recycle();
            var3.recycle();
            return var8;
         }
      }
   }
}
