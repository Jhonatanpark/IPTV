package a.a.a;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface c extends IInterface {
   void onMessageChannelReady(a.a.a.a var1, Bundle var2);

   void onPostMessage(a.a.a.a var1, String var2, Bundle var3);

   public abstract static class a extends Binder implements c {
      private static final String DESCRIPTOR = "android.support.customtabs.IPostMessageService";
      static final int TRANSACTION_onMessageChannelReady = 2;
      static final int TRANSACTION_onPostMessage = 3;

      public a() {
         this.attachInterface(this, "android.support.customtabs.IPostMessageService");
      }

      public static c asInterface(IBinder var0) {
         if (var0 == null) {
            return null;
         } else {
            IInterface var1 = var0.queryLocalInterface("android.support.customtabs.IPostMessageService");
            return (c)(var1 != null && var1 instanceof c ? (c)var1 : new c.a.a(var0));
         }
      }

      public IBinder asBinder() {
         return this;
      }

      public boolean onTransact(int var1, Parcel var2, Parcel var3, int var4) {
         if (var1 != 2) {
            if (var1 != 3) {
               if (var1 != 1598968902) {
                  return super.onTransact(var1, var2, var3, var4);
               }

               var3.writeString("android.support.customtabs.IPostMessageService");
               return true;
            }

            var2.enforceInterface("android.support.customtabs.IPostMessageService");
            a.a.a.a var8 = a.a.a.a.a.asInterface(var2.readStrongBinder());
            String var9 = var2.readString();
            int var10 = var2.readInt();
            Bundle var11 = null;
            if (var10 != 0) {
               var11 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            }

            this.onPostMessage(var8, var9, var11);
         } else {
            var2.enforceInterface("android.support.customtabs.IPostMessageService");
            a.a.a.a var5 = a.a.a.a.a.asInterface(var2.readStrongBinder());
            int var6 = var2.readInt();
            Bundle var7 = null;
            if (var6 != 0) {
               var7 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            }

            this.onMessageChannelReady(var5, var7);
         }

         var3.writeNoException();
         return true;
      }

      private static class a implements c {
         private IBinder a;

         a(IBinder var1) {
            this.a = var1;
         }

         public IBinder asBinder() {
            return this.a;
         }

         public void onMessageChannelReady(a.a.a.a var1, Bundle var2) {
            Parcel var3 = Parcel.obtain();
            Parcel var4 = Parcel.obtain();

            label339: {
               Throwable var10000;
               label343: {
                  boolean var10001;
                  try {
                     var3.writeInterfaceToken("android.support.customtabs.IPostMessageService");
                  } catch (Throwable var48) {
                     var10000 = var48;
                     var10001 = false;
                     break label343;
                  }

                  IBinder var6;
                  if (var1 != null) {
                     try {
                        var6 = var1.asBinder();
                     } catch (Throwable var47) {
                        var10000 = var47;
                        var10001 = false;
                        break label343;
                     }
                  } else {
                     var6 = null;
                  }

                  try {
                     var3.writeStrongBinder(var6);
                  } catch (Throwable var46) {
                     var10000 = var46;
                     var10001 = false;
                     break label343;
                  }

                  if (var2 != null) {
                     try {
                        var3.writeInt(1);
                        var2.writeToParcel(var3, 0);
                     } catch (Throwable var45) {
                        var10000 = var45;
                        var10001 = false;
                        break label343;
                     }
                  } else {
                     try {
                        var3.writeInt(0);
                     } catch (Throwable var44) {
                        var10000 = var44;
                        var10001 = false;
                        break label343;
                     }
                  }

                  label321:
                  try {
                     this.a.transact(2, var3, var4, 0);
                     var4.readException();
                     break label339;
                  } catch (Throwable var43) {
                     var10000 = var43;
                     var10001 = false;
                     break label321;
                  }
               }

               Throwable var5 = var10000;
               var4.recycle();
               var3.recycle();
               throw var5;
            }

            var4.recycle();
            var3.recycle();
         }

         public void onPostMessage(a.a.a.a var1, String var2, Bundle var3) {
            Parcel var4 = Parcel.obtain();
            Parcel var5 = Parcel.obtain();

            label339: {
               Throwable var10000;
               label343: {
                  boolean var10001;
                  try {
                     var4.writeInterfaceToken("android.support.customtabs.IPostMessageService");
                  } catch (Throwable var49) {
                     var10000 = var49;
                     var10001 = false;
                     break label343;
                  }

                  IBinder var7;
                  if (var1 != null) {
                     try {
                        var7 = var1.asBinder();
                     } catch (Throwable var48) {
                        var10000 = var48;
                        var10001 = false;
                        break label343;
                     }
                  } else {
                     var7 = null;
                  }

                  try {
                     var4.writeStrongBinder(var7);
                     var4.writeString(var2);
                  } catch (Throwable var47) {
                     var10000 = var47;
                     var10001 = false;
                     break label343;
                  }

                  if (var3 != null) {
                     try {
                        var4.writeInt(1);
                        var3.writeToParcel(var4, 0);
                     } catch (Throwable var46) {
                        var10000 = var46;
                        var10001 = false;
                        break label343;
                     }
                  } else {
                     try {
                        var4.writeInt(0);
                     } catch (Throwable var45) {
                        var10000 = var45;
                        var10001 = false;
                        break label343;
                     }
                  }

                  label321:
                  try {
                     this.a.transact(3, var4, var5, 0);
                     var5.readException();
                     break label339;
                  } catch (Throwable var44) {
                     var10000 = var44;
                     var10001 = false;
                     break label321;
                  }
               }

               Throwable var6 = var10000;
               var5.recycle();
               var4.recycle();
               throw var6;
            }

            var5.recycle();
            var4.recycle();
         }
      }
   }
}
