package a.a.a;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface a extends IInterface {
   void extraCallback(String var1, Bundle var2);

   void onMessageChannelReady(Bundle var1);

   void onNavigationEvent(int var1, Bundle var2);

   void onPostMessage(String var1, Bundle var2);

   void onRelationshipValidationResult(int var1, Uri var2, boolean var3, Bundle var4);

   public abstract static class a extends Binder implements a.a.a.a {
      private static final String DESCRIPTOR = "android.support.customtabs.ICustomTabsCallback";
      static final int TRANSACTION_extraCallback = 3;
      static final int TRANSACTION_onMessageChannelReady = 4;
      static final int TRANSACTION_onNavigationEvent = 2;
      static final int TRANSACTION_onPostMessage = 5;
      static final int TRANSACTION_onRelationshipValidationResult = 6;

      public a() {
         this.attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
      }

      public static a.a.a.a asInterface(IBinder var0) {
         if (var0 == null) {
            return null;
         } else {
            IInterface var1 = var0.queryLocalInterface("android.support.customtabs.ICustomTabsCallback");
            return (a.a.a.a)(var1 != null && var1 instanceof a.a.a.a ? (a.a.a.a)var1 : new a.a.a.a.a.a(var0));
         }
      }

      public IBinder asBinder() {
         return this;
      }

      public boolean onTransact(int var1, Parcel var2, Parcel var3, int var4) {
         if (var1 != 2) {
            if (var1 != 3) {
               if (var1 != 4) {
                  if (var1 != 5) {
                     if (var1 != 6) {
                        if (var1 != 1598968902) {
                           return super.onTransact(var1, var2, var3, var4);
                        }

                        var3.writeString("android.support.customtabs.ICustomTabsCallback");
                        return true;
                     }

                     var2.enforceInterface("android.support.customtabs.ICustomTabsCallback");
                     int var16 = var2.readInt();
                     Uri var17;
                     if (var2.readInt() != 0) {
                        var17 = (Uri)Uri.CREATOR.createFromParcel(var2);
                     } else {
                        var17 = null;
                     }

                     boolean var18;
                     if (var2.readInt() != 0) {
                        var18 = true;
                     } else {
                        var18 = false;
                     }

                     int var19 = var2.readInt();
                     Bundle var20 = null;
                     if (var19 != 0) {
                        var20 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
                     }

                     this.onRelationshipValidationResult(var16, var17, var18, var20);
                  } else {
                     var2.enforceInterface("android.support.customtabs.ICustomTabsCallback");
                     String var13 = var2.readString();
                     int var14 = var2.readInt();
                     Bundle var15 = null;
                     if (var14 != 0) {
                        var15 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
                     }

                     this.onPostMessage(var13, var15);
                  }
               } else {
                  var2.enforceInterface("android.support.customtabs.ICustomTabsCallback");
                  int var11 = var2.readInt();
                  Bundle var12 = null;
                  if (var11 != 0) {
                     var12 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
                  }

                  this.onMessageChannelReady(var12);
               }
            } else {
               var2.enforceInterface("android.support.customtabs.ICustomTabsCallback");
               String var8 = var2.readString();
               int var9 = var2.readInt();
               Bundle var10 = null;
               if (var9 != 0) {
                  var10 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
               }

               this.extraCallback(var8, var10);
            }
         } else {
            var2.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            int var5 = var2.readInt();
            int var6 = var2.readInt();
            Bundle var7 = null;
            if (var6 != 0) {
               var7 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            }

            this.onNavigationEvent(var5, var7);
         }

         var3.writeNoException();
         return true;
      }

      private static class a implements a.a.a.a {
         private IBinder a;

         a(IBinder var1) {
            this.a = var1;
         }

         public IBinder asBinder() {
            return this.a;
         }

         public void extraCallback(String var1, Bundle var2) {
            Parcel var3 = Parcel.obtain();
            Parcel var4 = Parcel.obtain();

            label166: {
               Throwable var10000;
               label170: {
                  boolean var10001;
                  try {
                     var3.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
                     var3.writeString(var1);
                  } catch (Throwable var25) {
                     var10000 = var25;
                     var10001 = false;
                     break label170;
                  }

                  if (var2 != null) {
                     try {
                        var3.writeInt(1);
                        var2.writeToParcel(var3, 0);
                     } catch (Throwable var24) {
                        var10000 = var24;
                        var10001 = false;
                        break label170;
                     }
                  } else {
                     try {
                        var3.writeInt(0);
                     } catch (Throwable var23) {
                        var10000 = var23;
                        var10001 = false;
                        break label170;
                     }
                  }

                  label156:
                  try {
                     this.a.transact(3, var3, var4, 0);
                     var4.readException();
                     break label166;
                  } catch (Throwable var22) {
                     var10000 = var22;
                     var10001 = false;
                     break label156;
                  }
               }

               Throwable var5 = var10000;
               var4.recycle();
               var3.recycle();
               throw var5;
            }

            var4.recycle();
            var3.recycle();
         }

         public void onMessageChannelReady(Bundle var1) {
            Parcel var2 = Parcel.obtain();
            Parcel var3 = Parcel.obtain();

            label166: {
               Throwable var10000;
               label170: {
                  boolean var10001;
                  try {
                     var2.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
                  } catch (Throwable var24) {
                     var10000 = var24;
                     var10001 = false;
                     break label170;
                  }

                  if (var1 != null) {
                     try {
                        var2.writeInt(1);
                        var1.writeToParcel(var2, 0);
                     } catch (Throwable var23) {
                        var10000 = var23;
                        var10001 = false;
                        break label170;
                     }
                  } else {
                     try {
                        var2.writeInt(0);
                     } catch (Throwable var22) {
                        var10000 = var22;
                        var10001 = false;
                        break label170;
                     }
                  }

                  label156:
                  try {
                     this.a.transact(4, var2, var3, 0);
                     var3.readException();
                     break label166;
                  } catch (Throwable var21) {
                     var10000 = var21;
                     var10001 = false;
                     break label156;
                  }
               }

               Throwable var4 = var10000;
               var3.recycle();
               var2.recycle();
               throw var4;
            }

            var3.recycle();
            var2.recycle();
         }

         public void onNavigationEvent(int var1, Bundle var2) {
            Parcel var3 = Parcel.obtain();
            Parcel var4 = Parcel.obtain();

            label166: {
               Throwable var10000;
               label170: {
                  boolean var10001;
                  try {
                     var3.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
                     var3.writeInt(var1);
                  } catch (Throwable var25) {
                     var10000 = var25;
                     var10001 = false;
                     break label170;
                  }

                  if (var2 != null) {
                     try {
                        var3.writeInt(1);
                        var2.writeToParcel(var3, 0);
                     } catch (Throwable var24) {
                        var10000 = var24;
                        var10001 = false;
                        break label170;
                     }
                  } else {
                     try {
                        var3.writeInt(0);
                     } catch (Throwable var23) {
                        var10000 = var23;
                        var10001 = false;
                        break label170;
                     }
                  }

                  label156:
                  try {
                     this.a.transact(2, var3, var4, 0);
                     var4.readException();
                     break label166;
                  } catch (Throwable var22) {
                     var10000 = var22;
                     var10001 = false;
                     break label156;
                  }
               }

               Throwable var5 = var10000;
               var4.recycle();
               var3.recycle();
               throw var5;
            }

            var4.recycle();
            var3.recycle();
         }

         public void onPostMessage(String var1, Bundle var2) {
            Parcel var3 = Parcel.obtain();
            Parcel var4 = Parcel.obtain();

            label166: {
               Throwable var10000;
               label170: {
                  boolean var10001;
                  try {
                     var3.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
                     var3.writeString(var1);
                  } catch (Throwable var25) {
                     var10000 = var25;
                     var10001 = false;
                     break label170;
                  }

                  if (var2 != null) {
                     try {
                        var3.writeInt(1);
                        var2.writeToParcel(var3, 0);
                     } catch (Throwable var24) {
                        var10000 = var24;
                        var10001 = false;
                        break label170;
                     }
                  } else {
                     try {
                        var3.writeInt(0);
                     } catch (Throwable var23) {
                        var10000 = var23;
                        var10001 = false;
                        break label170;
                     }
                  }

                  label156:
                  try {
                     this.a.transact(5, var3, var4, 0);
                     var4.readException();
                     break label166;
                  } catch (Throwable var22) {
                     var10000 = var22;
                     var10001 = false;
                     break label156;
                  }
               }

               Throwable var5 = var10000;
               var4.recycle();
               var3.recycle();
               throw var5;
            }

            var4.recycle();
            var3.recycle();
         }

         public void onRelationshipValidationResult(int var1, Uri var2, boolean var3, Bundle var4) {
            Parcel var5 = Parcel.obtain();
            Parcel var6 = Parcel.obtain();

            label430: {
               Throwable var10000;
               label434: {
                  boolean var10001;
                  try {
                     var5.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
                     var5.writeInt(var1);
                  } catch (Throwable var64) {
                     var10000 = var64;
                     var10001 = false;
                     break label434;
                  }

                  if (var2 != null) {
                     try {
                        var5.writeInt(1);
                        var2.writeToParcel(var5, 0);
                     } catch (Throwable var63) {
                        var10000 = var63;
                        var10001 = false;
                        break label434;
                     }
                  } else {
                     try {
                        var5.writeInt(0);
                     } catch (Throwable var62) {
                        var10000 = var62;
                        var10001 = false;
                        break label434;
                     }
                  }

                  byte var8;
                  if (var3) {
                     var8 = 1;
                  } else {
                     var8 = 0;
                  }

                  try {
                     var5.writeInt(var8);
                  } catch (Throwable var61) {
                     var10000 = var61;
                     var10001 = false;
                     break label434;
                  }

                  if (var4 != null) {
                     try {
                        var5.writeInt(1);
                        var4.writeToParcel(var5, 0);
                     } catch (Throwable var60) {
                        var10000 = var60;
                        var10001 = false;
                        break label434;
                     }
                  } else {
                     try {
                        var5.writeInt(0);
                     } catch (Throwable var59) {
                        var10000 = var59;
                        var10001 = false;
                        break label434;
                     }
                  }

                  label411:
                  try {
                     this.a.transact(6, var5, var6, 0);
                     var6.readException();
                     break label430;
                  } catch (Throwable var58) {
                     var10000 = var58;
                     var10001 = false;
                     break label411;
                  }
               }

               Throwable var7 = var10000;
               var6.recycle();
               var5.recycle();
               throw var7;
            }

            var6.recycle();
            var5.recycle();
         }
      }
   }
}
