package b.a.a.a;

import android.net.Uri;
import android.os.Parcel;
import android.os.RemoteException;
import androidx.fragment.app.Fragment;
import b.b.b.b.b.a$a;
import com.google.android.gms.cast.framework.f;
import com.google.android.gms.internal.ads.t;
import com.google.android.gms.internal.ads.w12;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class a {
   public static float a(float var0, float var1, float var2, float var3) {
      return var3 + var2 * (var0 - var1);
   }

   public static int b(int var0, int var1, int var2, int var3) {
      return var3 + var0 * var1 / var2;
   }

   public static String c(String var0, int var1) {
      StringBuilder var2 = new StringBuilder();
      var2.append(var0);
      var2.append(var1);
      return var2.toString();
   }

   public static String d(String var0, Uri var1) {
      StringBuilder var2 = new StringBuilder();
      var2.append(var0);
      var2.append(var1);
      return var2.toString();
   }

   public static String e(String var0, Fragment var1, String var2) {
      StringBuilder var3 = new StringBuilder();
      var3.append(var0);
      var3.append(var1);
      var3.append(var2);
      return var3.toString();
   }

   public static String f(String var0, String var1) {
      StringBuilder var2 = new StringBuilder();
      var2.append(var0);
      var2.append(var1);
      return var2.toString();
   }

   public static String g(String var0, String var1, String var2) {
      StringBuilder var3 = new StringBuilder();
      var3.append(var0);
      var3.append(var1);
      var3.append(var2);
      return var3.toString();
   }

   public static String h(StringBuilder var0, String var1, String var2) {
      var0.append(var1);
      var0.append(var2);
      return var0.toString();
   }

   public static StringBuilder i(int var0, String var1, String var2, String var3, String var4) {
      StringBuilder var5 = new StringBuilder(var0);
      var5.append(var1);
      var5.append(var2);
      var5.append(var3);
      var5.append(var4);
      return var5;
   }

   public static StringBuilder j(String var0) {
      StringBuilder var1 = new StringBuilder();
      var1.append(var0);
      return var1;
   }

   public static StringBuilder k(String var0, String var1) {
      StringBuilder var2 = new StringBuilder();
      var2.append(var0);
      var2.append(var1);
      return var2;
   }

   public static HashMap l(String var0, String var1) {
      HashMap var2 = new HashMap();
      var2.put(var0, var1);
      return var2;
   }

   public static int m(String var0, int var1) {
      return var1 + String.valueOf(var0).length();
   }

   public static void n(String var0, String var1, w12 var2, String var3, LinkedHashMap var4, String var5, w12 var6) {
      f.Y(var0, var1);
      f.Y(var2, var3);
      var4.put(var5, var6);
   }

   public static void o(StringBuilder var0, String var1, char var2, String var3) {
      var0.append(var1);
      var0.append(var2);
      var0.append(var3);
   }

   public static void p(StringBuilder var0, String var1, String var2, String var3, String var4) {
      var0.append(var1);
      var0.append(var2);
      var0.append(var3);
      var0.append(var4);
   }

   public static RemoteException q(String var0, Throwable var1) {
      t.v0(var0, var1);
      return new RemoteException();
   }

   public static b.b.b.b.b.a r(Parcel var0) {
      b.b.b.b.b.a var1 = a$a.V1(var0.readStrongBinder());
      var0.recycle();
      return var1;
   }

   public static String s(int var0, String var1, int var2) {
      StringBuilder var3 = new StringBuilder(var0);
      var3.append(var1);
      var3.append(var2);
      return var3.toString();
   }

   public static String t(int var0, String var1, int var2, String var3, int var4) {
      StringBuilder var5 = new StringBuilder(var0);
      var5.append(var1);
      var5.append(var2);
      var5.append(var3);
      var5.append(var4);
      return var5.toString();
   }

   public static String u(int var0, String var1, String var2) {
      StringBuilder var3 = new StringBuilder(var0);
      var3.append(var1);
      var3.append(var2);
      return var3.toString();
   }

   public static String v(int var0, String var1, String var2, String var3) {
      StringBuilder var4 = new StringBuilder(var0);
      var4.append(var1);
      var4.append(var2);
      var4.append(var3);
      return var4.toString();
   }

   public static String w(int var0, String var1, String var2, String var3, String var4) {
      StringBuilder var5 = new StringBuilder(var0);
      var5.append(var1);
      var5.append(var2);
      var5.append(var3);
      var5.append(var4);
      return var5.toString();
   }
}
