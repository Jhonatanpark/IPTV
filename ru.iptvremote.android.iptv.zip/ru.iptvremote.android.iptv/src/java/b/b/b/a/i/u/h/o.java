package b.b.b.a.i.u.h;

import android.database.Cursor;
import java.util.Map;

// $FF: synthetic class
final class o implements b.b.b.a.i.u.h.a0.b {
   private final Map a;

   private o(Map var1) {
      this.a = var1;
   }

   public static b.b.b.a.i.u.h.a0.b a(Map var0) {
      return new o(var0);
   }

   public Object apply(Object var1) {
      a0.I(this.a, (Cursor)var1);
      return null;
   }
}
