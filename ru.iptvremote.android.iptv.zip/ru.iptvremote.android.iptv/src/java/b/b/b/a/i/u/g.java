package b.b.b.a.i.u;

import android.content.Context;
import android.os.Build.VERSION;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.e;
import d.a.a;

public final class g implements c.a.b {
   private final a a;
   private final a b;
   private final a c;
   private final a d;

   public g(a var1, a var2, a var3, a var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   public Object get() {
      Context var1 = (Context)this.a.get();
      b.b.b.a.i.u.h.c var2 = (b.b.b.a.i.u.h.c)this.b.get();
      com.google.android.datatransport.runtime.scheduling.jobscheduling.g var3 = (com.google.android.datatransport.runtime.scheduling.jobscheduling.g)this.c.get();
      b.b.b.a.i.w.a var4 = (b.b.b.a.i.w.a)this.d.get();
      Object var5;
      if (VERSION.SDK_INT >= 21) {
         var5 = new e(var1, var2, var3);
      } else {
         var5 = new com.google.android.datatransport.runtime.scheduling.jobscheduling.a(var1, var2, var4, var3);
      }

      com.google.android.gms.cast.framework.f.q(var5, "Cannot return null from a non-@Nullable @Provides method");
      return var5;
   }
}
