package b.b.b.a.i.u.h;

import android.database.sqlite.SQLiteDatabase;

// $FF: synthetic class
final class c0 implements b.b.b.a.i.u.h.g0.a {
   private static final c0 a = new c0();

   private c0() {
   }

   public static b.b.b.a.i.u.h.g0.a b() {
      return a;
   }

   public void a(SQLiteDatabase var1) {
      g0.a(var1);
   }
}
