package b.b.b.a.i;

import android.content.Context;
import androidx.annotation.RestrictTo;
import androidx.annotation.RestrictTo.Scope;
import b.b.b.a.b;
import b.b.b.a.g;
import b.b.b.a.i.u.e;
import b.b.b.a.i.w.a;
import java.util.Collections;
import java.util.HashMap;
import java.util.Set;

public class p implements o {
   private static volatile q e;
   private final a a;
   private final a b;
   private final e c;
   private final com.google.android.datatransport.runtime.scheduling.jobscheduling.m d;

   p(a var1, a var2, e var3, com.google.android.datatransport.runtime.scheduling.jobscheduling.m var4, com.google.android.datatransport.runtime.scheduling.jobscheduling.q var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      var5.a();
   }

   public static p a() {
      q var0 = e;
      if (var0 != null) {
         return var0.b();
      } else {
         throw new IllegalStateException("Not initialized!");
      }
   }

   public static void c(Context var0) {
      if (e == null) {
         Class var5 = p.class;
         synchronized(p.class){}

         Throwable var10000;
         boolean var10001;
         label205: {
            label211: {
               d.b var2;
               try {
                  if (e != null) {
                     break label211;
                  }

                  var2 = new d.b((b.b.b.a.i.d.a)null);
                  var2.b(var0);
               } catch (Throwable var25) {
                  var10000 = var25;
                  var10001 = false;
                  break label205;
               }

               d.b var4 = (d.b)var2;

               try {
                  e = var4.a();
               } catch (Throwable var24) {
                  var10000 = var24;
                  var10001 = false;
                  break label205;
               }
            }

            label196:
            try {
               return;
            } catch (Throwable var23) {
               var10000 = var23;
               var10001 = false;
               break label196;
            }
         }

         while(true) {
            Throwable var1 = var10000;

            try {
               throw var1;
            } catch (Throwable var22) {
               var10000 = var22;
               var10001 = false;
               continue;
            }
         }
      }
   }

   @RestrictTo({Scope.LIBRARY})
   public com.google.android.datatransport.runtime.scheduling.jobscheduling.m b() {
      return this.d;
   }

   public g d(b.b.b.a.i.e var1) {
      Set var2;
      if (var1 instanceof b.b.b.a.i.e) {
         var2 = Collections.unmodifiableSet(var1.a());
      } else {
         var2 = Collections.singleton(b.b.b.a.b.b("proto"));
      }

      b.b.b.a.i.k.a var3 = k.a();
      var3.b(var1.getName());
      var3.c(var1.getExtras());
      return new l(var2, var3.a(), this);
   }

   public void e(j var1, b.b.b.a.h var2) {
      e var3 = this.c;
      k var4 = var1.d();
      b.b.b.a.d var5 = var1.b().c();
      if (var4 != null) {
         b.b.b.a.i.k.a var6 = k.a();
         var6.b(var4.b());
         var6.d(var5);
         var6.c(var4.c());
         k var10 = var6.a();
         b.b.b.a.i.a.b var11 = new b.b.b.a.i.a.b();
         var11.f(new HashMap());
         var11.i(this.a.a());
         var11.k(this.b.a());
         var11.j(var1.e());
         var11.h(new f(var1.a(), (byte[])var1.c().apply(var1.b().b())));
         var11.g(var1.b().a());
         var3.a(var10, var11.d(), var2);
      } else {
         throw null;
      }
   }
}
