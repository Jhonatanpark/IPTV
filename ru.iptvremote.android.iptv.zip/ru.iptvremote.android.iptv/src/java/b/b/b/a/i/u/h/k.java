package b.b.b.a.i.u.h;

import android.database.sqlite.SQLiteDatabase;

// $FF: synthetic class
final class k implements b.b.b.a.i.u.h.a0.b {
   private static final k a = new k();

   private k() {
   }

   public static b.b.b.a.i.u.h.a0.b a() {
      return a;
   }

   public Object apply(Object var1) {
      return a0.E((SQLiteDatabase)var1);
   }
}
