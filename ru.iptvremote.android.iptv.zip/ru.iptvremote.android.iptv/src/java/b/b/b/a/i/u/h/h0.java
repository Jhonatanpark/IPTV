package b.b.b.a.i.u.h;

import android.content.Context;

public final class h0 implements c.a.b {
   private final d.a.a a;
   private final d.a.a b;
   private final d.a.a c;

   public h0(d.a.a var1, d.a.a var2, d.a.a var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public Object get() {
      return new g0((Context)this.a.get(), (String)this.b.get(), (Integer)this.c.get());
   }
}
