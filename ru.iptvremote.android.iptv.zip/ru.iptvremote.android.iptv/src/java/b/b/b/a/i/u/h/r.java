package b.b.b.a.i.u.h;

import b.b.b.a.i.u.h.a0.d;

// $FF: synthetic class
final class r implements d {
   private final g0 a;

   private r(g0 var1) {
      this.a = var1;
   }

   public static d b(g0 var0) {
      return new r(var0);
   }

   public Object a() {
      return this.a.getWritableDatabase();
   }
}
