package b.b.b.a.i.u.h;

import android.database.sqlite.SQLiteDatabase;

// $FF: synthetic class
final class x implements b.b.b.a.i.u.h.a0.b {
   private final String a;

   private x(String var1) {
      this.a = var1;
   }

   public static b.b.b.a.i.u.h.a0.b a(String var0) {
      return new x(var0);
   }

   public Object apply(Object var1) {
      a0.P(this.a, (SQLiteDatabase)var1);
      return null;
   }
}
