package b.b.b.a.i.w;

import com.google.android.gms.cast.framework.f;

public final class b implements c.a.b {
   private static final b a = new b();

   public static b a() {
      return a;
   }

   public Object get() {
      e var1 = new e();
      f.q(var1, "Cannot return null from a non-@Nullable @Provides method");
      return var1;
   }
}
