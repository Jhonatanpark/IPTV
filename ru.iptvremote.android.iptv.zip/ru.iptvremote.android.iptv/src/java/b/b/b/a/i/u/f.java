package b.b.b.a.i.u;

import d.a.a;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

public final class f implements c.a.b {
   private final a a;

   public f(a var1) {
      this.a = var1;
   }

   public Object get() {
      b.b.b.a.i.w.a var1 = (b.b.b.a.i.w.a)this.a.get();
      com.google.android.datatransport.runtime.scheduling.jobscheduling.g.a var2 = new com.google.android.datatransport.runtime.scheduling.jobscheduling.g.a();
      b.b.b.a.d var3 = b.b.b.a.d.a;
      com.google.android.datatransport.runtime.scheduling.jobscheduling.g.b.a var4 = com.google.android.datatransport.runtime.scheduling.jobscheduling.g.b.a();
      var4.b(30000L);
      var4.d(86400000L);
      var2.a(var3, var4.a());
      b.b.b.a.d var8 = b.b.b.a.d.c;
      com.google.android.datatransport.runtime.scheduling.jobscheduling.g.b.a var9 = com.google.android.datatransport.runtime.scheduling.jobscheduling.g.b.a();
      var9.b(1000L);
      var9.d(86400000L);
      var2.a(var8, var9.a());
      b.b.b.a.d var13 = b.b.b.a.d.b;
      com.google.android.datatransport.runtime.scheduling.jobscheduling.g.b.a var14 = com.google.android.datatransport.runtime.scheduling.jobscheduling.g.b.a();
      var14.b(86400000L);
      var14.d(86400000L);
      com.google.android.datatransport.runtime.scheduling.jobscheduling.g.c[] var17 = new com.google.android.datatransport.runtime.scheduling.jobscheduling.g.c[]{com.google.android.datatransport.runtime.scheduling.jobscheduling.g.c.a, com.google.android.datatransport.runtime.scheduling.jobscheduling.g.c.b};
      var14.c(Collections.unmodifiableSet(new HashSet(Arrays.asList(var17))));
      var2.a(var13, var14.a());
      var2.c(var1);
      com.google.android.datatransport.runtime.scheduling.jobscheduling.g var21 = var2.b();
      com.google.android.gms.cast.framework.f.q(var21, "Cannot return null from a non-@Nullable @Provides method");
      return var21;
   }
}
