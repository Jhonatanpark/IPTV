package b.b.b.a.i.u.h;

public final class e implements c.a.b {
   private static final e a = new e();

   public static e a() {
      return a;
   }

   public Object get() {
      com.google.android.gms.cast.framework.f.q("com.google.android.datatransport.events", "Cannot return null from a non-@Nullable @Provides method");
      return "com.google.android.datatransport.events";
   }
}
