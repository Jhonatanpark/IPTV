package b.b.b.a.i.u.h;

import android.database.sqlite.SQLiteDatabase;
import b.b.b.a.i.u.h.a0.d;

// $FF: synthetic class
final class p implements d {
   private final SQLiteDatabase a;

   private p(SQLiteDatabase var1) {
      this.a = var1;
   }

   public static d b(SQLiteDatabase var0) {
      return new p(var0);
   }

   public Object a() {
      a0.g(this.a);
      return null;
   }
}
