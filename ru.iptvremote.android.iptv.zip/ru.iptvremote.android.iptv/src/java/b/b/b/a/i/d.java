package b.b.b.a.i;

import android.content.Context;
import b.b.b.a.i.u.h.b0;
import b.b.b.a.i.u.h.e;
import b.b.b.a.i.u.h.f;
import b.b.b.a.i.u.h.g;
import b.b.b.a.i.u.h.h0;
import c.a.c;
import com.google.android.datatransport.runtime.backends.j;
import d.a.a;

final class d extends q {
   private a a = c.a.a.a(b.b.b.a.i.h.a());
   private a b;
   private a c;
   private a d;
   private a e;
   private a f;
   private a g;
   private a h;
   private a i;
   private a j;
   private a k;
   private a l;

   d(Context var1, b.b.b.a.i.d.a var2) {
      c.a.b var3 = c.a.c.a(var1);
      this.b = var3;
      j var4 = new j(var3, b.b.b.a.i.w.b.a(), b.b.b.a.i.w.c.a());
      this.c = var4;
      this.d = c.a.a.a(new com.google.android.datatransport.runtime.backends.l(this.b, var4));
      this.e = new h0(this.b, b.b.b.a.i.u.h.e.a(), b.b.b.a.i.u.h.f.a());
      this.f = c.a.a.a(new b0(b.b.b.a.i.w.b.a(), b.b.b.a.i.w.c.a(), b.b.b.a.i.u.h.g.a(), this.e));
      b.b.b.a.i.u.f var5 = new b.b.b.a.i.u.f(b.b.b.a.i.w.b.a());
      this.g = var5;
      b.b.b.a.i.u.g var6 = new b.b.b.a.i.u.g(this.b, this.f, var5, b.b.b.a.i.w.c.a());
      this.h = var6;
      a var7 = this.a;
      a var8 = this.d;
      a var9 = this.f;
      b.b.b.a.i.u.d var10 = new b.b.b.a.i.u.d(var7, var8, var6, var9, var9);
      this.i = var10;
      a var11 = this.b;
      a var12 = this.d;
      a var13 = this.f;
      a var14 = this.h;
      a var15 = this.a;
      b.b.b.a.i.w.b var16 = b.b.b.a.i.w.b.a();
      com.google.android.datatransport.runtime.scheduling.jobscheduling.n var17 = new com.google.android.datatransport.runtime.scheduling.jobscheduling.n(var11, var12, var13, var14, var15, var13, var16);
      this.j = var17;
      a var18 = this.a;
      a var19 = this.f;
      this.k = new com.google.android.datatransport.runtime.scheduling.jobscheduling.r(var18, var19, this.h, var19);
      b.b.b.a.i.w.b var20 = b.b.b.a.i.w.b.a();
      b.b.b.a.i.w.c var21 = b.b.b.a.i.w.c.a();
      a var22 = this.i;
      a var23 = this.j;
      a var24 = this.k;
      r var25 = new r(var20, var21, var22, var23, var24);
      this.l = c.a.a.a(var25);
   }

   b.b.b.a.i.u.h.c a() {
      return (b.b.b.a.i.u.h.c)this.f.get();
   }

   p b() {
      return (p)this.l.get();
   }

   private static final class b implements b.b.b.a.i.q.a {
      private Context a;

      private b() {
      }

      b(b.b.b.a.i.d.a var1) {
      }

      public q a() {
         Context var1 = this.a;
         if (var1 != null) {
            return new d(var1, (b.b.b.a.i.d.a)null);
         } else {
            StringBuilder var2 = new StringBuilder();
            var2.append(Context.class.getCanonicalName());
            var2.append(" must be set");
            throw new IllegalStateException(var2.toString());
         }
      }

      public b.b.b.a.i.q.a b(Context var1) {
         if (var1 != null) {
            this.a = var1;
            return this;
         } else {
            throw null;
         }
      }
   }
}
