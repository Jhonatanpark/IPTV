package b.b.b.a.i.u.h;

import android.database.Cursor;

// $FF: synthetic class
final class y implements b.b.b.a.i.u.h.a0.b {
   private static final y a = new y();

   private y() {
   }

   public static b.b.b.a.i.u.h.a0.b a() {
      return a;
   }

   public Object apply(Object var1) {
      return a0.w((Cursor)var1);
   }
}
