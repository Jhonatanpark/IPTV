package b.b.b.a.i.u.h;

public final class g implements c.a.b {
   private static final g a = new g();

   public static g a() {
      return a;
   }

   public Object get() {
      d var1 = d.a;
      com.google.android.gms.cast.framework.f.q(var1, "Cannot return null from a non-@Nullable @Provides method");
      return var1;
   }
}
