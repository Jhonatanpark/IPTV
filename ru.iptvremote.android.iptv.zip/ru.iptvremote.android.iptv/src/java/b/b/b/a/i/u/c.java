package b.b.b.a.i.u;

import b.a.a.a.a;
import b.b.b.a.h;
import b.b.b.a.i.k;
import b.b.b.a.i.p;
import com.google.android.datatransport.runtime.backends.m;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.s;
import java.util.concurrent.Executor;
import java.util.logging.Logger;

public class c implements e {
   private static final Logger f = Logger.getLogger(p.class.getName());
   private final s a;
   private final Executor b;
   private final com.google.android.datatransport.runtime.backends.e c;
   private final b.b.b.a.i.u.h.c d;
   private final b.b.b.a.i.v.b e;

   public c(Executor var1, com.google.android.datatransport.runtime.backends.e var2, s var3, b.b.b.a.i.u.h.c var4, b.b.b.a.i.v.b var5) {
      this.b = var1;
      this.c = var2;
      this.a = var3;
      this.d = var4;
      this.e = var5;
   }

   // $FF: synthetic method
   static Object b(c var0, k var1, b.b.b.a.i.g var2) {
      var0.d.S(var1, var2);
      var0.a.a(var1, 1);
      return null;
   }

   // $FF: synthetic method
   static void c(c var0, k var1, h var2, b.b.b.a.i.g var3) {
      Exception var10000;
      label25: {
         m var8;
         boolean var10001;
         try {
            var8 = var0.c.a(var1.b());
         } catch (Exception var14) {
            var10000 = var14;
            var10001 = false;
            break label25;
         }

         if (var8 == null) {
            try {
               Object[] var9 = new Object[]{var1.b()};
               String var10 = String.format("Transport backend '%s' is not registered", var9);
               f.warning(var10);
               var2.a(new IllegalArgumentException(var10));
               return;
            } catch (Exception var12) {
               var10000 = var12;
               var10001 = false;
            }
         } else {
            try {
               b.b.b.a.i.g var11 = var8.b(var3);
               var0.e.a(b.b.b.a.i.u.b.a(var0, var1, var11));
               var2.a((Exception)null);
               return;
            } catch (Exception var13) {
               var10000 = var13;
               var10001 = false;
            }
         }
      }

      Exception var4 = var10000;
      Logger var5 = f;
      StringBuilder var6 = b.a.a.a.a.j("Error scheduling event ");
      var6.append(var4.getMessage());
      var5.warning(var6.toString());
      var2.a(var4);
   }

   public void a(k var1, b.b.b.a.i.g var2, h var3) {
      this.b.execute(b.b.b.a.i.u.a.a(this, var1, var3, var2));
   }
}
