package b.b.b.a.i.w;

import android.os.SystemClock;

public class d implements a {
   public long a() {
      return SystemClock.elapsedRealtime();
   }
}
