package b.b.b.a.i.u.h;

import android.database.Cursor;

// $FF: synthetic class
final class s implements b.b.b.a.i.u.h.a0.b {
   private static final s a = new s();

   private s() {
   }

   public static b.b.b.a.i.u.h.a0.b a() {
      return a;
   }

   public Object apply(Object var1) {
      return a0.D((Cursor)var1);
   }
}
