package b.b.b.a.i;

import b.b.b.a.b;
import b.b.b.a.c;
import b.b.b.a.e;
import b.b.b.a.f;

final class n implements f {
   private final k a;
   private final String b;
   private final b c;
   private final e d;
   private final o e;

   n(k var1, String var2, b var3, e var4, o var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }

   public void a(c var1) {
      this.b(var1, m.b());
   }

   public void b(c var1, b.b.b.a.h var2) {
      o var3 = this.e;
      b.b.b.a.i.b.b var4 = new b.b.b.a.i.b.b();
      var4.e(this.a);
      var4.c(var1);
      var4.f(this.b);
      var4.d(this.d);
      var4.b(this.c);
      j var10 = var4.a();
      ((p)var3).e(var10, var2);
   }
}
