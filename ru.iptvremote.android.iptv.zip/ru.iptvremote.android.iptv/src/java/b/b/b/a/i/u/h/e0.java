package b.b.b.a.i.u.h;

import android.database.sqlite.SQLiteDatabase;

// $FF: synthetic class
final class e0 implements b.b.b.a.i.u.h.g0.a {
   private static final e0 a = new e0();

   private e0() {
   }

   public static b.b.b.a.i.u.h.g0.a b() {
      return a;
   }

   public void a(SQLiteDatabase var1) {
      g0.c(var1);
   }
}
