package b.b.b.a.i.u.h;

public final class f implements c.a.b {
   private static final f a = new f();

   public static f a() {
      return a;
   }

   public Object get() {
      int var10000 = g0.c;
      return 4;
   }
}
