package b.b.b.a.i.u.h;

public final class b0 implements c.a.b {
   private final d.a.a a;
   private final d.a.a b;
   private final d.a.a c;
   private final d.a.a d;

   public b0(d.a.a var1, d.a.a var2, d.a.a var3, d.a.a var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   public Object get() {
      return new a0((b.b.b.a.i.w.a)this.a.get(), (b.b.b.a.i.w.a)this.b.get(), (d)this.c.get(), (g0)this.d.get());
   }
}
