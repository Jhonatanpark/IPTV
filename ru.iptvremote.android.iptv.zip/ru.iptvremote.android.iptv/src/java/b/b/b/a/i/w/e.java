package b.b.b.a.i.w;

public class e implements a {
   public long a() {
      return System.currentTimeMillis();
   }
}
