package b.b.b.a.i.u.h;

import android.database.Cursor;
import java.util.List;

// $FF: synthetic class
final class m implements b.b.b.a.i.u.h.a0.b {
   private final a0 a;
   private final List b;
   private final b.b.b.a.i.k c;

   private m(a0 var1, List var2, b.b.b.a.i.k var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public static b.b.b.a.i.u.h.a0.b a(a0 var0, List var1, b.b.b.a.i.k var2) {
      return new m(var0, var1, var2);
   }

   public Object apply(Object var1) {
      a0.G(this.a, this.b, this.c, (Cursor)var1);
      return null;
   }
}
