package b.b.b.a.i.u.h;

final class a extends d {
   private final long b;
   private final int c;
   private final int d;
   private final long e;
   private final int f;

   a(long var1, int var3, int var4, long var5, int var7, b.b.b.a.i.u.h.a.a var8) {
      this.b = var1;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var7;
   }

   int a() {
      return this.d;
   }

   long b() {
      return this.e;
   }

   int c() {
      return this.c;
   }

   int d() {
      return this.f;
   }

   long e() {
      return this.b;
   }

   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else if (var1 instanceof d) {
         d var2 = (d)var1;
         if (this.b == ((a)var2).b) {
            int var3 = this.c;
            a var4 = (a)var2;
            if (var3 == var4.c && this.d == var4.d && this.e == var4.e && this.f == var4.f) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public int hashCode() {
      long var1 = this.b;
      int var3 = 1000003 * (1000003 * (1000003 * (1000003 ^ (int)(var1 ^ var1 >>> 32)) ^ this.c) ^ this.d);
      long var4 = this.e;
      return 1000003 * (var3 ^ (int)(var4 ^ var4 >>> 32)) ^ this.f;
   }

   public String toString() {
      StringBuilder var1 = b.a.a.a.a.j("EventStoreConfig{maxStorageSizeInBytes=");
      var1.append(this.b);
      var1.append(", loadBatchSize=");
      var1.append(this.c);
      var1.append(", criticalSectionEnterTimeoutMs=");
      var1.append(this.d);
      var1.append(", eventCleanUpAge=");
      var1.append(this.e);
      var1.append(", maxBlobByteSizePerRow=");
      var1.append(this.f);
      var1.append("}");
      return var1.toString();
   }

   static final class b extends b.b.b.a.i.u.h.d.a {
      private Long a;
      private Integer b;
      private Integer c;
      private Long d;
      private Integer e;

      d a() {
         String var1;
         if (this.a == null) {
            var1 = " maxStorageSizeInBytes";
         } else {
            var1 = "";
         }

         if (this.b == null) {
            var1 = b.a.a.a.a.f(var1, " loadBatchSize");
         }

         if (this.c == null) {
            var1 = b.a.a.a.a.f(var1, " criticalSectionEnterTimeoutMs");
         }

         if (this.d == null) {
            var1 = b.a.a.a.a.f(var1, " eventCleanUpAge");
         }

         if (this.e == null) {
            var1 = b.a.a.a.a.f(var1, " maxBlobByteSizePerRow");
         }

         if (var1.isEmpty()) {
            a var2 = new a(this.a, this.b, this.c, this.d, this.e, (b.b.b.a.i.u.h.a.a)null);
            return var2;
         } else {
            throw new IllegalStateException(b.a.a.a.a.f("Missing required properties:", var1));
         }
      }

      b.b.b.a.i.u.h.d.a b(int var1) {
         this.c = var1;
         return this;
      }

      b.b.b.a.i.u.h.d.a c(long var1) {
         this.d = var1;
         return this;
      }

      b.b.b.a.i.u.h.d.a d(int var1) {
         this.b = var1;
         return this;
      }

      b.b.b.a.i.u.h.d.a e(int var1) {
         this.e = var1;
         return this;
      }

      b.b.b.a.i.u.h.d.a f(long var1) {
         this.a = var1;
         return this;
      }
   }
}
