package b.b.b.a.i.u.h;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.os.SystemClock;
import android.util.Base64;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import androidx.annotation.WorkerThread;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

@WorkerThread
public class a0 implements c, b.b.b.a.i.v.b {
   private static final b.b.b.a.b e = b.b.b.a.b.b("proto");
   private final g0 a;
   private final b.b.b.a.i.w.a b;
   private final b.b.b.a.i.w.a c;
   private final d d;

   a0(b.b.b.a.i.w.a var1, b.b.b.a.i.w.a var2, d var3, g0 var4) {
      this.a = var4;
      this.b = var1;
      this.c = var2;
      this.d = var3;
   }

   // $FF: synthetic method
   static Boolean C(a0 var0, b.b.b.a.i.k var1, SQLiteDatabase var2) {
      Long var3 = var0.c(var2, var1);
      if (var3 == null) {
         return Boolean.FALSE;
      } else {
         SQLiteDatabase var4 = var0.b();
         String[] var5 = new String[]{var3.toString()};
         return (Boolean)Y(var4.rawQuery("SELECT 1 FROM events WHERE context_id = ? LIMIT 1", var5), t.a());
      }
   }

   static List D(Cursor var0) {
      ArrayList var1 = new ArrayList();

      while(var0.moveToNext()) {
         b.b.b.a.i.k.a var2 = b.b.b.a.i.k.a();
         var2.b(var0.getString(1));
         var2.d(b.b.b.a.i.x.a.b(var0.getInt(2)));
         String var5 = var0.getString(3);
         byte[] var6;
         if (var5 == null) {
            var6 = null;
         } else {
            var6 = Base64.decode(var5, 0);
         }

         var2.c(var6);
         var1.add(var2.a());
      }

      return var1;
   }

   // $FF: synthetic method
   static List E(SQLiteDatabase var0) {
      return (List)Y(var0.rawQuery("SELECT distinct t._id, t.backend_name, t.priority, t.extras FROM transport_contexts AS t, events AS e WHERE e.context_id = t._id", new String[0]), s.a());
   }

   static List F(a0 var0, b.b.b.a.i.k var1, SQLiteDatabase var2) {
      if (var0 == null) {
         throw null;
      } else {
         ArrayList var3 = new ArrayList();
         Long var4 = var0.c(var2, var1);
         if (var4 != null) {
            String[] var5 = new String[]{"_id", "transport_name", "timestamp_ms", "uptime_ms", "payload_encoding", "payload", "code", "inline"};
            String[] var6 = new String[]{var4.toString()};
            Y(var2.query("events", var5, "context_id = ?", var6, (String)null, (String)null, (String)null, String.valueOf(var0.d.c())), m.a(var0, var3, var1));
         }

         HashMap var8 = new HashMap();
         StringBuilder var9 = new StringBuilder("event_id IN (");

         for(int var10 = 0; var10 < var3.size(); ++var10) {
            var9.append(((h)var3.get(var10)).b());
            if (var10 < var3.size() - 1) {
               var9.append(',');
            }
         }

         var9.append(')');
         Y(var2.query("event_metadata", new String[]{"event_id", "name", "value"}, var9.toString(), (String[])null, (String)null, (String)null, (String)null), o.a(var8));
         ListIterator var13 = var3.listIterator();

         while(true) {
            h var14;
            do {
               if (!var13.hasNext()) {
                  return var3;
               }

               var14 = (h)var13.next();
            } while(!var8.containsKey(var14.b()));

            b.b.b.a.i.g.a var15 = var14.a().l();
            Iterator var16 = ((Set)var8.get(var14.b())).iterator();

            while(var16.hasNext()) {
               b.b.b.a.i.u.h.a0.c var17 = (b.b.b.a.i.u.h.a0.c)var16.next();
               var15.c(var17.a, var17.b);
            }

            var13.set(new b(var14.b(), var14.c(), var15.d()));
         }
      }
   }

   static Object G(a0 var0, List var1, b.b.b.a.i.k var2, Cursor var3) {
      long var4;
      b.b.b.a.i.g.a var7;
      for(; var3.moveToNext(); var1.add(new b(var4, var2, var7.d()))) {
         var4 = var3.getLong(0);
         boolean var6;
         if (var3.getInt(7) != 0) {
            var6 = true;
         } else {
            var6 = false;
         }

         var7 = b.b.b.a.i.g.a();
         var7.j(var3.getString(1));
         var7.i(var3.getLong(2));
         var7.k(var3.getLong(3));
         if (var6) {
            String var19 = var3.getString(4);
            b.b.b.a.b var20;
            if (var19 == null) {
               var20 = e;
            } else {
               var20 = b.b.b.a.b.b(var19);
            }

            var7.h(new b.b.b.a.i.f(var20, var3.getBlob(5)));
         } else {
            String var11 = var3.getString(4);
            b.b.b.a.b var12;
            if (var11 == null) {
               var12 = e;
            } else {
               var12 = b.b.b.a.b.b(var11);
            }

            SQLiteDatabase var13 = var0.b();
            String[] var14 = new String[]{"bytes"};
            String[] var15 = new String[]{String.valueOf(var4)};
            var7.h(new b.b.b.a.i.f(var12, (byte[])Y(var13.query("event_payloads", var14, "event_id = ?", var15, (String)null, (String)null, "sequence_num"), n.a())));
         }

         if (!var3.isNull(6)) {
            var7.g(var3.getInt(6));
         }
      }

      return null;
   }

   // $FF: synthetic method
   static Object I(Map var0, Cursor var1) {
      Object var4;
      for(; var1.moveToNext(); ((Set)var4).add(new b.b.b.a.i.u.h.a0.c(var1.getString(1), var1.getString(2), (b.b.b.a.i.u.h.a0.a)null))) {
         long var2 = var1.getLong(0);
         var4 = (Set)var0.get(var2);
         if (var4 == null) {
            var4 = new HashSet();
            var0.put(var2, var4);
         }
      }

      return null;
   }

   static Long L(a0 var0, b.b.b.a.i.k var1, b.b.b.a.i.g var2, SQLiteDatabase var3) {
      long var4 = var0.b().compileStatement("PRAGMA page_count").simpleQueryForLong() * var0.b().compileStatement("PRAGMA page_size").simpleQueryForLong();
      long var6 = var0.d.e();
      int var8 = 1;
      boolean var9;
      if (var4 >= var6) {
         var9 = true;
      } else {
         var9 = false;
      }

      if (var9) {
         return -1L;
      } else {
         Long var10 = var0.c(var3, var1);
         long var12;
         if (var10 != null) {
            var12 = var10;
         } else {
            ContentValues var11 = new ContentValues();
            var11.put("backend_name", var1.b());
            var11.put("priority", b.b.b.a.i.x.a.a(var1.d()));
            var11.put("next_request_ms", 0);
            if (var1.c() != null) {
               var11.put("extras", Base64.encodeToString(var1.c(), 0));
            }

            var12 = var3.insert("transport_contexts", (String)null, var11);
         }

         int var14 = var0.d.d();
         byte[] var15 = var2.e().a();
         boolean var16;
         if (var15.length <= var14) {
            var16 = true;
         } else {
            var16 = false;
         }

         ContentValues var17 = new ContentValues();
         var17.put("context_id", var12);
         var17.put("transport_name", var2.j());
         var17.put("timestamp_ms", var2.f());
         var17.put("uptime_ms", var2.k());
         var17.put("payload_encoding", var2.e().b().a());
         var17.put("code", var2.d());
         var17.put("num_attempts", 0);
         var17.put("inline", var16);
         byte[] var18;
         if (var16) {
            var18 = var15;
         } else {
            var18 = new byte[0];
         }

         var17.put("payload", var18);
         long var19 = var3.insert("events", (String)null, var17);
         if (!var16) {
            double var26 = (double)var15.length;
            double var28 = (double)var14;
            Double.isNaN(var26);
            Double.isNaN(var28);

            for(int var32 = (int)Math.ceil(var26 / var28); var8 <= var32; ++var8) {
               byte[] var33 = Arrays.copyOfRange(var15, var14 * (var8 - 1), Math.min(var8 * var14, var15.length));
               ContentValues var34 = new ContentValues();
               var34.put("event_id", var19);
               var34.put("sequence_num", var8);
               var34.put("bytes", var33);
               var3.insert("event_payloads", (String)null, var34);
            }
         }

         Iterator var21 = var2.i().entrySet().iterator();

         while(var21.hasNext()) {
            Entry var22 = (Entry)var21.next();
            ContentValues var23 = new ContentValues();
            var23.put("event_id", var19);
            var23.put("name", (String)var22.getKey());
            var23.put("value", (String)var22.getValue());
            var3.insert("event_metadata", (String)null, var23);
         }

         return var19;
      }
   }

   // $FF: synthetic method
   static byte[] N(Cursor var0) {
      ArrayList var1 = new ArrayList();

      int var2;
      byte[] var7;
      for(var2 = 0; var0.moveToNext(); var2 += var7.length) {
         var7 = var0.getBlob(0);
         var1.add(var7);
      }

      byte[] var3 = new byte[var2];
      int var4 = 0;

      for(int var5 = 0; var4 < var1.size(); ++var4) {
         byte[] var6 = (byte[])var1.get(var4);
         System.arraycopy(var6, 0, var3, var5, var6.length);
         var5 += var6.length;
      }

      return var3;
   }

   // $FF: synthetic method
   static Object P(String var0, SQLiteDatabase var1) {
      var1.compileStatement(var0).execute();
      var1.compileStatement("DELETE FROM events WHERE num_attempts >= 16").execute();
      return null;
   }

   // $FF: synthetic method
   static Object R(long var0, b.b.b.a.i.k var2, SQLiteDatabase var3) {
      ContentValues var4 = new ContentValues();
      var4.put("next_request_ms", var0);
      String[] var5 = new String[]{var2.b(), String.valueOf(b.b.b.a.i.x.a.a(var2.d()))};
      if (var3.update("transport_contexts", var4, "backend_name = ? and priority = ?", var5) < 1) {
         var4.put("backend_name", var2.b());
         var4.put("priority", b.b.b.a.i.x.a.a(var2.d()));
         var3.insert("transport_contexts", (String)null, var4);
      }

      return null;
   }

   private Object U(b.b.b.a.i.u.h.a0.d var1, b.b.b.a.i.u.h.a0.b var2) {
      long var3 = this.c.a();

      while(true) {
         try {
            Object var6 = var1.a();
            return var6;
         } catch (SQLiteDatabaseLockedException var7) {
            if (this.c.a() >= var3 + (long)this.d.a()) {
               return var2.apply(var7);
            }

            SystemClock.sleep(50L);
         }
      }
   }

   private static String W(Iterable var0) {
      StringBuilder var1 = new StringBuilder("(");
      Iterator var2 = var0.iterator();

      while(var2.hasNext()) {
         var1.append(((h)var2.next()).b());
         if (var2.hasNext()) {
            var1.append(',');
         }
      }

      var1.append(')');
      return var1.toString();
   }

   private static Object Y(Cursor var0, b.b.b.a.i.u.h.a0.b var1) {
      Object var3;
      try {
         var3 = var1.apply(var0);
      } finally {
         var0.close();
      }

      return var3;
   }

   @Nullable
   private Long c(SQLiteDatabase var1, b.b.b.a.i.k var2) {
      StringBuilder var3 = new StringBuilder("backend_name = ? and priority = ?");
      String[] var4 = new String[]{var2.b(), String.valueOf(b.b.b.a.i.x.a.a(var2.d()))};
      ArrayList var5 = new ArrayList(Arrays.asList(var4));
      if (var2.c() != null) {
         var3.append(" and extras = ?");
         var5.add(Base64.encodeToString(var2.c(), 0));
      }

      return (Long)Y(var1.query("transport_contexts", new String[]{"_id"}, var3.toString(), (String[])var5.toArray(new String[0]), (String)null, (String)null, (String)null), w.a());
   }

   private Object e(b.b.b.a.i.u.h.a0.b var1) {
      SQLiteDatabase var2 = this.b();
      var2.beginTransaction();

      Object var4;
      try {
         var4 = var1.apply(var2);
         var2.setTransactionSuccessful();
      } finally {
         var2.endTransaction();
      }

      return var4;
   }

   // $FF: synthetic method
   static Integer f(long var0, SQLiteDatabase var2) {
      String[] var3 = new String[]{String.valueOf(var0)};
      return var2.delete("events", "timestamp_ms < ?", var3);
   }

   // $FF: synthetic method
   static Object g(SQLiteDatabase var0) {
      var0.beginTransaction();
      return null;
   }

   // $FF: synthetic method
   static Object t(Throwable var0) {
      throw new b.b.b.a.i.v.a("Timed out while trying to acquire the lock.", var0);
   }

   // $FF: synthetic method
   static SQLiteDatabase u(Throwable var0) {
      throw new b.b.b.a.i.v.a("Timed out while trying to open db.", var0);
   }

   // $FF: synthetic method
   static Long w(Cursor var0) {
      long var1;
      if (var0.moveToNext()) {
         var1 = var0.getLong(0);
      } else {
         var1 = 0L;
      }

      return var1;
   }

   // $FF: synthetic method
   static Long x(Cursor var0) {
      return !var0.moveToNext() ? null : var0.getLong(0);
   }

   @Nullable
   public h S(b.b.b.a.i.k var1, b.b.b.a.i.g var2) {
      Object[] var3 = new Object[]{var1.d(), var2.j(), var1.b()};
      b.b.b.a.i.s.a.b("SQLiteEventStore", "Storing event with priority=%s, name=%s for destination %s", var3);
      long var4 = (Long)this.e(v.a(this, var1, var2));
      return var4 < 1L ? null : new b(var4, var1, var2);
   }

   public long Z(b.b.b.a.i.k var1) {
      SQLiteDatabase var2 = this.b();
      String[] var3 = new String[]{var1.b(), String.valueOf(b.b.b.a.i.x.a.a(var1.d()))};
      return (Long)Y(var2.rawQuery("SELECT next_request_ms FROM transport_contexts WHERE backend_name = ? and priority = ?", var3), y.a());
   }

   public Object a(b.b.b.a.i.v.b.a var1) {
      SQLiteDatabase var2 = this.b();
      this.U(p.b(var2), q.a());

      Object var5;
      try {
         var5 = var1.execute();
         var2.setTransactionSuccessful();
      } finally {
         var2.endTransaction();
      }

      return var5;
   }

   @VisibleForTesting
   SQLiteDatabase b() {
      g0 var1 = this.a;
      var1.getClass();
      return (SQLiteDatabase)this.U(r.b(var1), u.a());
   }

   public boolean b0(b.b.b.a.i.k var1) {
      return (Boolean)this.e(z.a(this, var1));
   }

   public void c0(Iterable var1) {
      if (var1.iterator().hasNext()) {
         StringBuilder var2 = b.a.a.a.a.j("UPDATE events SET num_attempts = num_attempts + 1 WHERE _id in ");
         var2.append(W(var1));
         this.e(x.a(var2.toString()));
      }
   }

   public void close() {
      this.a.close();
   }

   public int j() {
      return (Integer)this.e(l.a(this.b.a() - this.d.b()));
   }

   public void k(Iterable var1) {
      if (var1.iterator().hasNext()) {
         StringBuilder var2 = b.a.a.a.a.j("DELETE FROM events WHERE _id in ");
         var2.append(W(var1));
         String var4 = var2.toString();
         this.b().compileStatement(var4).execute();
      }
   }

   public Iterable n(b.b.b.a.i.k var1) {
      return (Iterable)this.e(j.a(this, var1));
   }

   public void o(b.b.b.a.i.k var1, long var2) {
      this.e(i.a(var2, var1));
   }

   public Iterable r() {
      return (Iterable)this.e(k.a());
   }
}
