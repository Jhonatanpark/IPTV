package b.b.b.a.i;

import b.b.b.a.b;
import b.b.b.a.e;
import b.b.b.a.f;
import b.b.b.a.g;
import java.util.Set;

final class l implements g {
   private final Set a;
   private final k b;
   private final o c;

   l(Set var1, k var2, o var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public f a(String var1, Class var2, e var3) {
      return this.b(var1, var2, b.b.b.a.b.b("proto"), var3);
   }

   public f b(String var1, Class var2, b var3, e var4) {
      if (this.a.contains(var3)) {
         n var5 = new n(this.b, var1, var3, var4, this.c);
         return var5;
      } else {
         Object[] var6 = new Object[]{var3, this.a};
         throw new IllegalArgumentException(String.format("%s is not supported byt this factory. Supported encodings are: %s.", var6));
      }
   }
}
