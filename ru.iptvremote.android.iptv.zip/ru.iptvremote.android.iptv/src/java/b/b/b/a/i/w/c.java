package b.b.b.a.i.w;

import com.google.android.gms.cast.framework.f;

public final class c implements c.a.b {
   private static final c a = new c();

   public static c a() {
      return a;
   }

   public Object get() {
      d var1 = new d();
      f.q(var1, "Cannot return null from a non-@Nullable @Provides method");
      return var1;
   }
}
