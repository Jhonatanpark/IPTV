package b.b.b.a.i;

import b.b.b.a.i.u.e;
import c.a.b;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.q;
import d.a.a;

public final class r implements b {
   private final a a;
   private final a b;
   private final a c;
   private final a d;
   private final a e;

   public r(a var1, a var2, a var3, a var4, a var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }

   public Object get() {
      p var1 = new p((b.b.b.a.i.w.a)this.a.get(), (b.b.b.a.i.w.a)this.b.get(), (e)this.c.get(), (com.google.android.datatransport.runtime.scheduling.jobscheduling.m)this.d.get(), (q)this.e.get());
      return var1;
   }
}
