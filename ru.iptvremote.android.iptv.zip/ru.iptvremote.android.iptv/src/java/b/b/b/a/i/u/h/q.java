package b.b.b.a.i.u.h;

// $FF: synthetic class
final class q implements b.b.b.a.i.u.h.a0.b {
   private static final q a = new q();

   private q() {
   }

   public static b.b.b.a.i.u.h.a0.b a() {
      return a;
   }

   public Object apply(Object var1) {
      a0.t((Throwable)var1);
      throw null;
   }
}
