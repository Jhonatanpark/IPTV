package b.b.b.a.i.u.h;

// $FF: synthetic class
final class u implements b.b.b.a.i.u.h.a0.b {
   private static final u a = new u();

   private u() {
   }

   public static b.b.b.a.i.u.h.a0.b a() {
      return a;
   }

   public Object apply(Object var1) {
      a0.u((Throwable)var1);
      throw null;
   }
}
