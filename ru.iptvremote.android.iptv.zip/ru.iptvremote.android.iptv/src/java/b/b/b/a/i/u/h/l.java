package b.b.b.a.i.u.h;

import android.database.sqlite.SQLiteDatabase;

// $FF: synthetic class
final class l implements b.b.b.a.i.u.h.a0.b {
   private final long a;

   private l(long var1) {
      this.a = var1;
   }

   public static b.b.b.a.i.u.h.a0.b a(long var0) {
      return new l(var0);
   }

   public Object apply(Object var1) {
      return a0.f(this.a, (SQLiteDatabase)var1);
   }
}
