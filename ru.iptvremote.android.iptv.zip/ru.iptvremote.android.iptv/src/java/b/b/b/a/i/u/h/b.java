package b.b.b.a.i.u.h;

final class b extends h {
   private final long a;
   private final b.b.b.a.i.k b;
   private final b.b.b.a.i.g c;

   b(long var1, b.b.b.a.i.k var3, b.b.b.a.i.g var4) {
      this.a = var1;
      if (var3 != null) {
         this.b = var3;
         if (var4 != null) {
            this.c = var4;
         } else {
            throw new NullPointerException("Null event");
         }
      } else {
         throw new NullPointerException("Null transportContext");
      }
   }

   public b.b.b.a.i.g a() {
      return this.c;
   }

   public long b() {
      return this.a;
   }

   public b.b.b.a.i.k c() {
      return this.b;
   }

   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else if (var1 instanceof h) {
         h var2 = (h)var1;
         if (this.a == ((b)var2).a) {
            b.b.b.a.i.k var3 = this.b;
            b var4 = (b)var2;
            if (var3.equals(var4.b) && this.c.equals(var4.c)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public int hashCode() {
      long var1 = this.a;
      return 1000003 * (1000003 * (1000003 ^ (int)(var1 ^ var1 >>> 32)) ^ this.b.hashCode()) ^ this.c.hashCode();
   }

   public String toString() {
      StringBuilder var1 = b.a.a.a.a.j("PersistedEvent{id=");
      var1.append(this.a);
      var1.append(", transportContext=");
      var1.append(this.b);
      var1.append(", event=");
      var1.append(this.c);
      var1.append("}");
      return var1.toString();
   }
}
