package b.b.b.a.i.u;

import b.b.b.a.i.k;
import b.b.b.a.i.v.b.a;

// $FF: synthetic class
final class b implements a {
   private final c a;
   private final k b;
   private final b.b.b.a.i.g c;

   private b(c var1, k var2, b.b.b.a.i.g var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public static a a(c var0, k var1, b.b.b.a.i.g var2) {
      return new b(var0, var1, var2);
   }

   public Object execute() {
      b.b.b.a.i.u.c.b(this.a, this.b, this.c);
      return null;
   }
}
