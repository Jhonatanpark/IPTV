package b.b.b.a.i;

// $FF: synthetic class
final class m implements b.b.b.a.h {
   private static final m a = new m();

   private m() {
   }

   public static b.b.b.a.h b() {
      return a;
   }

   public void a(Exception var1) {
   }
}
