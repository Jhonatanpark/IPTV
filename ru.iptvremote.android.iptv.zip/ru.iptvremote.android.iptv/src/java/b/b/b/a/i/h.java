package b.b.b.a.i;

import c.a.b;
import com.google.android.gms.cast.framework.f;
import java.util.concurrent.Executors;

public final class h implements b {
   private static final h a = new h();

   public static h a() {
      return a;
   }

   public Object get() {
      i var1 = new i(Executors.newSingleThreadExecutor());
      f.q(var1, "Cannot return null from a non-@Nullable @Provides method");
      return var1;
   }
}
