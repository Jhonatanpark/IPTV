package b.b.b.a.i.u.h;

import android.database.Cursor;

// $FF: synthetic class
final class w implements b.b.b.a.i.u.h.a0.b {
   private static final w a = new w();

   private w() {
   }

   public static b.b.b.a.i.u.h.a0.b a() {
      return a;
   }

   public Object apply(Object var1) {
      return a0.x((Cursor)var1);
   }
}
