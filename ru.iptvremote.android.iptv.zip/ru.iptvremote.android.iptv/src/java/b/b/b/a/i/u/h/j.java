package b.b.b.a.i.u.h;

import android.database.sqlite.SQLiteDatabase;

// $FF: synthetic class
final class j implements b.b.b.a.i.u.h.a0.b {
   private final a0 a;
   private final b.b.b.a.i.k b;

   private j(a0 var1, b.b.b.a.i.k var2) {
      this.a = var1;
      this.b = var2;
   }

   public static b.b.b.a.i.u.h.a0.b a(a0 var0, b.b.b.a.i.k var1) {
      return new j(var0, var1);
   }

   public Object apply(Object var1) {
      return a0.F(this.a, this.b, (SQLiteDatabase)var1);
   }
}
