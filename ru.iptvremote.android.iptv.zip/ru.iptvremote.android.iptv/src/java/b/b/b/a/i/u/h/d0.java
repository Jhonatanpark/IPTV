package b.b.b.a.i.u.h;

import android.database.sqlite.SQLiteDatabase;

// $FF: synthetic class
final class d0 implements b.b.b.a.i.u.h.g0.a {
   private static final d0 a = new d0();

   private d0() {
   }

   public static b.b.b.a.i.u.h.g0.a b() {
      return a;
   }

   public void a(SQLiteDatabase var1) {
      g0.b(var1);
   }
}
