package b.b.b.a.i.u;

import com.google.android.datatransport.runtime.backends.e;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.s;
import d.a.a;
import java.util.concurrent.Executor;

public final class d implements c.a.b {
   private final a a;
   private final a b;
   private final a c;
   private final a d;
   private final a e;

   public d(a var1, a var2, a var3, a var4, a var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }

   public Object get() {
      c var1 = new c((Executor)this.a.get(), (e)this.b.get(), (s)this.c.get(), (b.b.b.a.i.u.h.c)this.d.get(), (b.b.b.a.i.v.b)this.e.get());
      return var1;
   }
}
