package b.b.b.a.i.u.h;

import android.database.Cursor;

// $FF: synthetic class
final class t implements b.b.b.a.i.u.h.a0.b {
   private static final t a = new t();

   private t() {
   }

   public static b.b.b.a.i.u.h.a0.b a() {
      return a;
   }

   public Object apply(Object var1) {
      return ((Cursor)var1).moveToNext();
   }
}
