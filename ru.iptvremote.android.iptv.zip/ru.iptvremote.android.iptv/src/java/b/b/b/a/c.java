package b.b.b.a;

import androidx.annotation.Nullable;
import com.google.auto.value.AutoValue;

@AutoValue
public abstract class c {
   public static c d(int var0, Object var1) {
      return new a(var0, var1, d.a);
   }

   public static c e(int var0, Object var1) {
      return new a(var0, var1, d.b);
   }

   public static c f(Object var0) {
      return new a((Integer)null, var0, d.c);
   }

   @Nullable
   public abstract Integer a();

   public abstract Object b();

   public abstract d c();
}
