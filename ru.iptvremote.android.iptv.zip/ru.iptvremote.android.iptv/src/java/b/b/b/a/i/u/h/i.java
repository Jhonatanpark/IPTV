package b.b.b.a.i.u.h;

import android.database.sqlite.SQLiteDatabase;

// $FF: synthetic class
final class i implements b.b.b.a.i.u.h.a0.b {
   private final long a;
   private final b.b.b.a.i.k b;

   private i(long var1, b.b.b.a.i.k var3) {
      this.a = var1;
      this.b = var3;
   }

   public static b.b.b.a.i.u.h.a0.b a(long var0, b.b.b.a.i.k var2) {
      return new i(var0, var2);
   }

   public Object apply(Object var1) {
      a0.R(this.a, this.b, (SQLiteDatabase)var1);
      return null;
   }
}
