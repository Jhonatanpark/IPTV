package b.b.b.b.d.c;

final class c3 implements t6 {
   static final t6 a = new c3();

   private c3() {
   }
}
