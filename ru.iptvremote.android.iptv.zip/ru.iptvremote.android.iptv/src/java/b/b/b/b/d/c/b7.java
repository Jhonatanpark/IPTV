package b.b.b.b.d.c;

public final class b7 extends f7 {
   public static x7 e() {
      throw new NoSuchMethodError();
   }

   public final boolean equals(Object var1) {
      throw new NoSuchMethodError();
   }

   public final int hashCode() {
      throw new NoSuchMethodError();
   }

   public final String toString() {
      throw new NoSuchMethodError();
   }
}
