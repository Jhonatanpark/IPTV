package b.b.b.b.d.a;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;

public abstract class c extends Binder implements b, IInterface {
   public static b t0(IBinder var0) {
      IInterface var1 = var0.queryLocalInterface("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
      return (b)(var1 instanceof b ? (b)var1 : new d(var0));
   }
}
