package b.b.b.b.d.c;

import b.b.b.b.d.c.o6.d;

public final class a5 extends o6 implements z7 {
   private static volatile g8 zzafw;
   private static final a5 zzbgq;
   private int zzafi;
   private int zzbbo;
   private int zzbff;
   private int zzbft;
   private int zzbgn;
   private boolean zzbgo;
   private boolean zzbgp;

   static {
      a5 var0 = new a5();
      zzbgq = var0;
      o6.j(a5.class, var0);
   }

   private a5() {
   }

   protected final Object h(d var1, Object var2, Object var3) {
      switch(c5.a[var1.ordinal()]) {
      case 1:
         return new a5();
      case 2:
         return new a5.a((c5)null);
      case 3:
         Object[] var4 = new Object[]{"zzafi", "zzbft", "zzbgn", u2.a, "zzbgo", "zzbgp", "zzbff", e2.a, "zzbbo"};
         return new n8(zzbgq, "\u0001\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001\u0004\u0000\u0002\f\u0001\u0003\u0007\u0002\u0004\u0007\u0003\u0005\f\u0004\u0006\u0006\u0005", var4);
      case 4:
         return zzbgq;
      case 5:
         g8 var5 = zzafw;
         if (var5 == null) {
            Class var8 = a5.class;
            synchronized(a5.class){}

            Throwable var10000;
            boolean var10001;
            label261: {
               Object var7;
               try {
                  var7 = zzafw;
               } catch (Throwable var28) {
                  var10000 = var28;
                  var10001 = false;
                  break label261;
               }

               if (var7 == null) {
                  try {
                     var7 = new b.b.b.b.d.c.o6.c(zzbgq);
                     zzafw = (g8)var7;
                  } catch (Throwable var27) {
                     var10000 = var27;
                     var10001 = false;
                     break label261;
                  }
               }

               label246:
               try {
                  return var7;
               } catch (Throwable var26) {
                  var10000 = var26;
                  var10001 = false;
                  break label246;
               }
            }

            while(true) {
               Throwable var6 = var10000;

               try {
                  throw var6;
               } catch (Throwable var25) {
                  var10000 = var25;
                  var10001 = false;
                  continue;
               }
            }
         } else {
            return var5;
         }
      case 6:
         return 1;
      case 7:
         return null;
      default:
         throw new UnsupportedOperationException();
      }
   }

   public static final class a extends o6.a implements z7 {
      a(c5 var1) {
         super(a5.zzbgq);
      }
   }
}
