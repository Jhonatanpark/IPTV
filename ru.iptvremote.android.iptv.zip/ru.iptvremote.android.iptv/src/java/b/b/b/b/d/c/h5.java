package b.b.b.b.d.c;

import b.a.a.a.a;
import java.io.IOException;

public abstract class h5 implements x7 {
   protected int zzbim = 0;

   public final n5 c() {
      try {
         t5 var5 = n5.h(this.d());
         this.b(var5.b());
         n5 var6 = var5.a();
         return var6;
      } catch (IOException var7) {
         String var2 = this.getClass().getName();
         StringBuilder var3 = a.i(62 + var2.length() + "ByteString".length(), "Serializing ", var2, " to a ", "ByteString");
         var3.append(" threw an IOException (should never happen).");
         throw new RuntimeException(var3.toString(), var7);
      }
   }

   void e(int var1) {
      throw new UnsupportedOperationException();
   }

   int g() {
      throw new UnsupportedOperationException();
   }
}
