package b.b.b.b.d.c;

import android.view.View;
import androidx.annotation.VisibleForTesting;
import com.google.android.gms.cast.framework.media.d.e;
import com.google.android.gms.cast.framework.media.f.a;
import com.google.android.gms.cast.framework.media.f.d;

public final class a0 extends a implements e {
   private final View c;
   private final d d;

   public a0(View var1, d var2) {
      this.c = var1;
      this.d = var2;
      var1.setEnabled(false);
   }

   @VisibleForTesting
   private final void g() {
      boolean var2;
      View var3;
      label31: {
         com.google.android.gms.cast.framework.media.d var1 = this.b();
         var2 = true;
         if (var1 != null && var1.o() && !var1.u()) {
            if (!var1.q()) {
               var3 = this.c;
               break label31;
            }

            View var4 = this.c;
            if (var1.W()) {
               d var5 = this.d;
               if (!var5.c((long)var5.f() + var5.i())) {
                  var3 = var4;
                  break label31;
               }
            }

            var3 = var4;
         } else {
            var3 = this.c;
         }

         var2 = false;
      }

      var3.setEnabled(var2);
   }

   public final void a(long var1, long var3) {
      this.g();
   }

   public final void c() {
      this.g();
   }

   public final void d() {
      this.c.setEnabled(false);
   }

   public final void e(com.google.android.gms.cast.framework.c var1) {
      super.e(var1);
      if (this.b() != null) {
         this.b().c(this, 1000L);
      }

      this.g();
   }

   public final void f() {
      if (this.b() != null) {
         this.b().D(this);
      }

      this.c.setEnabled(false);
      super.f();
      this.g();
   }
}
