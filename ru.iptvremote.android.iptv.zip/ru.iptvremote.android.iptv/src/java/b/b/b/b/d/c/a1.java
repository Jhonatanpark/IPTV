package b.b.b.b.d.c;

import android.os.Parcel;
import android.view.Surface;

public abstract class a1 extends a implements b1 {
   public a1() {
      super("com.google.android.gms.cast.remote_display.ICastRemoteDisplayCallbacks");
   }

   protected final boolean t0(int var1, Parcel var2, Parcel var3, int var4) {
      if (var1 != 1) {
         if (var1 != 2) {
            if (var1 != 3) {
               if (var1 != 4) {
                  return false;
               }

               this.U();
               throw null;
            }

            this.K5();
         } else {
            this.c8(var2.readInt());
         }

         var3.writeNoException();
         return true;
      } else {
         this.C4(var2.readInt(), var2.readInt(), (Surface)v0.b(var2, Surface.CREATOR));
         throw null;
      }
   }
}
