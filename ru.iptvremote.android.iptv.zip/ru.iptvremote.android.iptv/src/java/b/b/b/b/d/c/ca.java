package b.b.b.b.d.c;

// $FF: synthetic class
final class ca implements y9 {
   static final y9 a = new ca();

   private ca() {
   }
}
