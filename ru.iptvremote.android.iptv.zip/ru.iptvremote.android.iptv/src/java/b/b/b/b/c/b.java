package b.b.b.b.c;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import b.b.b.b.b.a$a;

public abstract class b extends b.b.b.b.d.e.b implements a {
   public b() {
      super("com.google.android.gms.flags.IFlagProvider");
   }

   public static a asInterface(IBinder var0) {
      if (var0 == null) {
         return null;
      } else {
         IInterface var1 = var0.queryLocalInterface("com.google.android.gms.flags.IFlagProvider");
         return (a)(var1 instanceof a ? (a)var1 : new c(var0));
      }
   }

   protected final boolean t0(int var1, Parcel var2, Parcel var3, int var4) {
      if (var1 != 1) {
         if (var1 != 2) {
            if (var1 != 3) {
               if (var1 != 4) {
                  if (var1 != 5) {
                     return false;
                  } else {
                     String var9 = this.getStringFlagValue(var2.readString(), var2.readString(), var2.readInt());
                     var3.writeNoException();
                     var3.writeString(var9);
                     return true;
                  }
               } else {
                  long var7 = this.getLongFlagValue(var2.readString(), var2.readLong(), var2.readInt());
                  var3.writeNoException();
                  var3.writeLong(var7);
                  return true;
               }
            } else {
               int var6 = this.getIntFlagValue(var2.readString(), var2.readInt(), var2.readInt());
               var3.writeNoException();
               var3.writeInt(var6);
               return true;
            }
         } else {
            byte var5 = this.getBooleanFlagValue(var2.readString(), b.b.b.b.d.e.c.c(var2), var2.readInt());
            var3.writeNoException();
            var3.writeInt(var5);
            return true;
         }
      } else {
         this.init(a$a.V1(var2.readStrongBinder()));
         var3.writeNoException();
         return true;
      }
   }
}
