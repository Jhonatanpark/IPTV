package b.b.b.b.d.c;

final class c2 implements t6 {
   static final t6 a = new c2();

   private c2() {
   }
}
