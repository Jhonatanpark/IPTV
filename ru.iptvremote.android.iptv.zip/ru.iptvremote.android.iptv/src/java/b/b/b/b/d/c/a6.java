package b.b.b.b.d.c;

import b.b.b.b.d.c.a6.a;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class a6 extends o5 {
   private static final Logger b = Logger.getLogger(a6.class.getName());
   private static final boolean c = h9.u();
   c6 a;

   private a6() {
   }

   a6(z5 var1) {
   }

   public static int A(int var0, String var1) {
      return k(var0) + i(var1);
   }

   public static int B(x7 var0) {
      int var1 = var0.d();
      return var1 + m(var1);
   }

   public static int D() {
      return 8;
   }

   public static int E(int var0, long var1) {
      return k(var0) + Y(var1);
   }

   @Deprecated
   public static int F(x7 var0) {
      return var0.d();
   }

   public static int G(int var0, long var1) {
      return k(var0) + Y(var1);
   }

   public static int I(int var0, long var1) {
      return k(var0) + Y(c0(var1));
   }

   public static int J(int var0) {
      return 8 + k(var0);
   }

   public static int L(int var0) {
      return 8 + k(var0);
   }

   public static int M(int var0, int var1) {
      return k(var0) + l(var1);
   }

   public static int P(int var0, int var1) {
      return k(var0) + m(var1);
   }

   public static int Q(int var0, int var1) {
      return k(var0) + m(q(var1));
   }

   public static int S(int var0) {
      return 4 + k(var0);
   }

   public static int U(int var0) {
      return 4 + k(var0);
   }

   public static int W(int var0, int var1) {
      return k(var0) + l(var1);
   }

   public static int X() {
      return 1;
   }

   public static int Y(long var0) {
      if ((-128L & var0) == 0L) {
         return 1;
      } else if (var0 < 0L) {
         return 10;
      } else {
         int var2;
         if ((-34359738368L & var0) != 0L) {
            var2 = 6;
            var0 >>>= 28;
         } else {
            var2 = 2;
         }

         if ((-2097152L & var0) != 0L) {
            var2 += 2;
            var0 >>>= 14;
         }

         if ((var0 & -16384L) != 0L) {
            ++var2;
         }

         return var2;
      }
   }

   public static int Z(long var0) {
      return Y(c0(var0));
   }

   public static int a0() {
      return 8;
   }

   public static int b(f7 var0) {
      int var1 = var0.a();
      return var1 + m(var1);
   }

   public static int b0() {
      return 8;
   }

   static int c(x7 var0, m8 var1) {
      h5 var2 = (h5)var0;
      int var3 = var2.g();
      if (var3 == -1) {
         var3 = var1.f(var2);
         var2.e(var3);
      }

      return var3 + m(var3);
   }

   private static long c0(long var0) {
      return var0 << 1 ^ var0 >> 63;
   }

   public static a6 d(byte[] var0) {
      return new a6.b(var0, var0.length);
   }

   public static int i(String var0) {
      int var1;
      try {
         var1 = k9.a(var0);
      } catch (o9 var2) {
         var1 = var0.getBytes(p6.a).length;
      }

      return var1 + m(var1);
   }

   public static int k(int var0) {
      return m(var0 << 3);
   }

   public static int l(int var0) {
      return var0 >= 0 ? m(var0) : 10;
   }

   public static int m(int var0) {
      if ((var0 & -128) == 0) {
         return 1;
      } else if ((var0 & -16384) == 0) {
         return 2;
      } else if ((-2097152 & var0) == 0) {
         return 3;
      } else {
         return (var0 & -268435456) == 0 ? 4 : 5;
      }
   }

   public static int n(int var0) {
      return m(q(var0));
   }

   public static int o() {
      return 4;
   }

   public static int p() {
      return 4;
   }

   private static int q(int var0) {
      return var0 << 1 ^ var0 >> 31;
   }

   public static int r() {
      return 4;
   }

   public static int s(int var0) {
      return 4 + k(var0);
   }

   public static int t(n5 var0) {
      int var1 = var0.size();
      return var1 + m(var1);
   }

   public static int u(byte[] var0) {
      int var1 = var0.length;
      return var1 + m(var1);
   }

   public static int w(int var0) {
      return 8 + k(var0);
   }

   public static int x(int var0) {
      return 1 + k(var0);
   }

   public static int y(int var0, n5 var1) {
      int var2 = k(var0);
      int var3 = var1.size();
      return var2 + var3 + m(var3);
   }

   @Deprecated
   static int z(int var0, x7 var1, m8 var2) {
      int var3 = k(var0) << 1;
      h5 var4 = (h5)var1;
      int var5 = var4.g();
      if (var5 == -1) {
         var5 = var2.f(var4);
         var4.e(var5);
      }

      return var3 + var5;
   }

   public abstract void C(byte var1);

   public abstract void H(int var1, int var2);

   public final void K(int var1, int var2) {
      int var3 = q(var2);
      a6.b var4 = (a6.b)this;
      var4.g(0 | var1 << 3);
      var4.g(var3);
   }

   public abstract int N();

   public abstract void R(long var1);

   public final void T(long var1) {
      this.R(c0(var1));
   }

   public abstract void V(long var1);

   final void e(String var1, o9 var2) {
      b.logp(Level.WARNING, "com.google.protobuf.CodedOutputStream", "inefficientWriteStringNoTag", "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", var2);
      byte[] var3 = var1.getBytes(p6.a);

      try {
         this.g(var3.length);
         this.a(var3, 0, var3.length);
      } catch (IndexOutOfBoundsException var6) {
         throw new a(var6);
      } catch (a var7) {
         throw var7;
      }
   }

   public abstract void f(int var1);

   public abstract void g(int var1);

   public final void h(int var1) {
      this.g(q(var1));
   }

   public abstract void j(int var1);

   public final void v(int var1, long var2) {
      long var4 = c0(var2);
      a6.b var6 = (a6.b)this;
      var6.g(0 | var1 << 3);
      var6.R(var4);
   }

   static final class b extends a6 {
      private final byte[] d;
      private final int e;
      private int f;

      b(byte[] var1, int var2) {
         super((z5)null);
         int var3 = var2 | 0;
         int var4 = var1.length;
         int var5 = var2 + 0;
         if ((var3 | var4 - var5) >= 0) {
            this.d = var1;
            this.f = 0;
            this.e = var5;
         } else {
            Object[] var6 = new Object[]{var1.length, 0, var2};
            throw new IllegalArgumentException(String.format("Array range is invalid. Buffer.length=%d, offset=%d, length=%d", var6));
         }
      }

      private final void d0(byte[] var1, int var2, int var3) {
         try {
            System.arraycopy(var1, var2, this.d, this.f, var3);
            this.f += var3;
         } catch (IndexOutOfBoundsException var6) {
            Object[] var5 = new Object[]{this.f, this.e, var3};
            throw new a(String.format("Pos: %d, limit: %d, len: %d", var5), var6);
         }
      }

      public final void C(byte var1) {
         try {
            byte[] var4 = this.d;
            int var5 = this.f++;
            var4[var5] = var1;
         } catch (IndexOutOfBoundsException var6) {
            Object[] var3 = new Object[]{this.f, this.e, 1};
            throw new a(String.format("Pos: %d, limit: %d, len: %d", var3), var6);
         }
      }

      public final void H(int var1, int var2) {
         this.g(0 | var1 << 3);
         if (var2 >= 0) {
            this.g(var2);
         } else {
            this.R((long)var2);
         }
      }

      public final int N() {
         return this.e - this.f;
      }

      public final void R(long var1) {
         if (a6.c && this.N() >= 10) {
            while((var1 & -128L) != 0L) {
               byte[] var10 = this.d;
               int var11 = this.f++;
               h9.i(var10, (long)var11, (byte)(128 | 127 & (int)var1));
               var1 >>>= 7;
            }

            byte[] var12 = this.d;
            int var13 = this.f++;
            h9.i(var12, (long)var13, (byte)((int)var1));
         } else {
            while(true) {
               IndexOutOfBoundsException var10000;
               boolean var10001;
               if ((var1 & -128L) == 0L) {
                  try {
                     byte[] var8 = this.d;
                     int var9 = this.f++;
                     var8[var9] = (byte)((int)var1);
                     return;
                  } catch (IndexOutOfBoundsException var14) {
                     var10000 = var14;
                     var10001 = false;
                  }
               } else {
                  label34: {
                     try {
                        byte[] var6 = this.d;
                        int var7 = this.f++;
                        var6[var7] = (byte)(128 | 127 & (int)var1);
                     } catch (IndexOutOfBoundsException var15) {
                        var10000 = var15;
                        var10001 = false;
                        break label34;
                     }

                     var1 >>>= 7;
                     continue;
                  }
               }

               IndexOutOfBoundsException var3 = var10000;
               Object[] var4 = new Object[]{this.f, this.e, 1};
               a var5 = new a(String.format("Pos: %d, limit: %d, len: %d", var4), var3);
               throw var5;
            }
         }
      }

      public final void V(long var1) {
         IndexOutOfBoundsException var10000;
         label69: {
            byte[] var5;
            int var6;
            boolean var10001;
            try {
               var5 = this.d;
               var6 = this.f;
            } catch (IndexOutOfBoundsException var28) {
               var10000 = var28;
               var10001 = false;
               break label69;
            }

            int var7 = var6 + 1;

            byte[] var8;
            try {
               this.f = var7;
               var5[var6] = (byte)((int)var1);
               var8 = this.d;
            } catch (IndexOutOfBoundsException var27) {
               var10000 = var27;
               var10001 = false;
               break label69;
            }

            int var9 = var7 + 1;

            byte[] var10;
            try {
               this.f = var9;
               var8[var7] = (byte)((int)(var1 >> 8));
               var10 = this.d;
            } catch (IndexOutOfBoundsException var26) {
               var10000 = var26;
               var10001 = false;
               break label69;
            }

            int var11 = var9 + 1;

            byte[] var12;
            try {
               this.f = var11;
               var10[var9] = (byte)((int)(var1 >> 16));
               var12 = this.d;
            } catch (IndexOutOfBoundsException var25) {
               var10000 = var25;
               var10001 = false;
               break label69;
            }

            int var13 = var11 + 1;

            byte[] var14;
            try {
               this.f = var13;
               var12[var11] = (byte)((int)(var1 >> 24));
               var14 = this.d;
            } catch (IndexOutOfBoundsException var24) {
               var10000 = var24;
               var10001 = false;
               break label69;
            }

            int var15 = var13 + 1;

            byte[] var16;
            try {
               this.f = var15;
               var14[var13] = (byte)((int)(var1 >> 32));
               var16 = this.d;
            } catch (IndexOutOfBoundsException var23) {
               var10000 = var23;
               var10001 = false;
               break label69;
            }

            int var17 = var15 + 1;

            byte[] var18;
            try {
               this.f = var17;
               var16[var15] = (byte)((int)(var1 >> 40));
               var18 = this.d;
            } catch (IndexOutOfBoundsException var22) {
               var10000 = var22;
               var10001 = false;
               break label69;
            }

            int var19 = var17 + 1;

            try {
               this.f = var19;
               var18[var17] = (byte)((int)(var1 >> 48));
               byte[] var20 = this.d;
               this.f = var19 + 1;
               var20[var19] = (byte)((int)(var1 >> 56));
               return;
            } catch (IndexOutOfBoundsException var21) {
               var10000 = var21;
               var10001 = false;
            }
         }

         IndexOutOfBoundsException var3 = var10000;
         Object[] var4 = new Object[]{this.f, this.e, 1};
         throw new a(String.format("Pos: %d, limit: %d, len: %d", var4), var3);
      }

      public final void a(byte[] var1, int var2, int var3) {
         this.d0(var1, var2, var3);
      }

      public final void e0(int var1, n5 var2) {
         this.g(2 | var1 << 3);
         this.f0(var2);
      }

      public final void f(int var1) {
         if (var1 >= 0) {
            this.g(var1);
         } else {
            this.R((long)var1);
         }
      }

      public final void f0(n5 var1) {
         this.g(var1.size());
         u5 var2 = (u5)var1;
         this.a(var2.d, var2.n(), var2.size());
      }

      public final void g(int var1) {
         if (a6.c && !k5.a() && this.N() >= 5) {
            if ((var1 & -128) == 0) {
               byte[] var29 = this.d;
               int var30 = this.f++;
               h9.i(var29, (long)var30, (byte)var1);
            } else {
               byte[] var9 = this.d;
               int var10 = this.f++;
               h9.i(var9, (long)var10, (byte)(var1 | 128));
               int var11 = var1 >>> 7;
               if ((var11 & -128) == 0) {
                  byte[] var27 = this.d;
                  int var28 = this.f++;
                  h9.i(var27, (long)var28, (byte)var11);
               } else {
                  byte[] var12 = this.d;
                  int var13 = this.f++;
                  h9.i(var12, (long)var13, (byte)(var11 | 128));
                  int var14 = var11 >>> 7;
                  if ((var14 & -128) == 0) {
                     byte[] var25 = this.d;
                     int var26 = this.f++;
                     h9.i(var25, (long)var26, (byte)var14);
                  } else {
                     byte[] var15 = this.d;
                     int var16 = this.f++;
                     h9.i(var15, (long)var16, (byte)(var14 | 128));
                     int var17 = var14 >>> 7;
                     if ((var17 & -128) == 0) {
                        byte[] var23 = this.d;
                        int var24 = this.f++;
                        h9.i(var23, (long)var24, (byte)var17);
                     } else {
                        byte[] var18 = this.d;
                        int var19 = this.f++;
                        h9.i(var18, (long)var19, (byte)(var17 | 128));
                        int var20 = var17 >>> 7;
                        byte[] var21 = this.d;
                        int var22 = this.f++;
                        h9.i(var21, (long)var22, (byte)var20);
                     }
                  }
               }
            }
         } else {
            while(true) {
               IndexOutOfBoundsException var10000;
               boolean var10001;
               if ((var1 & -128) == 0) {
                  try {
                     byte[] var7 = this.d;
                     int var8 = this.f++;
                     var7[var8] = (byte)var1;
                     return;
                  } catch (IndexOutOfBoundsException var31) {
                     var10000 = var31;
                     var10001 = false;
                  }
               } else {
                  label45: {
                     try {
                        byte[] var5 = this.d;
                        int var6 = this.f++;
                        var5[var6] = (byte)(128 | var1 & 127);
                     } catch (IndexOutOfBoundsException var32) {
                        var10000 = var32;
                        var10001 = false;
                        break label45;
                     }

                     var1 >>>= 7;
                     continue;
                  }
               }

               IndexOutOfBoundsException var2 = var10000;
               Object[] var3 = new Object[]{this.f, this.e, 1};
               a var4 = new a(String.format("Pos: %d, limit: %d, len: %d", var3), var2);
               throw var4;
            }
         }
      }

      public final void g0(String var1) {
         int var2 = this.f;

         o9 var15;
         label38: {
            IndexOutOfBoundsException var10000;
            label37: {
               int var5;
               int var6;
               boolean var10001;
               try {
                  var5 = a6.m(3 * var1.length());
                  var6 = a6.m(var1.length());
               } catch (o9 var13) {
                  var15 = var13;
                  var10001 = false;
                  break label38;
               } catch (IndexOutOfBoundsException var14) {
                  var10000 = var14;
                  var10001 = false;
                  break label37;
               }

               if (var6 == var5) {
                  int var7 = var2 + var6;

                  try {
                     this.f = var7;
                     int var8 = k9.b(var1, this.d, var7, this.N());
                     this.f = var2;
                     this.g(var8 - var2 - var6);
                     this.f = var8;
                     return;
                  } catch (o9 var9) {
                     var15 = var9;
                     var10001 = false;
                     break label38;
                  } catch (IndexOutOfBoundsException var10) {
                     var10000 = var10;
                     var10001 = false;
                  }
               } else {
                  try {
                     this.g(k9.a(var1));
                     this.f = k9.b(var1, this.d, this.f, this.N());
                     return;
                  } catch (o9 var11) {
                     var15 = var11;
                     var10001 = false;
                     break label38;
                  } catch (IndexOutOfBoundsException var12) {
                     var10000 = var12;
                     var10001 = false;
                  }
               }
            }

            IndexOutOfBoundsException var4 = var10000;
            throw new a(var4);
         }

         o9 var3 = var15;
         this.f = var2;
         this.e(var1, var3);
      }

      public final void h0(int var1, int var2) {
         this.g(var2 | var1 << 3);
      }

      public final void i0(int var1, int var2) {
         this.g(0 | var1 << 3);
         this.g(var2);
      }

      public final void j(int var1) {
         IndexOutOfBoundsException var10000;
         label37: {
            byte[] var4;
            int var5;
            boolean var10001;
            try {
               var4 = this.d;
               var5 = this.f;
            } catch (IndexOutOfBoundsException var15) {
               var10000 = var15;
               var10001 = false;
               break label37;
            }

            int var6 = var5 + 1;

            byte[] var7;
            try {
               this.f = var6;
               var4[var5] = (byte)var1;
               var7 = this.d;
            } catch (IndexOutOfBoundsException var14) {
               var10000 = var14;
               var10001 = false;
               break label37;
            }

            int var8 = var6 + 1;

            byte[] var9;
            try {
               this.f = var8;
               var7[var6] = (byte)(var1 >> 8);
               var9 = this.d;
            } catch (IndexOutOfBoundsException var13) {
               var10000 = var13;
               var10001 = false;
               break label37;
            }

            int var10 = var8 + 1;

            try {
               this.f = var10;
               var9[var8] = (byte)(var1 >> 16);
               byte[] var11 = this.d;
               this.f = var10 + 1;
               var11[var10] = (byte)(var1 >>> 24);
               return;
            } catch (IndexOutOfBoundsException var12) {
               var10000 = var12;
               var10001 = false;
            }
         }

         IndexOutOfBoundsException var2 = var10000;
         Object[] var3 = new Object[]{this.f, this.e, 1};
         throw new a(String.format("Pos: %d, limit: %d, len: %d", var3), var2);
      }
   }
}
