package b.b.b.b.d.c;

public interface x7 extends z7 {
   void b(a6 var1);

   n5 c();

   int d();

   a8 f();
}
