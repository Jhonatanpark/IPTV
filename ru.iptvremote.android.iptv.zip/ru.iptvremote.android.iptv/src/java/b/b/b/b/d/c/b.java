package b.b.b.b.d.c;

import android.content.Context;
import com.google.android.gms.cast.framework.CastOptions;
import com.google.android.gms.cast.framework.h;
import com.google.android.gms.cast.framework.k;

public final class b extends k {
   private final CastOptions d;
   private final i e;
   private final t1 f;

   public b(Context var1, CastOptions var2, i var3) {
      String var4;
      if (var2.n0().isEmpty()) {
         var4 = com.google.android.gms.cast.b.a(var2.l0());
      } else {
         var4 = com.google.android.gms.cast.b.b(var2.l0(), var2.n0());
      }

      super(var1, var4);
      this.d = var2;
      this.e = var3;
      this.f = new z9(var1);
   }

   public final h a(String var1) {
      com.google.android.gms.cast.framework.c var2 = new com.google.android.gms.cast.framework.c(this.c(), this.b(), var1, this.d, this.f, new com.google.android.gms.cast.framework.media.internal.i(this.c(), this.d, this.e));
      return var2;
   }

   public final boolean d() {
      return this.d.m0();
   }
}
