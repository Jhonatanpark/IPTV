package b.b.b.b.d.c;

import android.graphics.Bitmap;

final class c0 implements com.google.android.gms.cast.framework.media.internal.c {
   // $FF: synthetic field
   private final d0 a;

   c0(d0 var1) {
      this.a = var1;
   }

   public final void a(Bitmap var1) {
      if (var1 != null) {
         if (d0.g(this.a) != null) {
            d0.g(this.a).setVisibility(4);
         }

         d0.h(this.a).setVisibility(0);
         d0.h(this.a).setImageBitmap(var1);
      }

   }
}
