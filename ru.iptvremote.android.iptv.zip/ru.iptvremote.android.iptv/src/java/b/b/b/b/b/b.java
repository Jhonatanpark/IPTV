package b.b.b.b.b;

import android.os.IBinder;
import java.lang.reflect.Field;

public final class b extends a$a {
   private final Object a;

   private b(Object var1) {
      this.a = var1;
   }

   public static Object c2(b.b.b.b.b.a var0) {
      if (var0 instanceof b) {
         return ((b)var0).a;
      } else {
         IBinder var1 = var0.asBinder();
         Field[] var2 = var1.getClass().getDeclaredFields();
         Field var3 = null;
         int var4 = var2.length;
         int var5 = 0;

         int var6;
         for(var6 = 0; var5 < var4; ++var5) {
            Field var11 = var2[var5];
            if (!var11.isSynthetic()) {
               ++var6;
               var3 = var11;
            }
         }

         if (var6 == 1) {
            if (!var3.isAccessible()) {
               var3.setAccessible(true);

               try {
                  Object var10 = var3.get(var1);
                  return var10;
               } catch (NullPointerException var12) {
                  throw new IllegalArgumentException("Binder object is null.", var12);
               } catch (IllegalAccessException var13) {
                  throw new IllegalArgumentException("Could not access the field in remoteBinder.", var13);
               }
            } else {
               throw new IllegalArgumentException("IObjectWrapper declared field not private!");
            }
         } else {
            IllegalArgumentException var7 = new IllegalArgumentException(b.a.a.a.a.s(64, "Unexpected number of IObjectWrapper declared fields: ", var2.length));
            throw var7;
         }
      }
   }

   public static b.b.b.b.b.a g2(Object var0) {
      return new b(var0);
   }
}
