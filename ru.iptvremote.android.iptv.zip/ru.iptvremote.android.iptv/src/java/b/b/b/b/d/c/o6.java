package b.b.b.b.d.c;

import b.b.b.b.d.c.o6.d;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class o6 extends h5 {
   private static Map zzbmr = new ConcurrentHashMap();
   protected d9 zzbmp = d9.g();
   private int zzbmq = -1;

   static Object i(Method var0, Object var1, Object... var2) {
      try {
         Object var6 = var0.invoke(var1, var2);
         return var6;
      } catch (IllegalAccessException var7) {
         throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", var7);
      } catch (InvocationTargetException var8) {
         Throwable var5 = var8.getCause();
         if (!(var5 instanceof RuntimeException)) {
            if (var5 instanceof Error) {
               throw (Error)var5;
            } else {
               throw new RuntimeException("Unexpected exception thrown by generated accessor method.", var5);
            }
         } else {
            throw (RuntimeException)var5;
         }
      }
   }

   protected static void j(Class var0, o6 var1) {
      zzbmr.put(var0, var1);
   }

   protected static final boolean k(o6 var0, boolean var1) {
      byte var2 = (Byte)var0.h(d.a, (Object)null, (Object)null);
      if (var2 == 1) {
         return true;
      } else if (var2 == 0) {
         return false;
      } else {
         boolean var3 = l8.b().c(var0).d(var0);
         if (var1) {
            d var4 = d.b;
            o6 var5;
            if (var3) {
               var5 = var0;
            } else {
               var5 = null;
            }

            var0.h(var4, var5, (Object)null);
         }

         return var3;
      }
   }

   static o6 l(Class var0) {
      o6 var1 = (o6)zzbmr.get(var0);
      if (var1 == null) {
         try {
            Class.forName(var0.getName(), true, var0.getClassLoader());
         } catch (ClassNotFoundException var5) {
            throw new IllegalStateException("Class initialization cannot fail.", var5);
         }

         var1 = (o6)zzbmr.get(var0);
      }

      if (var1 == null) {
         o6 var2 = (o6)((o6)h9.o(var0)).h(d.f, (Object)null, (Object)null);
         if (var2 != null) {
            zzbmr.put(var0, var2);
            return var2;
         } else {
            throw new IllegalStateException();
         }
      } else {
         return var1;
      }
   }

   // $FF: synthetic method
   public final x7 a() {
      return (o6)this.h(d.f, (Object)null, (Object)null);
   }

   public void b(a6 var1) {
      l8.b().c(this).g(this, c6.a(var1));
   }

   public int d() {
      if (this.zzbmq == -1) {
         this.zzbmq = l8.b().c(this).f(this);
      }

      return this.zzbmq;
   }

   final void e(int var1) {
      this.zzbmq = var1;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else {
         return !((o6)this.h(d.f, (Object)null, (Object)null)).getClass().isInstance(var1) ? false : l8.b().c(this).a(this, (o6)var1);
      }
   }

   // $FF: synthetic method
   public final a8 f() {
      o6.a var1 = (o6.a)this.h(d.e, (Object)null, (Object)null);
      var1.g(this);
      return var1;
   }

   final int g() {
      return this.zzbmq;
   }

   protected abstract Object h(d var1, Object var2, Object var3);

   public int hashCode() {
      int var1 = super.zzbim;
      if (var1 != 0) {
         return var1;
      } else {
         int var2 = l8.b().c(this).c(this);
         super.zzbim = var2;
         return var2;
      }
   }

   public final boolean isInitialized() {
      return k(this, true);
   }

   protected final o6.a m() {
      return (o6.a)this.h(d.e, (Object)null, (Object)null);
   }

   public String toString() {
      return l.b(this, super.toString());
   }

   public static class a extends g5 {
      private final o6 a;
      protected o6 b;
      protected boolean c;

      protected a(o6 var1) {
         this.a = var1;
         this.b = (o6)var1.h(d.d, (Object)null, (Object)null);
         this.c = false;
      }

      private static void h(o6 var0, o6 var1) {
         l8.b().c(var0).e(var0, var1);
      }

      // $FF: synthetic method
      public final x7 a() {
         return this.a;
      }

      // $FF: synthetic method
      public Object clone() {
         o6.a var1 = (o6.a)this.a.h(d.e, (Object)null, (Object)null);
         var1.g((o6)this.j());
         return var1;
      }

      public final o6.a g(o6 var1) {
         if (this.c) {
            this.i();
            this.c = false;
         }

         h(this.b, var1);
         return this;
      }

      protected void i() {
         o6 var1 = (o6)this.b.h(d.d, (Object)null, (Object)null);
         o6 var2 = this.b;
         l8.b().c(var1).e(var1, var2);
         this.b = var1;
      }

      public final boolean isInitialized() {
         return o6.k(this.b, false);
      }

      public x7 j() {
         if (!this.c) {
            o6 var1 = this.b;
            l8.b().c(var1).b(var1);
            this.c = true;
         }

         return this.b;
      }

      public x7 k() {
         o6 var1 = (o6)this.j();
         if (var1.isInitialized()) {
            return var1;
         } else {
            throw new b9();
         }
      }
   }
}
