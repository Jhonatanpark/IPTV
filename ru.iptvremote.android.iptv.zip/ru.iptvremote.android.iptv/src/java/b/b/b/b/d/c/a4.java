package b.b.b.b.d.c;

import b.b.b.b.d.c.o6.d;

public final class a4 extends o6 implements z7 {
   private static volatile g8 zzafw;
   private static final a4 zzbii;
   private int zzafi;
   private int zzbid;
   private int zzbie;
   private x6 zzbif = k8.i();
   private x6 zzbig = k8.i();
   private int zzbih;

   static {
      a4 var0 = new a4();
      zzbii = var0;
      o6.j(a4.class, var0);
   }

   private a4() {
   }

   protected final Object h(d var1, Object var2, Object var3) {
      switch(c5.a[var1.ordinal()]) {
      case 1:
         return new a4();
      case 2:
         return new a4.a((c5)null);
      case 3:
         Object[] var4 = new Object[]{"zzafi", "zzbid", i3.a, "zzbie", k3.a, "zzbif", n4.class, "zzbig", n4.class, "zzbih", i2.a};
         return new n8(zzbii, "\u0001\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0002\u0000\u0001\f\u0000\u0002\f\u0001\u0003\u001b\u0004\u001b\u0005\f\u0002", var4);
      case 4:
         return zzbii;
      case 5:
         g8 var5 = zzafw;
         if (var5 == null) {
            Class var8 = a4.class;
            synchronized(a4.class){}

            Throwable var10000;
            boolean var10001;
            label261: {
               Object var7;
               try {
                  var7 = zzafw;
               } catch (Throwable var28) {
                  var10000 = var28;
                  var10001 = false;
                  break label261;
               }

               if (var7 == null) {
                  try {
                     var7 = new b.b.b.b.d.c.o6.c(zzbii);
                     zzafw = (g8)var7;
                  } catch (Throwable var27) {
                     var10000 = var27;
                     var10001 = false;
                     break label261;
                  }
               }

               label246:
               try {
                  return var7;
               } catch (Throwable var26) {
                  var10000 = var26;
                  var10001 = false;
                  break label246;
               }
            }

            while(true) {
               Throwable var6 = var10000;

               try {
                  throw var6;
               } catch (Throwable var25) {
                  var10000 = var25;
                  var10001 = false;
                  continue;
               }
            }
         } else {
            return var5;
         }
      case 6:
         return 1;
      case 7:
         return null;
      default:
         throw new UnsupportedOperationException();
      }
   }

   public static final class a extends o6.a implements z7 {
      a(c5 var1) {
         super(a4.zzbii);
      }
   }
}
