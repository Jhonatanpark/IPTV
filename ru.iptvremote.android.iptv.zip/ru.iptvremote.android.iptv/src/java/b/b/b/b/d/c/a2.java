package b.b.b.b.d.c;

final class a2 implements t6 {
   static final t6 a = new a2();

   private a2() {
   }
}
