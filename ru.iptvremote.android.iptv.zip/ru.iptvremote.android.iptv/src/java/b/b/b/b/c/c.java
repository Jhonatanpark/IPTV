package b.b.b.b.c;

import android.os.IBinder;
import android.os.Parcel;
import b.b.b.b.d.e.a;

public final class c extends a implements b.b.b.b.c.a {
   c(IBinder var1) {
      super(var1, "com.google.android.gms.flags.IFlagProvider");
   }

   public final boolean getBooleanFlagValue(String var1, boolean var2, int var3) {
      Parcel var4 = this.t0();
      var4.writeString(var1);
      b.b.b.b.d.e.c.a(var4, var2);
      var4.writeInt(var3);
      Parcel var5 = this.V1(2, var4);
      boolean var6;
      if (var5.readInt() != 0) {
         var6 = true;
      } else {
         var6 = false;
      }

      var5.recycle();
      return var6;
   }

   public final int getIntFlagValue(String var1, int var2, int var3) {
      Parcel var4 = this.t0();
      var4.writeString(var1);
      var4.writeInt(var2);
      var4.writeInt(var3);
      Parcel var5 = this.V1(3, var4);
      int var6 = var5.readInt();
      var5.recycle();
      return var6;
   }

   public final long getLongFlagValue(String var1, long var2, int var4) {
      Parcel var5 = this.t0();
      var5.writeString(var1);
      var5.writeLong(var2);
      var5.writeInt(var4);
      Parcel var6 = this.V1(4, var5);
      long var7 = var6.readLong();
      var6.recycle();
      return var7;
   }

   public final String getStringFlagValue(String var1, String var2, int var3) {
      Parcel var4 = this.t0();
      var4.writeString(var1);
      var4.writeString(var2);
      var4.writeInt(var3);
      Parcel var5 = this.V1(5, var4);
      String var6 = var5.readString();
      var5.recycle();
      return var6;
   }

   public final void init(b.b.b.b.b.a var1) {
      Parcel var2 = this.t0();
      b.b.b.b.d.e.c.b(var2, var1);
      this.c2(var2);
   }
}
