package b.b.b.b.d.c;

import android.os.IBinder;
import android.os.Parcel;

public final class c1 extends t implements d1 {
   c1(IBinder var1) {
      super(var1, "com.google.android.gms.cast.remote_display.ICastRemoteDisplayService");
   }

   public final void K4(b1 var1) {
      Parcel var2 = this.t0();
      v0.c(var2, var1);
      this.g2(6, var2);
   }

   public final void disconnect() {
      this.g2(3, this.t0());
   }
}
