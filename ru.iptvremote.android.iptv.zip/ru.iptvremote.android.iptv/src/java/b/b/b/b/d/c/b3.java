package b.b.b.b.d.c;

final class b3 implements t6 {
   static final t6 a = new b3();

   private b3() {
   }
}
