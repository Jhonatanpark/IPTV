package b.b.b.b.d.c;

import android.os.IBinder;
import android.os.Parcel;
import b.b.b.b.b.a;
import com.google.android.gms.cast.framework.CastOptions;
import com.google.android.gms.cast.framework.f0;
import com.google.android.gms.cast.framework.g0;
import com.google.android.gms.cast.framework.o;
import com.google.android.gms.cast.framework.y;
import com.google.android.gms.cast.framework.z;
import com.google.android.gms.cast.framework.media.internal.f;
import com.google.android.gms.cast.framework.media.internal.g;
import java.util.Map;

public final class c extends t implements d {
   c(IBinder var1) {
      super(var1, "com.google.android.gms.cast.framework.internal.ICastDynamiteModule");
   }

   public final f0 G0(a var1, a var2, a var3) {
      Parcel var4 = this.t0();
      v0.c(var4, var1);
      v0.c(var4, var2);
      v0.c(var4, var3);
      Parcel var5 = this.V1(5, var4);
      f0 var6 = com.google.android.gms.cast.framework.f0.a.V1(var5.readStrongBinder());
      var5.recycle();
      return var6;
   }

   public final com.google.android.gms.cast.framework.a0 I7(CastOptions var1, a var2, y var3) {
      Parcel var4 = this.t0();
      v0.d(var4, var1);
      v0.c(var4, var2);
      v0.c(var4, var3);
      Parcel var5 = this.V1(3, var4);
      com.google.android.gms.cast.framework.a0 var6 = com.google.android.gms.cast.framework.a0.a.V1(var5.readStrongBinder());
      var5.recycle();
      return var6;
   }

   public final g0 b7(String var1, String var2, o var3) {
      Parcel var4 = this.t0();
      var4.writeString(var1);
      var4.writeString(var2);
      v0.c(var4, var3);
      Parcel var5 = this.V1(2, var4);
      g0 var6 = com.google.android.gms.cast.framework.g0.a.V1(var5.readStrongBinder());
      var5.recycle();
      return var6;
   }

   public final f c6(a var1, g var2, int var3, int var4, boolean var5, long var6, int var8, int var9, int var10) {
      Parcel var11 = this.t0();
      v0.c(var11, var1);
      v0.c(var11, var2);
      var11.writeInt(var3);
      var11.writeInt(var4);
      var11.writeInt(var5);
      var11.writeLong(var6);
      var11.writeInt(var8);
      var11.writeInt(var9);
      var11.writeInt(var10);
      Parcel var12 = this.V1(6, var11);
      f var13 = com.google.android.gms.cast.framework.media.internal.f.a.V1(var12.readStrongBinder());
      var12.recycle();
      return var13;
   }

   public final z p5(a var1, CastOptions var2, b.b.b.b.d.c.f var3, Map var4) {
      Parcel var5 = this.t0();
      v0.c(var5, var1);
      v0.d(var5, var2);
      v0.c(var5, var3);
      var5.writeMap(var4);
      Parcel var6 = this.V1(1, var5);
      z var7 = com.google.android.gms.cast.framework.z.a.V1(var6.readStrongBinder());
      var6.recycle();
      return var7;
   }
}
