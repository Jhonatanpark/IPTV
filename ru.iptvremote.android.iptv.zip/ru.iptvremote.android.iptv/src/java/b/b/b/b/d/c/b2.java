package b.b.b.b.d.c;

final class b2 implements t6 {
   static final t6 a = new b2();

   private b2() {
   }
}
