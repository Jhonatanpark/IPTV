package b.b.b.b.d.a;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public final class d implements b, IInterface {
   private final IBinder a;
   private final String b;

   d(IBinder var1) {
      this.a = var1;
      this.b = "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService";
   }

   protected final Parcel V1(int var1, Parcel var2) {
      Parcel var3 = Parcel.obtain();

      try {
         this.a.transact(var1, var2, var3, 0);
         var3.readException();
      } catch (RuntimeException var8) {
         var3.recycle();
         throw var8;
      } finally {
         var2.recycle();
      }

      return var3;
   }

   public IBinder asBinder() {
      return this.a;
   }

   public final String getId() {
      Parcel var1 = this.V1(1, this.t0());
      String var2 = var1.readString();
      var1.recycle();
      return var2;
   }

   protected final Parcel t0() {
      Parcel var1 = Parcel.obtain();
      var1.writeInterfaceToken(this.b);
      return var1;
   }

   public final boolean v() {
      Parcel var1 = this.V1(6, this.t0());
      boolean var2 = b.b.b.b.d.a.a.b(var1);
      var1.recycle();
      return var2;
   }

   public final boolean y3(boolean var1) {
      Parcel var2 = this.t0();
      b.b.b.b.d.a.a.a(var2);
      Parcel var3 = this.V1(2, var2);
      boolean var4;
      if (var3.readInt() != 0) {
         var4 = true;
      } else {
         var4 = false;
      }

      var3.recycle();
      return var4;
   }
}
