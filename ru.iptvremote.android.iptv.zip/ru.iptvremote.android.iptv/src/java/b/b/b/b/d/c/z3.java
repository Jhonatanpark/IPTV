package b.b.b.b.d.c;

import b.b.b.b.d.c.o6.d;

public final class z3 extends o6 implements z7 {
   private static volatile g8 zzafw;
   private static final z3 zzbic;
   private int zzafi;
   private x6 zzbbe = k8.i();
   private int zzbhg;
   private int zzbhq;
   private x6 zzbib = k8.i();

   static {
      z3 var0 = new z3();
      zzbic = var0;
      o6.j(z3.class, var0);
   }

   private z3() {
   }

   // $FF: synthetic method
   static z3 n() {
      return zzbic;
   }

   protected final Object h(d var1, Object var2, Object var3) {
      switch(c5.a[var1.ordinal()]) {
      case 1:
         return new z3();
      case 2:
         return new b.b.b.b.d.c.z3.a((c5)null);
      case 3:
         Object[] var4 = new Object[]{"zzafi", "zzbhq", h3.a, "zzbbe", r3.class, "zzbib", r3.class, "zzbhg"};
         return new n8(zzbic, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0002\u0000\u0001\f\u0000\u0002\u001b\u0003\u001b\u0004\u0004\u0001", var4);
      case 4:
         return zzbic;
      case 5:
         g8 var5 = zzafw;
         if (var5 == null) {
            Class var8 = z3.class;
            synchronized(z3.class){}

            Throwable var10000;
            boolean var10001;
            label261: {
               Object var7;
               try {
                  var7 = zzafw;
               } catch (Throwable var28) {
                  var10000 = var28;
                  var10001 = false;
                  break label261;
               }

               if (var7 == null) {
                  try {
                     var7 = new b.b.b.b.d.c.o6.c(zzbic);
                     zzafw = (g8)var7;
                  } catch (Throwable var27) {
                     var10000 = var27;
                     var10001 = false;
                     break label261;
                  }
               }

               label246:
               try {
                  return var7;
               } catch (Throwable var26) {
                  var10000 = var26;
                  var10001 = false;
                  break label246;
               }
            }

            while(true) {
               Throwable var6 = var10000;

               try {
                  throw var6;
               } catch (Throwable var25) {
                  var10000 = var25;
                  var10001 = false;
                  continue;
               }
            }
         } else {
            return var5;
         }
      case 6:
         return 1;
      case 7:
         return null;
      default:
         throw new UnsupportedOperationException();
      }
   }
}
