package b.b.b.b.d.c;

public abstract class g5 implements a8 {
}
