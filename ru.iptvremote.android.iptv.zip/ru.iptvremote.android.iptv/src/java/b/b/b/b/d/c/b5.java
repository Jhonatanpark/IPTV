package b.b.b.b.d.c;

final class b5 implements t6 {
   static final t6 a = new b5();

   private b5() {
   }
}
