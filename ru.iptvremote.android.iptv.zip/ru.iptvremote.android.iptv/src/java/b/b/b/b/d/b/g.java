package b.b.b.b.d.b;

import androidx.annotation.NonNull;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

final class g implements d {
   g(e var1) {
   }

   @NonNull
   public final ExecutorService a(int var1, ThreadFactory var2, int var3) {
      ThreadPoolExecutor var4 = new ThreadPoolExecutor(var1, var1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue(), var2);
      var4.allowCoreThreadTimeOut(true);
      return Executors.unconfigurableExecutorService(var4);
   }
}
