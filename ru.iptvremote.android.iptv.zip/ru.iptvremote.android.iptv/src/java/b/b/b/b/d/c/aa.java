package b.b.b.b.d.c;

import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.a.a;
import com.google.android.gms.common.api.Status;

final class aa implements a {
   private final Status a;

   public aa(Status var1) {
      this.a = var1;
   }

   public final Status E() {
      return this.a;
   }

   public final String P0() {
      return null;
   }

   public final boolean Q0() {
      return false;
   }

   public final String R0() {
      return null;
   }

   public final ApplicationMetadata S0() {
      return null;
   }
}
