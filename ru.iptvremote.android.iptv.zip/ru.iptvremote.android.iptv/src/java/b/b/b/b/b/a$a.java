package b.b.b.b.b;

import android.os.IBinder;
import android.os.IInterface;

public class a$a extends b.b.b.b.d.d.a implements b.b.b.b.b.a {
   public a$a() {
      super("com.google.android.gms.dynamic.IObjectWrapper");
   }

   public static b.b.b.b.b.a V1(IBinder var0) {
      if (var0 == null) {
         return null;
      } else {
         IInterface var1 = var0.queryLocalInterface("com.google.android.gms.dynamic.IObjectWrapper");
         return (b.b.b.b.b.a)(var1 instanceof b.b.b.b.b.a ? (b.b.b.b.b.a)var1 : new a$a.a(var0));
      }
   }

   public static final class a extends b.b.b.b.d.d.b implements b.b.b.b.b.a {
      a(IBinder var1) {
         super(var1, "com.google.android.gms.dynamic.IObjectWrapper");
      }
   }
}
