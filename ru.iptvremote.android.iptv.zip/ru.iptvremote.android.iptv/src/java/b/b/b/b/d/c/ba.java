package b.b.b.b.d.c;

import b.b.b.b.f.e;

// $FF: synthetic class
final class ba implements e {
   static final e a = new ba();

   private ba() {
   }

   public final void onSuccess(Object var1) {
      z9.a = (Boolean)var1;
   }
}
