package b.b.b.b.d.c;

import android.content.Context;
import android.view.View;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaTrack;
import com.google.android.gms.cast.framework.media.d;
import com.google.android.gms.cast.framework.media.f.a;
import java.util.Iterator;
import java.util.List;

public final class b0 extends a {
   private final View c;
   private final String d;
   private final String e;

   public b0(View var1, Context var2) {
      this.c = var1;
      this.d = var2.getString(2131689534);
      this.e = var2.getString(2131689535);
      this.c.setEnabled(false);
   }

   private final void g() {
      View var2;
      String var3;
      label48: {
         d var1 = this.b();
         if (var1 != null && var1.o()) {
            boolean var5;
            label44: {
               label54: {
                  MediaInfo var4 = var1.j();
                  if (var4 != null) {
                     List var6 = var4.n0();
                     if (var6 != null && !var6.isEmpty()) {
                        Iterator var7 = var6.iterator();
                        int var8 = 0;

                        while(var7.hasNext()) {
                           MediaTrack var9 = (MediaTrack)var7.next();
                           if (var9.n0() == 2) {
                              ++var8;
                              if (var8 > 1) {
                                 break label54;
                              }
                           } else if (var9.n0() == 1) {
                              break label54;
                           }
                        }
                     }
                  }

                  var5 = false;
                  break label44;
               }

               var5 = true;
            }

            if (var5 && !var1.u()) {
               this.c.setEnabled(true);
               var2 = this.c;
               var3 = this.d;
               break label48;
            }
         }

         this.c.setEnabled(false);
         var2 = this.c;
         var3 = this.e;
      }

      var2.setContentDescription(var3);
   }

   public final void c() {
      this.g();
   }

   public final void d() {
      this.c.setEnabled(false);
   }

   public final void e(com.google.android.gms.cast.framework.c var1) {
      super.e(var1);
      this.c.setEnabled(true);
      this.g();
   }

   public final void f() {
      this.c.setEnabled(false);
      super.f();
   }
}
