package b.b.b.b.d.c;

final class a3 implements t6 {
   static final t6 a = new a3();

   private a3() {
   }
}
