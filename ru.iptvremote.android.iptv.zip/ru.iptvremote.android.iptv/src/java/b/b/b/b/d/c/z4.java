package b.b.b.b.d.c;

import b.b.b.b.d.c.o6.d;

public final class z4 extends o6 implements z7 {
   private static volatile g8 zzafw;
   private static final z4 zzbgm;
   private int zzafi;
   private int zzbbw;
   private long zzbgk;
   private int zzbgl;

   static {
      z4 var0 = new z4();
      zzbgm = var0;
      o6.j(z4.class, var0);
   }

   private z4() {
   }

   protected final Object h(d var1, Object var2, Object var3) {
      switch(c5.a[var1.ordinal()]) {
      case 1:
         return new z4();
      case 2:
         return new z4.a((c5)null);
      case 3:
         Object[] var4 = new Object[]{"zzafi", "zzbbw", t2.a, "zzbgk", "zzbgl", c2.a};
         return new n8(zzbgm, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\f\u0000\u0002\u0002\u0001\u0003\f\u0002", var4);
      case 4:
         return zzbgm;
      case 5:
         g8 var5 = zzafw;
         if (var5 == null) {
            Class var8 = z4.class;
            synchronized(z4.class){}

            Throwable var10000;
            boolean var10001;
            label261: {
               Object var7;
               try {
                  var7 = zzafw;
               } catch (Throwable var28) {
                  var10000 = var28;
                  var10001 = false;
                  break label261;
               }

               if (var7 == null) {
                  try {
                     var7 = new b.b.b.b.d.c.o6.c(zzbgm);
                     zzafw = (g8)var7;
                  } catch (Throwable var27) {
                     var10000 = var27;
                     var10001 = false;
                     break label261;
                  }
               }

               label246:
               try {
                  return var7;
               } catch (Throwable var26) {
                  var10000 = var26;
                  var10001 = false;
                  break label246;
               }
            }

            while(true) {
               Throwable var6 = var10000;

               try {
                  throw var6;
               } catch (Throwable var25) {
                  var10000 = var25;
                  var10001 = false;
                  continue;
               }
            }
         } else {
            return var5;
         }
      case 6:
         return 1;
      case 7:
         return null;
      default:
         throw new UnsupportedOperationException();
      }
   }

   public static final class a extends o6.a implements z7 {
      a(c5 var1) {
         super(z4.zzbgm);
      }
   }
}
