package b.b.b.b.d.c;

import b.a.a.a.a;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import sun.misc.Unsafe;

final class b8 implements m8 {
   private static final int[] m = new int[0];
   private static final Unsafe n = h9.w();
   private final int[] a;
   private final Object[] b;
   private final boolean c;
   private final boolean d;
   private final boolean e;
   private final int[] f;
   private final int g;
   private final int h;
   private final g7 i;
   private final a9 j;
   private final e6 k;
   private final u7 l;

   private b8(int[] var1, Object[] var2, int var3, int var4, x7 var5, boolean var6, int[] var7, int var8, int var9, f8 var10, g7 var11, a9 var12, e6 var13, u7 var14) {
      this.a = var1;
      this.b = var2;
      boolean var10000 = var5 instanceof o6;
      this.d = var6;
      boolean var16;
      if (var13 != null && var5 instanceof b.b.b.b.d.c.o6.b) {
         var16 = true;
      } else {
         var16 = false;
      }

      this.c = var16;
      this.e = false;
      this.f = var7;
      this.g = var8;
      this.h = var9;
      this.i = var11;
      this.j = var12;
      this.k = var13;
      this.l = var14;
   }

   private static double A(Object var0, long var1) {
      return (Double)h9.B(var0, var1);
   }

   private static float B(Object var0, long var1) {
      return (Float)h9.B(var0, var1);
   }

   private static int C(Object var0, long var1) {
      return (Integer)h9.B(var0, var1);
   }

   private static long D(Object var0, long var1) {
      return (Long)h9.B(var0, var1);
   }

   private static boolean E(Object var0, long var1) {
      return (Boolean)h9.B(var0, var1);
   }

   static b8 h(Class var0, v7 var1, f8 var2, g7 var3, a9 var4, e6 var5, u7 var6) {
      if (var1 instanceof n8) {
         n8 var9 = (n8)var1;
         boolean var10;
         if (var9.b() == 2) {
            var10 = true;
         } else {
            var10 = false;
         }

         String var11 = var9.d();
         int var12 = var11.length();
         int var13 = var11.charAt(0);
         int var14;
         if (var13 >= 55296) {
            int var176 = var13 & 8191;
            int var177 = 1;
            int var178 = 13;

            while(true) {
               var14 = var177 + 1;
               char var179 = var11.charAt(var177);
               if (var179 < '\ud800') {
                  var13 = var176 | var179 << var178;
                  break;
               }

               var176 |= (var179 & 8191) << var178;
               var178 += 13;
               var177 = var14;
            }
         } else {
            var14 = 1;
         }

         int var15 = var14 + 1;
         int var16 = var11.charAt(var14);
         if (var16 >= 55296) {
            int var172 = var16 & 8191;
            int var173 = 13;

            while(true) {
               int var174 = var15 + 1;
               char var175 = var11.charAt(var15);
               if (var175 < '\ud800') {
                  var16 = var172 | var175 << var173;
                  var15 = var174;
                  break;
               }

               var172 |= (var175 & 8191) << var173;
               var173 += 13;
               var15 = var174;
            }
         }

         int var22;
         int var26;
         int var35;
         int var36;
         int[] var37;
         int var38;
         int var39;
         int var40;
         if (var16 == 0) {
            var37 = m;
            var40 = 0;
            var38 = 0;
            var36 = 0;
            var22 = 0;
            var26 = 0;
            var39 = 0;
            var35 = 0;
         } else {
            int var17 = var15 + 1;
            int var18 = var11.charAt(var15);
            if (var18 >= 55296) {
               int var168 = var18 & 8191;
               int var169 = 13;

               while(true) {
                  int var170 = var17 + 1;
                  char var171 = var11.charAt(var17);
                  if (var171 < '\ud800') {
                     var18 = var168 | var171 << var169;
                     var17 = var170;
                     break;
                  }

                  var168 |= (var171 & 8191) << var169;
                  var169 += 13;
                  var17 = var170;
               }
            }

            int var19 = var17 + 1;
            int var20 = var11.charAt(var17);
            if (var20 >= 55296) {
               int var164 = var20 & 8191;
               int var165 = 13;

               while(true) {
                  int var166 = var19 + 1;
                  char var167 = var11.charAt(var19);
                  if (var167 < '\ud800') {
                     var20 = var164 | var167 << var165;
                     var19 = var166;
                     break;
                  }

                  var164 |= (var167 & 8191) << var165;
                  var165 += 13;
                  var19 = var166;
               }
            }

            int var21 = var19 + 1;
            var22 = var11.charAt(var19);
            if (var22 >= 55296) {
               int var160 = var22 & 8191;
               int var161 = 13;

               while(true) {
                  int var162 = var21 + 1;
                  char var163 = var11.charAt(var21);
                  if (var163 < '\ud800') {
                     var22 = var160 | var163 << var161;
                     var21 = var162;
                     break;
                  }

                  var160 |= (var163 & 8191) << var161;
                  var161 += 13;
                  var21 = var162;
               }
            }

            int var23 = var21 + 1;
            int var24 = var11.charAt(var21);
            if (var24 >= 55296) {
               int var156 = var24 & 8191;
               int var157 = 13;

               while(true) {
                  int var158 = var23 + 1;
                  char var159 = var11.charAt(var23);
                  if (var159 < '\ud800') {
                     var24 = var156 | var159 << var157;
                     var23 = var158;
                     break;
                  }

                  var156 |= (var159 & 8191) << var157;
                  var157 += 13;
                  var23 = var158;
               }
            }

            int var25 = var23 + 1;
            var26 = var11.charAt(var23);
            if (var26 >= 55296) {
               int var152 = var26 & 8191;
               int var153 = 13;

               while(true) {
                  int var154 = var25 + 1;
                  char var155 = var11.charAt(var25);
                  if (var155 < '\ud800') {
                     var26 = var152 | var155 << var153;
                     var25 = var154;
                     break;
                  }

                  var152 |= (var155 & 8191) << var153;
                  var153 += 13;
                  var25 = var154;
               }
            }

            int var27 = var25 + 1;
            int var28 = var11.charAt(var25);
            if (var28 >= 55296) {
               int var148 = var28 & 8191;
               int var149 = 13;

               while(true) {
                  int var150 = var27 + 1;
                  char var151 = var11.charAt(var27);
                  if (var151 < '\ud800') {
                     var28 = var148 | var151 << var149;
                     var27 = var150;
                     break;
                  }

                  var148 |= (var151 & 8191) << var149;
                  var149 += 13;
                  var27 = var150;
               }
            }

            int var29 = var27 + 1;
            int var30 = var11.charAt(var27);
            int var31;
            if (var30 < 55296) {
               var31 = var29;
            } else {
               int var143 = var30 & 8191;
               int var144 = var29;
               int var145 = 13;

               while(true) {
                  int var146 = var144 + 1;
                  char var147 = var11.charAt(var144);
                  if (var147 < '\ud800') {
                     var30 = var143 | var147 << var145;
                     var31 = var146;
                     break;
                  }

                  var143 |= (var147 & 8191) << var145;
                  var145 += 13;
                  var144 = var146;
               }
            }

            int var32 = var31 + 1;
            int var33 = var11.charAt(var31);
            if (var33 >= 55296) {
               int var138 = var33 & 8191;
               int var139 = var32;
               int var140 = 13;

               while(true) {
                  int var141 = var139 + 1;
                  char var142 = var11.charAt(var139);
                  if (var142 < '\ud800') {
                     var33 = var138 | var142 << var140;
                     var32 = var141;
                     break;
                  }

                  var138 |= (var142 & 8191) << var140;
                  var140 += 13;
                  var139 = var141;
               }
            }

            int[] var34 = new int[var30 + var33 + var28];
            var35 = var20 + (var18 << 1);
            var36 = var24;
            var37 = var34;
            var38 = var28;
            var39 = var33;
            var40 = var18;
            var15 = var32;
         }

         Unsafe var41 = n;
         Object[] var42 = var9.e();
         Class var43 = var9.a().getClass();
         int[] var45 = new int[var26 * 3];
         Object[] var46 = new Object[var26 << 1];
         int var47 = var39 + var38;
         int var48 = var39;
         int var49 = var15;
         int var50 = var47;
         int var51 = 0;

         int var70;
         for(int var52 = 0; var49 < var12; var22 = var70) {
            int var59 = var49 + 1;
            int var60 = var11.charAt(var49);
            int var62;
            int var63;
            if (var60 < 55296) {
               var62 = var39;
               var63 = var59;
            } else {
               int var133 = var60 & 8191;
               int var134 = var59;
               int var135 = 13;

               while(true) {
                  int var136 = var134 + 1;
                  char var137 = var11.charAt(var134);
                  var62 = var39;
                  if (var137 < '\ud800') {
                     var60 = var133 | var137 << var135;
                     var63 = var136;
                     break;
                  }

                  var133 |= (var137 & 8191) << var135;
                  var135 += 13;
                  var134 = var136;
                  var39 = var39;
               }
            }

            int var64 = var63 + 1;
            int var65 = var11.charAt(var63);
            boolean var66;
            int var67;
            if (var65 < 55296) {
               var66 = var10;
               var67 = var64;
            } else {
               int var128 = var65 & 8191;
               int var129 = var64;
               int var130 = 13;

               while(true) {
                  int var131 = var129 + 1;
                  char var132 = var11.charAt(var129);
                  var66 = var10;
                  if (var132 < '\ud800') {
                     var65 = var128 | var132 << var130;
                     var67 = var131;
                     break;
                  }

                  var128 |= (var132 & 8191) << var130;
                  var130 += 13;
                  var129 = var131;
                  var10 = var10;
               }
            }

            int var68 = var65 & 255;
            if ((var65 & 1024) != 0) {
               int var127 = var51 + 1;
               var37[var51] = var52;
               var51 = var127;
            }

            n8 var73;
            String var74;
            int var75;
            int var78;
            int var79;
            int var80;
            int var81;
            if (var68 >= 51) {
               int var105 = var67 + 1;
               int var106 = var11.charAt(var67);
               char var107 = '\ud800';
               int var108;
               if (var106 >= var107) {
                  int var121 = var106 & 8191;
                  int var122 = 13;
                  int var123 = var121;
                  int var124 = var105;

                  while(true) {
                     int var125 = var124 + 1;
                     char var126 = var11.charAt(var124);
                     if (var126 < var107) {
                        var106 = var123 | var126 << var122;
                        var108 = var125;
                        break;
                     }

                     var123 |= (var126 & 8191) << var122;
                     var122 += 13;
                     var124 = var125;
                     var107 = '\ud800';
                  }
               } else {
                  var108 = var105;
               }

               var80 = var108;
               int var109 = var68 - 51;
               var70 = var22;
               if (var109 != 9 && var109 != 17) {
                  if (var109 == 12 && (var13 & 1) == 1) {
                     int var119 = 1 + (var52 / 3 << 1);
                     int var120 = var35 + 1;
                     var46[var119] = var42[var35];
                     var35 = var120;
                  }
               } else {
                  int var110 = 1 + (var52 / 3 << 1);
                  int var111 = var35 + 1;
                  var46[var110] = var42[var35];
                  var35 = var111;
               }

               int var112 = var106 << 1;
               Object var113 = var42[var112];
               Field var114;
               if (var113 instanceof Field) {
                  var114 = (Field)var113;
               } else {
                  var114 = i(var43, (String)var113);
                  var42[var112] = var114;
               }

               var75 = (int)var41.objectFieldOffset(var114);
               int var116 = var112 + 1;
               Object var117 = var42[var116];
               Field var118;
               if (var117 instanceof Field) {
                  var118 = (Field)var117;
               } else {
                  var118 = i(var43, (String)var117);
                  var42[var116] = var118;
               }

               var81 = (int)var41.objectFieldOffset(var118);
               var74 = var11;
               var73 = var9;
               var79 = var35;
               var78 = 0;
            } else {
               int var71;
               Field var72;
               label239: {
                  int var98;
                  label383: {
                     var70 = var22;
                     var71 = var35 + 1;
                     var72 = i(var43, (String)var42[var35]);
                     if (var68 != 9 && var68 != 17) {
                        if (var68 == 27 || var68 == 49) {
                           var73 = var9;
                           int var97 = 1 + (var52 / 3 << 1);
                           var98 = var71 + 1;
                           var46[var97] = var42[var71];
                           break label383;
                        }

                        if (var68 != 12 && var68 != 30 && var68 != 44) {
                           label224: {
                              if (var68 == 50) {
                                 int var101 = var48 + 1;
                                 var37[var48] = var52;
                                 int var102 = var52 / 3 << 1;
                                 int var103 = var71 + 1;
                                 var46[var102] = var42[var71];
                                 if ((var65 & 2048) != 0) {
                                    int var104 = var102 + 1;
                                    var71 = var103 + 1;
                                    var46[var104] = var42[var103];
                                    var73 = var9;
                                    var48 = var101;
                                    break label224;
                                 }

                                 var48 = var101;
                                 var71 = var103;
                              }

                              var73 = var9;
                           }
                        } else {
                           int var99 = var13 & 1;
                           var73 = var9;
                           if (var99 == 1) {
                              int var100 = 1 + (var52 / 3 << 1);
                              var98 = var71 + 1;
                              var46[var100] = var42[var71];
                              break label383;
                           }
                        }
                     } else {
                        var73 = var9;
                        var46[1 + (var52 / 3 << 1)] = var72.getType();
                     }

                     var74 = var11;
                     break label239;
                  }

                  var74 = var11;
                  var71 = var98;
               }

               var75 = (int)var41.objectFieldOffset(var72);
               int var76;
               int var77;
               if ((var13 & 1) == 1 && var68 <= 17) {
                  int var88 = var67 + 1;
                  String var89 = var74;
                  int var90 = var74.charAt(var67);
                  if (var90 < 55296) {
                     var76 = var88;
                  } else {
                     int var94 = var90 & 8191;
                     int var95 = 13;

                     while(true) {
                        var76 = var88 + 1;
                        char var96 = var89.charAt(var88);
                        if (var96 < '\ud800') {
                           var90 = var94 | var96 << var95;
                           break;
                        }

                        var94 |= (var96 & 8191) << var95;
                        var95 += 13;
                        var88 = var76;
                     }
                  }

                  int var91 = (var40 << 1) + var90 / 32;
                  Object var92 = var42[var91];
                  Field var93;
                  if (var92 instanceof Field) {
                     var93 = (Field)var92;
                  } else {
                     var93 = i(var43, (String)var92);
                     var42[var91] = var93;
                  }

                  var74 = var89;
                  var77 = (int)var41.objectFieldOffset(var93);
                  var78 = var90 % 32;
               } else {
                  var76 = var67;
                  var77 = 0;
                  var78 = 0;
               }

               if (var68 >= 18 && var68 <= 49) {
                  int var87 = var50 + 1;
                  var37[var50] = var75;
                  var50 = var87;
               }

               var79 = var71;
               var80 = var76;
               var81 = var77;
            }

            int var82 = var52 + 1;
            var45[var52] = var60;
            int var83 = var82 + 1;
            int var85;
            if ((var65 & 512) != 0) {
               var85 = 536870912;
            } else {
               var85 = 0;
            }

            int var86;
            if ((var65 & 256) != 0) {
               var86 = 268435456;
            } else {
               var86 = 0;
            }

            var45[var82] = var75 | var85 | var86 | var68 << 20;
            var52 = var83 + 1;
            var45[var83] = var81 | var78 << 20;
            var11 = var74;
            var35 = var79;
            var36 = var36;
            var12 = var12;
            var49 = var80;
            var39 = var62;
            var10 = var66;
            var9 = var73;
         }

         b8 var58 = new b8(var45, var46, var22, var36, var9.a(), var10, var37, var39, var47, var2, var3, var4, var5, var6);
         return var58;
      } else {
         y8 var10000 = (y8)var1;
         NoSuchMethodError var8 = new NoSuchMethodError();
         throw var8;
      }
   }

   private static Field i(Class var0, String var1) {
      try {
         Field var9 = var0.getDeclaredField(var1);
         return var9;
      } catch (NoSuchFieldException var10) {
         Field[] var2 = var0.getDeclaredFields();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Field var8 = var2[var4];
            if (var1.equals(var8.getName())) {
               return var8;
            }
         }

         String var5 = var0.getName();
         String var6 = Arrays.toString(var2);
         RuntimeException var7 = new RuntimeException(b.a.a.a.a.h(b.a.a.a.a.i(b.a.a.a.a.m(var6, b.a.a.a.a.m(var1, 40) + var5.length()), "Field ", var1, " for ", var5), " not found. Known fields are ", var6));
         throw var7;
      }
   }

   private static void j(int var0, Object var1, v9 var2) {
      if (var1 instanceof String) {
         String var4 = (String)var1;
         ((c6)var2).o(var0, var4);
      } else {
         n5 var3 = (n5)var1;
         ((c6)var2).e(var0, var3);
      }
   }

   private static void k(a9 var0, Object var1, v9 var2) {
      if ((c9)var0 != null) {
         ((o6)var1).zzbmp.f(var2);
      } else {
         throw null;
      }
   }

   private final void l(v9 var1, int var2, Object var3, int var4) {
      if (var3 != null) {
         s7 var5 = this.l.j(this.b[var4 / 3 << 1]);
         Map var6 = this.l.a(var3);
         ((c6)var1).f(var2, var5, var6);
      }

   }

   private final void m(Object var1, Object var2, int var3) {
      long var4 = (long)(1048575 & this.a[var3 + 1]);
      if (this.n(var2, var3)) {
         Object var6 = h9.B(var1, var4);
         Object var7 = h9.B(var2, var4);
         if (var6 != null && var7 != null) {
            h9.g(var1, var4, p6.e(var6, var7));
            this.q(var1, var3);
         } else {
            if (var7 != null) {
               h9.g(var1, var4, var7);
               this.q(var1, var3);
            }

         }
      }
   }

   private final boolean n(Object var1, int var2) {
      if (this.d) {
         int var4 = this.a[var2 + 1];
         long var5 = (long)(var4 & 1048575);
         switch((var4 & 267386880) >>> 20) {
         case 0:
            if (h9.A(var1, var5) != 0.0D) {
               return true;
            }

            return false;
         case 1:
            if (h9.z(var1, var5) != 0.0F) {
               return true;
            }

            return false;
         case 2:
            if (h9.t(var1, var5) != 0L) {
               return true;
            }

            return false;
         case 3:
            if (h9.t(var1, var5) != 0L) {
               return true;
            }

            return false;
         case 4:
            if (h9.r(var1, var5) != 0) {
               return true;
            }

            return false;
         case 5:
            if (h9.t(var1, var5) != 0L) {
               return true;
            }

            return false;
         case 6:
            if (h9.r(var1, var5) != 0) {
               return true;
            }

            return false;
         case 7:
            return h9.x(var1, var5);
         case 8:
            Object var7 = h9.B(var1, var5);
            if (var7 instanceof String) {
               if (!((String)var7).isEmpty()) {
                  return true;
               }

               return false;
            } else {
               if (var7 instanceof n5) {
                  if (!n5.b.equals(var7)) {
                     return true;
                  }

                  return false;
               }

               throw new IllegalArgumentException();
            }
         case 9:
            if (h9.B(var1, var5) != null) {
               return true;
            }

            return false;
         case 10:
            if (!n5.b.equals(h9.B(var1, var5))) {
               return true;
            }

            return false;
         case 11:
            if (h9.r(var1, var5) != 0) {
               return true;
            }

            return false;
         case 12:
            if (h9.r(var1, var5) != 0) {
               return true;
            }

            return false;
         case 13:
            if (h9.r(var1, var5) != 0) {
               return true;
            }

            return false;
         case 14:
            if (h9.t(var1, var5) != 0L) {
               return true;
            }

            return false;
         case 15:
            if (h9.r(var1, var5) != 0) {
               return true;
            }

            return false;
         case 16:
            if (h9.t(var1, var5) != 0L) {
               return true;
            }

            return false;
         case 17:
            if (h9.B(var1, var5) != null) {
               return true;
            }

            return false;
         default:
            throw new IllegalArgumentException();
         }
      } else {
         int var3 = this.a[var2 + 2];
         return (1 << (var3 >>> 20) & h9.r(var1, (long)(var3 & 1048575))) != 0;
      }
   }

   private final boolean o(Object var1, int var2, int var3) {
      return h9.r(var1, (long)(1048575 & this.a[var3 + 2])) == var2;
   }

   private final boolean p(Object var1, int var2, int var3, int var4) {
      if (this.d) {
         return this.n(var1, var2);
      } else {
         return (var3 & var4) != 0;
      }
   }

   private final void q(Object var1, int var2) {
      if (!this.d) {
         int var3 = this.a[var2 + 2];
         int var4 = 1 << (var3 >>> 20);
         long var5 = (long)(var3 & 1048575);
         h9.e(var1, var5, var4 | h9.r(var1, var5));
      }
   }

   private final void r(Object var1, int var2, int var3) {
      h9.e(var1, (long)(1048575 & this.a[var3 + 2]), var2);
   }

   private final void s(Object var1, v9 var2) {
      Entry var3;
      label191: {
         if (this.c) {
            if ((d6)this.k == null) {
               throw null;
            }

            f6 var71 = ((b.b.b.b.d.c.o6.b)var1).zzbms;
            if (!var71.a.isEmpty()) {
               var3 = (Entry)var71.c().next();
               break label191;
            }
         }

         var3 = null;
      }

      int var4 = -1;
      int var5 = this.a.length;
      Unsafe var6 = n;
      int var7 = 0;

      int var13;
      for(int var8 = 0; var7 < var5; var7 = var13 + 3) {
         int var9 = this.w(var7);
         int[] var10 = this.a;
         int var11 = var10[var7];
         int var12 = (267386880 & var9) >>> 20;
         int var14;
         if (!this.d && var12 <= 17) {
            int var69 = var10[var7 + 2];
            int var70 = var69 & 1048575;
            var13 = var7;
            if (var70 != var4) {
               var8 = var6.getInt(var1, (long)var70);
               var4 = var70;
            }

            var14 = 1 << (var69 >>> 20);
         } else {
            var13 = var7;
            var14 = 0;
         }

         if (var3 != null) {
            this.k.a(var3);
            throw null;
         }

         long var16 = (long)(var9 & 1048575);
         switch(var12) {
         case 0:
            if ((var8 & var14) != 0) {
               double var19 = h9.A(var1, var16);
               ((c6)var2).b(var11, var19);
            }
            break;
         case 1:
            if ((var8 & var14) != 0) {
               float var21 = h9.z(var1, var16);
               ((c6)var2).c(var11, var21);
            }
            break;
         case 2:
            if ((var8 & var14) != 0) {
               long var22 = var6.getLong(var1, var16);
               ((c6)var2).D(var11, var22);
            }
            break;
         case 3:
            if ((var8 & var14) != 0) {
               long var24 = var6.getLong(var1, var16);
               ((c6)var2).d(var11, var24);
            }
            break;
         case 4:
            if ((var8 & var14) != 0) {
               int var26 = var6.getInt(var1, var16);
               ((c6)var2).v(var11, var26);
            }
            break;
         case 5:
            if ((var8 & var14) != 0) {
               long var27 = var6.getLong(var1, var16);
               ((c6)var2).s(var11, var27);
            }
            break;
         case 6:
            if ((var8 & var14) != 0) {
               int var29 = var6.getInt(var1, var16);
               ((c6)var2).B(var11, var29);
            }
            break;
         case 7:
            if ((var8 & var14) != 0) {
               boolean var30 = h9.x(var1, var16);
               ((c6)var2).r(var11, var30);
            }
            break;
         case 8:
            if ((var8 & var14) != 0) {
               j(var11, var6.getObject(var1, var16), var2);
            }
            break;
         case 9:
            if ((var8 & var14) != 0) {
               Object var31 = var6.getObject(var1, var16);
               m8 var32 = this.u(var13);
               ((c6)var2).g(var11, var31, var32);
            }
            break;
         case 10:
            if ((var8 & var14) != 0) {
               n5 var33 = (n5)var6.getObject(var1, var16);
               ((c6)var2).e(var11, var33);
            }
            break;
         case 11:
            if ((var8 & var14) != 0) {
               int var34 = var6.getInt(var1, var16);
               ((c6)var2).x(var11, var34);
            }
            break;
         case 12:
            if ((var8 & var14) != 0) {
               int var35 = var6.getInt(var1, var16);
               ((c6)var2).M(var11, var35);
            }
            break;
         case 13:
            if ((var8 & var14) != 0) {
               int var36 = var6.getInt(var1, var16);
               ((c6)var2).L(var11, var36);
            }
            break;
         case 14:
            if ((var8 & var14) != 0) {
               long var37 = var6.getLong(var1, var16);
               ((c6)var2).F(var11, var37);
            }
            break;
         case 15:
            if ((var8 & var14) != 0) {
               int var39 = var6.getInt(var1, var16);
               ((c6)var2).z(var11, var39);
            }
            break;
         case 16:
            if ((var8 & var14) != 0) {
               long var40 = var6.getLong(var1, var16);
               ((c6)var2).l(var11, var40);
            }
            break;
         case 17:
            if ((var8 & var14) != 0) {
               Object var42 = var6.getObject(var1, var16);
               m8 var43 = this.u(var13);
               ((c6)var2).n(var11, var42, var43);
            }
            break;
         case 18:
            o8.c(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 19:
            o8.i(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 20:
            o8.m(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 21:
            o8.p(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 22:
            o8.z(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 23:
            o8.u(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 24:
            o8.F(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 25:
            o8.O(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 26:
            o8.a(this.a[var13], (List)var6.getObject(var1, var16), var2);
            break;
         case 27:
            o8.b(this.a[var13], (List)var6.getObject(var1, var16), var2, this.u(var13));
            break;
         case 28:
            o8.g(this.a[var13], (List)var6.getObject(var1, var16), var2);
            break;
         case 29:
            o8.B(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 30:
            o8.M(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 31:
            o8.K(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 32:
            o8.x(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 33:
            o8.D(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 34:
            o8.r(this.a[var13], (List)var6.getObject(var1, var16), var2, false);
            break;
         case 35:
            o8.c(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 36:
            o8.i(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 37:
            o8.m(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 38:
            o8.p(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 39:
            o8.z(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 40:
            o8.u(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 41:
            o8.F(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 42:
            o8.O(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 43:
            o8.B(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 44:
            o8.M(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 45:
            o8.K(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 46:
            o8.x(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 47:
            o8.D(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 48:
            o8.r(this.a[var13], (List)var6.getObject(var1, var16), var2, true);
            break;
         case 49:
            o8.h(this.a[var13], (List)var6.getObject(var1, var16), var2, this.u(var13));
            break;
         case 50:
            this.l(var2, var11, var6.getObject(var1, var16), var13);
            break;
         case 51:
            if (this.o(var1, var11, var13)) {
               double var44 = A(var1, var16);
               ((c6)var2).b(var11, var44);
            }
            break;
         case 52:
            if (this.o(var1, var11, var13)) {
               float var46 = B(var1, var16);
               ((c6)var2).c(var11, var46);
            }
            break;
         case 53:
            if (this.o(var1, var11, var13)) {
               long var47 = D(var1, var16);
               ((c6)var2).D(var11, var47);
            }
            break;
         case 54:
            if (this.o(var1, var11, var13)) {
               long var49 = D(var1, var16);
               ((c6)var2).d(var11, var49);
            }
            break;
         case 55:
            if (this.o(var1, var11, var13)) {
               int var51 = C(var1, var16);
               ((c6)var2).v(var11, var51);
            }
            break;
         case 56:
            if (this.o(var1, var11, var13)) {
               long var52 = D(var1, var16);
               ((c6)var2).s(var11, var52);
            }
            break;
         case 57:
            if (this.o(var1, var11, var13)) {
               int var54 = C(var1, var16);
               ((c6)var2).B(var11, var54);
            }
            break;
         case 58:
            if (this.o(var1, var11, var13)) {
               boolean var55 = E(var1, var16);
               ((c6)var2).r(var11, var55);
            }
            break;
         case 59:
            if (this.o(var1, var11, var13)) {
               j(var11, var6.getObject(var1, var16), var2);
            }
            break;
         case 60:
            if (this.o(var1, var11, var13)) {
               Object var56 = var6.getObject(var1, var16);
               m8 var57 = this.u(var13);
               ((c6)var2).g(var11, var56, var57);
            }
            break;
         case 61:
            if (this.o(var1, var11, var13)) {
               n5 var58 = (n5)var6.getObject(var1, var16);
               ((c6)var2).e(var11, var58);
            }
            break;
         case 62:
            if (this.o(var1, var11, var13)) {
               int var59 = C(var1, var16);
               ((c6)var2).x(var11, var59);
            }
            break;
         case 63:
            if (this.o(var1, var11, var13)) {
               int var60 = C(var1, var16);
               ((c6)var2).M(var11, var60);
            }
            break;
         case 64:
            if (this.o(var1, var11, var13)) {
               int var61 = C(var1, var16);
               ((c6)var2).L(var11, var61);
            }
            break;
         case 65:
            if (this.o(var1, var11, var13)) {
               long var62 = D(var1, var16);
               ((c6)var2).F(var11, var62);
            }
            break;
         case 66:
            if (this.o(var1, var11, var13)) {
               int var64 = C(var1, var16);
               ((c6)var2).z(var11, var64);
            }
            break;
         case 67:
            if (this.o(var1, var11, var13)) {
               long var65 = D(var1, var16);
               ((c6)var2).l(var11, var65);
            }
            break;
         case 68:
            if (this.o(var1, var11, var13)) {
               Object var67 = var6.getObject(var1, var16);
               m8 var68 = this.u(var13);
               ((c6)var2).n(var11, var67, var68);
            }
         }
      }

      if (var3 == null) {
         k(this.j, var1, var2);
      } else {
         this.k.b(var2, var3);
         throw null;
      }
   }

   private final void t(Object var1, Object var2, int var3) {
      int[] var4 = this.a;
      int var5 = var4[var3 + 1];
      int var6 = var4[var3];
      long var7 = (long)(var5 & 1048575);
      if (this.o(var2, var6, var3)) {
         Object var9 = h9.B(var1, var7);
         Object var10 = h9.B(var2, var7);
         if (var9 != null && var10 != null) {
            h9.g(var1, var7, p6.e(var9, var10));
            this.r(var1, var6, var3);
         } else {
            if (var10 != null) {
               h9.g(var1, var7, var10);
               this.r(var1, var6, var3);
            }

         }
      }
   }

   private final m8 u(int var1) {
      int var2 = var1 / 3 << 1;
      m8 var3 = (m8)this.b[var2];
      if (var3 != null) {
         return var3;
      } else {
         m8 var4 = l8.b().a((Class)this.b[var2 + 1]);
         this.b[var2] = var4;
         return var4;
      }
   }

   private final Object v(int var1) {
      return this.b[var1 / 3 << 1];
   }

   private final int w(int var1) {
      return this.a[var1 + 1];
   }

   private final int x(int var1) {
      return this.a[var1 + 2];
   }

   private final boolean y(Object var1, Object var2, int var3) {
      return this.n(var1, var3) == this.n(var2, var3);
   }

   private static List z(Object var0, long var1) {
      return (List)h9.B(var0, var1);
   }

   public final boolean a(Object var1, Object var2) {
      int var3 = this.a.length;
      int var4 = 0;

      while(true) {
         boolean var5 = true;
         if (var4 >= var3) {
            c9 var6 = (c9)this.j;
            if (var6 != null) {
               d9 var7 = ((o6)var1).zzbmp;
               if (var6 != null) {
                  if (!var7.equals(((o6)var2).zzbmp)) {
                     return false;
                  }

                  if (this.c) {
                     d6 var8 = (d6)this.k;
                     if (var8 != null) {
                        f6 var9 = ((b.b.b.b.d.c.o6.b)var1).zzbms;
                        if (var8 != null) {
                           return var9.equals(((b.b.b.b.d.c.o6.b)var2).zzbms);
                        }

                        throw null;
                     }

                     throw null;
                  }

                  return var5;
               }

               throw null;
            }

            throw null;
         }

         label140: {
            int var10 = this.w(var4);
            long var11 = (long)(var10 & 1048575);
            switch((var10 & 267386880) >>> 20) {
            case 0:
               if (this.y(var1, var2, var4) && Double.doubleToLongBits(h9.A(var1, var11)) == Double.doubleToLongBits(h9.A(var2, var11))) {
                  break label140;
               }
               break;
            case 1:
               if (this.y(var1, var2, var4) && Float.floatToIntBits(h9.z(var1, var11)) == Float.floatToIntBits(h9.z(var2, var11))) {
                  break label140;
               }
               break;
            case 2:
               if (this.y(var1, var2, var4) && h9.t(var1, var11) == h9.t(var2, var11)) {
                  break label140;
               }
               break;
            case 3:
               if (this.y(var1, var2, var4) && h9.t(var1, var11) == h9.t(var2, var11)) {
                  break label140;
               }
               break;
            case 4:
               if (this.y(var1, var2, var4) && h9.r(var1, var11) == h9.r(var2, var11)) {
                  break label140;
               }
               break;
            case 5:
               if (this.y(var1, var2, var4) && h9.t(var1, var11) == h9.t(var2, var11)) {
                  break label140;
               }
               break;
            case 6:
               if (this.y(var1, var2, var4) && h9.r(var1, var11) == h9.r(var2, var11)) {
                  break label140;
               }
               break;
            case 7:
               if (this.y(var1, var2, var4) && h9.x(var1, var11) == h9.x(var2, var11)) {
                  break label140;
               }
               break;
            case 8:
               if (this.y(var1, var2, var4) && o8.s(h9.B(var1, var11), h9.B(var2, var11))) {
                  break label140;
               }
               break;
            case 9:
               if (this.y(var1, var2, var4) && o8.s(h9.B(var1, var11), h9.B(var2, var11))) {
                  break label140;
               }
               break;
            case 10:
               if (this.y(var1, var2, var4) && o8.s(h9.B(var1, var11), h9.B(var2, var11))) {
                  break label140;
               }
               break;
            case 11:
               if (this.y(var1, var2, var4) && h9.r(var1, var11) == h9.r(var2, var11)) {
                  break label140;
               }
               break;
            case 12:
               if (this.y(var1, var2, var4) && h9.r(var1, var11) == h9.r(var2, var11)) {
                  break label140;
               }
               break;
            case 13:
               if (this.y(var1, var2, var4) && h9.r(var1, var11) == h9.r(var2, var11)) {
                  break label140;
               }
               break;
            case 14:
               if (this.y(var1, var2, var4) && h9.t(var1, var11) == h9.t(var2, var11)) {
                  break label140;
               }
               break;
            case 15:
               if (this.y(var1, var2, var4) && h9.r(var1, var11) == h9.r(var2, var11)) {
                  break label140;
               }
               break;
            case 16:
               if (this.y(var1, var2, var4) && h9.t(var1, var11) == h9.t(var2, var11)) {
                  break label140;
               }
               break;
            case 17:
               if (this.y(var1, var2, var4) && o8.s(h9.B(var1, var11), h9.B(var2, var11))) {
                  break label140;
               }
               break;
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
            case 40:
            case 41:
            case 42:
            case 43:
            case 44:
            case 45:
            case 46:
            case 47:
            case 48:
            case 49:
            case 50:
               var5 = o8.s(h9.B(var1, var11), h9.B(var2, var11));
               break label140;
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 58:
            case 59:
            case 60:
            case 61:
            case 62:
            case 63:
            case 64:
            case 65:
            case 66:
            case 67:
            case 68:
               long var13 = (long)(1048575 & this.x(var4));
               if (h9.r(var1, var13) == h9.r(var2, var13) && o8.s(h9.B(var1, var11), h9.B(var2, var11))) {
                  break label140;
               }
               break;
            default:
               break label140;
            }

            var5 = false;
         }

         if (!var5) {
            return false;
         }

         var4 += 3;
      }
   }

   public final void b(Object var1) {
      int var2 = this.g;

      while(true) {
         int var3 = this.h;
         if (var2 >= var3) {
            for(int var4 = this.f.length; var3 < var4; ++var3) {
               this.i.a(var1, (long)this.f[var3]);
            }

            if ((c9)this.j != null) {
               if (((o6)var1).zzbmp != null) {
                  if (this.c) {
                     if ((d6)this.k != null) {
                        ((b.b.b.b.d.c.o6.b)var1).zzbms.n();
                        return;
                     } else {
                        throw null;
                     }
                  } else {
                     return;
                  }
               } else {
                  throw null;
               }
            } else {
               throw null;
            }
         }

         long var5 = (long)(1048575 & this.w(this.f[var2]));
         Object var7 = h9.B(var1, var5);
         if (var7 != null) {
            h9.g(var1, var5, this.l.i(var7));
         }

         ++var2;
      }
   }

   public final int c(Object var1) {
      int var2 = this.a.length;
      int var3 = 0;

      int var4;
      for(var4 = 0; var3 < var2; var3 += 3) {
         int var21;
         int var22;
         label188: {
            int var14;
            int var19;
            label187: {
               int var13;
               label186: {
                  long var10;
                  label185: {
                     label212: {
                        boolean var23;
                        label182: {
                           float var20;
                           label181: {
                              long var17;
                              label180: {
                                 Object var25;
                                 label213: {
                                    Object var24;
                                    label214: {
                                       label215: {
                                          label164: {
                                             label163: {
                                                int var8 = this.w(var3);
                                                int var9 = this.a[var3];
                                                var10 = (long)(1048575 & var8);
                                                int var12 = (var8 & 267386880) >>> 20;
                                                var13 = 37;
                                                double var15;
                                                switch(var12) {
                                                case 0:
                                                   var14 = var4 * 53;
                                                   var15 = h9.A(var1, var10);
                                                   break;
                                                case 1:
                                                   var14 = var4 * 53;
                                                   var20 = h9.z(var1, var10);
                                                   break label181;
                                                case 2:
                                                case 3:
                                                case 5:
                                                case 14:
                                                case 16:
                                                   var14 = var4 * 53;
                                                   var17 = h9.t(var1, var10);
                                                   break label180;
                                                case 4:
                                                case 6:
                                                case 11:
                                                case 12:
                                                case 13:
                                                case 15:
                                                   var21 = var4 * 53;
                                                   var22 = h9.r(var1, var10);
                                                   break label188;
                                                case 7:
                                                   var14 = var4 * 53;
                                                   var23 = h9.x(var1, var10);
                                                   break label182;
                                                case 8:
                                                   break label212;
                                                case 9:
                                                   var24 = h9.B(var1, var10);
                                                   if (var24 == null) {
                                                      break label186;
                                                   }
                                                   break label214;
                                                case 10:
                                                case 18:
                                                case 19:
                                                case 20:
                                                case 21:
                                                case 22:
                                                case 23:
                                                case 24:
                                                case 25:
                                                case 26:
                                                case 27:
                                                case 28:
                                                case 29:
                                                case 30:
                                                case 31:
                                                case 32:
                                                case 33:
                                                case 34:
                                                case 35:
                                                case 36:
                                                case 37:
                                                case 38:
                                                case 39:
                                                case 40:
                                                case 41:
                                                case 42:
                                                case 43:
                                                case 44:
                                                case 45:
                                                case 46:
                                                case 47:
                                                case 48:
                                                case 49:
                                                case 50:
                                                   break label164;
                                                case 17:
                                                   var24 = h9.B(var1, var10);
                                                   if (var24 == null) {
                                                      break label186;
                                                   }
                                                   break label214;
                                                case 51:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }

                                                   var14 = var4 * 53;
                                                   var15 = A(var1, var10);
                                                   break;
                                                case 52:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }

                                                   var14 = var4 * 53;
                                                   var20 = B(var1, var10);
                                                   break label181;
                                                case 53:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label215;
                                                case 54:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label215;
                                                case 55:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label185;
                                                case 56:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label215;
                                                case 57:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label185;
                                                case 58:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }

                                                   var14 = var4 * 53;
                                                   var23 = E(var1, var10);
                                                   break label182;
                                                case 59:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label212;
                                                case 60:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label163;
                                                case 61:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label164;
                                                case 62:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label185;
                                                case 63:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label185;
                                                case 64:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label185;
                                                case 65:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label215;
                                                case 66:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label185;
                                                case 67:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label215;
                                                case 68:
                                                   if (!this.o(var1, var9, var3)) {
                                                      continue;
                                                   }
                                                   break label163;
                                                default:
                                                   continue;
                                                }

                                                var17 = Double.doubleToLongBits(var15);
                                                break label180;
                                             }

                                             var25 = h9.B(var1, var10);
                                             var14 = var4 * 53;
                                             break label213;
                                          }

                                          var14 = var4 * 53;
                                          var25 = h9.B(var1, var10);
                                          break label213;
                                       }

                                       var14 = var4 * 53;
                                       var17 = D(var1, var10);
                                       break label180;
                                    }

                                    var13 = var24.hashCode();
                                    break label186;
                                 }

                                 var19 = var25.hashCode();
                                 break label187;
                              }

                              var19 = p6.h(var17);
                              break label187;
                           }

                           var19 = Float.floatToIntBits(var20);
                           break label187;
                        }

                        var19 = p6.g(var23);
                        break label187;
                     }

                     var14 = var4 * 53;
                     var19 = ((String)h9.B(var1, var10)).hashCode();
                     break label187;
                  }

                  var21 = var4 * 53;
                  var22 = C(var1, var10);
                  break label188;
               }

               var4 = var13 + var4 * 53;
               continue;
            }

            var4 = var19 + var14;
            continue;
         }

         var4 = var21 + var22;
      }

      int var5 = var4 * 53;
      if ((c9)this.j != null) {
         int var6 = var5 + ((o6)var1).zzbmp.hashCode();
         if (this.c) {
            int var7 = var6 * 53;
            if ((d6)this.k != null) {
               return var7 + ((b.b.b.b.d.c.o6.b)var1).zzbms.hashCode();
            } else {
               throw null;
            }
         } else {
            return var6;
         }
      } else {
         throw null;
      }
   }

   public final boolean d(Object var1) {
      int var2 = -1;
      int var3 = 0;
      int var4 = 0;

      while(true) {
         int var5 = this.g;
         byte var6 = 1;
         if (var3 >= var5) {
            if (this.c) {
               if ((d6)this.k == null) {
                  throw null;
               }

               if (!((b.b.b.b.d.c.o6.b)var1).zzbms.b()) {
                  return false;
               }
            }

            return (boolean)var6;
         }

         int var7 = this.f[var3];
         int var8 = this.a[var7];
         int var9 = this.w(var7);
         int var10;
         if (!this.d) {
            int var18 = this.a[var7 + 2];
            int var19 = var18 & 1048575;
            var10 = var6 << (var18 >>> 20);
            if (var19 != var2) {
               var4 = n.getInt(var1, (long)var19);
               var2 = var19;
            }
         } else {
            var10 = 0;
         }

         boolean var11;
         if ((268435456 & var9) != 0) {
            var11 = true;
         } else {
            var11 = false;
         }

         if (var11 && !this.p(var1, var7, var4, var10)) {
            return false;
         }

         int var12 = (267386880 & var9) >>> 20;
         if (var12 != 9 && var12 != 17) {
            label102: {
               if (var12 != 27) {
                  if (var12 == 60 || var12 == 68) {
                     if (this.o(var1, var8, var7) && !this.u(var7).d(h9.B(var1, (long)(var9 & 1048575)))) {
                        return false;
                     }
                     break label102;
                  }

                  if (var12 != 49) {
                     if (var12 == 50 && !this.l.a(h9.B(var1, (long)(var9 & 1048575))).isEmpty()) {
                        Object var16 = this.v(var7);
                        this.l.j(var16);
                        throw null;
                     }
                     break label102;
                  }
               }

               List var13 = (List)h9.B(var1, (long)(var9 & 1048575));
               if (!var13.isEmpty()) {
                  m8 var14 = this.u(var7);

                  for(int var15 = 0; var15 < var13.size(); ++var15) {
                     if (!var14.d(var13.get(var15))) {
                        var6 = 0;
                        break;
                     }
                  }
               }

               if (var6 == 0) {
                  return false;
               }
            }
         } else if (this.p(var1, var7, var4, var10) && !this.u(var7).d(h9.B(var1, (long)(var9 & 1048575)))) {
            return false;
         }

         ++var3;
      }
   }

   public final void e(Object var1, Object var2) {
      if (var2 == null) {
         throw null;
      } else {
         for(int var3 = 0; var3 < this.a.length; var3 += 3) {
            long var5;
            int var7;
            label145: {
               label114: {
                  label113: {
                     label112: {
                        int var4 = this.w(var3);
                        var5 = (long)(1048575 & var4);
                        var7 = this.a[var3];
                        switch((var4 & 267386880) >>> 20) {
                        case 0:
                           if (!this.n(var2, var3)) {
                              continue;
                           }

                           h9.c(var1, var5, h9.A(var2, var5));
                           break label114;
                        case 1:
                           if (!this.n(var2, var3)) {
                              continue;
                           }

                           h9.d(var1, var5, h9.z(var2, var5));
                           break label114;
                        case 2:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label112;
                        case 3:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label112;
                        case 4:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label113;
                        case 5:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label112;
                        case 6:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label113;
                        case 7:
                           if (!this.n(var2, var3)) {
                              continue;
                           }

                           h9.h(var1, var5, h9.x(var2, var5));
                           break label114;
                        case 8:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break;
                        case 9:
                        case 17:
                           this.m(var1, var2, var3);
                           continue;
                        case 10:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break;
                        case 11:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label113;
                        case 12:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label113;
                        case 13:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label113;
                        case 14:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label112;
                        case 15:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label113;
                        case 16:
                           if (!this.n(var2, var3)) {
                              continue;
                           }
                           break label112;
                        case 18:
                        case 19:
                        case 20:
                        case 21:
                        case 22:
                        case 23:
                        case 24:
                        case 25:
                        case 26:
                        case 27:
                        case 28:
                        case 29:
                        case 30:
                        case 31:
                        case 32:
                        case 33:
                        case 34:
                        case 35:
                        case 36:
                        case 37:
                        case 38:
                        case 39:
                        case 40:
                        case 41:
                        case 42:
                        case 43:
                        case 44:
                        case 45:
                        case 46:
                        case 47:
                        case 48:
                        case 49:
                           this.i.b(var1, var2, var5);
                           continue;
                        case 50:
                           o8.e(this.l, var1, var2, var5);
                           continue;
                        case 51:
                        case 52:
                        case 53:
                        case 54:
                        case 55:
                        case 56:
                        case 57:
                        case 58:
                        case 59:
                           if (!this.o(var2, var7, var3)) {
                              continue;
                           }
                           break label145;
                        case 60:
                        case 68:
                           this.t(var1, var2, var3);
                           continue;
                        case 61:
                        case 62:
                        case 63:
                        case 64:
                        case 65:
                        case 66:
                        case 67:
                           if (!this.o(var2, var7, var3)) {
                              continue;
                           }
                           break label145;
                        default:
                           continue;
                        }

                        h9.g(var1, var5, h9.B(var2, var5));
                        break label114;
                     }

                     h9.f(var1, var5, h9.t(var2, var5));
                     break label114;
                  }

                  h9.e(var1, var5, h9.r(var2, var5));
               }

               this.q(var1, var3);
               continue;
            }

            h9.g(var1, var5, h9.B(var2, var5));
            this.r(var1, var7, var3);
         }

         o8.f(this.j, var1, var2);
         if (this.c) {
            o8.d(this.k, var1, var2);
         }

      }
   }

   public final int f(Object var1) {
      boolean var2 = this.d;
      int var3 = 267386880;
      if (var2) {
         Unsafe var40 = n;
         int var41 = 0;

         int var42;
         for(var42 = 0; var41 < this.a.length; var41 += 3) {
            int var43 = this.w(var41);
            int var44 = (var43 & var3) >>> 20;
            int var45 = this.a[var41];
            long var46 = (long)(var43 & 1048575);
            int var48;
            if (var44 >= l6.K.a() && var44 <= l6.X.a()) {
               var48 = 1048575 & this.a[var41 + 2];
            } else {
               var48 = 0;
            }

            int var49;
            label544: {
               int var61;
               label543: {
                  Object var55;
                  label542: {
                     label541: {
                        label540: {
                           label539: {
                              label538: {
                                 int var54;
                                 label537: {
                                    long var52;
                                    label536: {
                                       long var50;
                                       label535: {
                                          label534: {
                                             label801: {
                                                label519: {
                                                   label802: {
                                                      long var59;
                                                      label515: {
                                                         int var58;
                                                         label514: {
                                                            label513: {
                                                               label512: {
                                                                  int var57;
                                                                  label511: {
                                                                     int var56;
                                                                     label510: {
                                                                        label509: {
                                                                           switch(var44) {
                                                                           case 0:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label801;
                                                                           case 1:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label534;
                                                                           case 2:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var50 = h9.t(var1, var46);
                                                                              break label535;
                                                                           case 3:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var52 = h9.t(var1, var46);
                                                                              break label536;
                                                                           case 4:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var54 = h9.r(var1, var46);
                                                                              break label537;
                                                                           case 5:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label538;
                                                                           case 6:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label539;
                                                                           case 7:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label540;
                                                                           case 8:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var55 = h9.B(var1, var46);
                                                                              if (var55 instanceof n5) {
                                                                                 break label542;
                                                                              }
                                                                              break label541;
                                                                           case 9:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label509;
                                                                           case 10:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break;
                                                                           case 11:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var56 = h9.r(var1, var46);
                                                                              break label510;
                                                                           case 12:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var57 = h9.r(var1, var46);
                                                                              break label511;
                                                                           case 13:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label512;
                                                                           case 14:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label513;
                                                                           case 15:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var58 = h9.r(var1, var46);
                                                                              break label514;
                                                                           case 16:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var59 = h9.t(var1, var46);
                                                                              break label515;
                                                                           case 17:
                                                                              if (!this.n(var1, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label802;
                                                                           case 18:
                                                                           case 23:
                                                                           case 32:
                                                                              var49 = o8.Y(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 19:
                                                                           case 24:
                                                                           case 31:
                                                                              var49 = o8.X(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 20:
                                                                              var49 = o8.P(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 21:
                                                                              var49 = o8.Q(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 22:
                                                                              var49 = o8.U(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 25:
                                                                              var49 = o8.Z(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 26:
                                                                              var49 = o8.k(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 27:
                                                                              var49 = o8.l(var45, z(var1, var46), this.u(var41));
                                                                              break label544;
                                                                           case 28:
                                                                              var49 = o8.n(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 29:
                                                                              var49 = o8.V(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 30:
                                                                              var49 = o8.T(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 33:
                                                                              var49 = o8.W(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 34:
                                                                              var49 = o8.R(var45, z(var1, var46));
                                                                              break label544;
                                                                           case 35:
                                                                              var61 = o8.L((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 36:
                                                                              var61 = o8.J((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 37:
                                                                              var61 = o8.q((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 38:
                                                                              var61 = o8.t((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 39:
                                                                              var61 = o8.A((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 40:
                                                                              var61 = o8.L((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 41:
                                                                              var61 = o8.J((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 42:
                                                                              var61 = o8.N((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 43:
                                                                              var61 = o8.C((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 44:
                                                                              var61 = o8.y((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 45:
                                                                              var61 = o8.J((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 46:
                                                                              var61 = o8.L((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 47:
                                                                              var61 = o8.E((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 48:
                                                                              var61 = o8.w((List)var40.getObject(var1, var46));
                                                                              if (var61 <= 0) {
                                                                                 continue;
                                                                              }

                                                                              if (!this.e) {
                                                                                 break label543;
                                                                              }
                                                                              break label519;
                                                                           case 49:
                                                                              var49 = o8.o(var45, z(var1, var46), this.u(var41));
                                                                              break label544;
                                                                           case 50:
                                                                              var49 = this.l.g(var45, h9.B(var1, var46), this.v(var41));
                                                                              break label544;
                                                                           case 51:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label801;
                                                                           case 52:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label534;
                                                                           case 53:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var50 = D(var1, var46);
                                                                              break label535;
                                                                           case 54:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var52 = D(var1, var46);
                                                                              break label536;
                                                                           case 55:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var54 = C(var1, var46);
                                                                              break label537;
                                                                           case 56:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label538;
                                                                           case 57:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label539;
                                                                           case 58:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label540;
                                                                           case 59:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var55 = h9.B(var1, var46);
                                                                              if (var55 instanceof n5) {
                                                                                 break label542;
                                                                              }
                                                                              break label541;
                                                                           case 60:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label509;
                                                                           case 61:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break;
                                                                           case 62:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var56 = C(var1, var46);
                                                                              break label510;
                                                                           case 63:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var57 = C(var1, var46);
                                                                              break label511;
                                                                           case 64:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label512;
                                                                           case 65:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label513;
                                                                           case 66:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var58 = C(var1, var46);
                                                                              break label514;
                                                                           case 67:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }

                                                                              var59 = D(var1, var46);
                                                                              break label515;
                                                                           case 68:
                                                                              if (!this.o(var1, var45, var41)) {
                                                                                 continue;
                                                                              }
                                                                              break label802;
                                                                           default:
                                                                              continue;
                                                                           }

                                                                           var55 = h9.B(var1, var46);
                                                                           break label542;
                                                                        }

                                                                        var49 = o8.j(var45, h9.B(var1, var46), this.u(var41));
                                                                        break label544;
                                                                     }

                                                                     var49 = a6.P(var45, var56);
                                                                     break label544;
                                                                  }

                                                                  var49 = a6.W(var45, var57);
                                                                  break label544;
                                                               }

                                                               var49 = a6.U(var45);
                                                               break label544;
                                                            }

                                                            var49 = a6.L(var45);
                                                            break label544;
                                                         }

                                                         var49 = a6.Q(var45, var58);
                                                         break label544;
                                                      }

                                                      var49 = a6.I(var45, var59);
                                                      break label544;
                                                   }

                                                   var49 = a6.z(var45, (x7)h9.B(var1, var46), this.u(var41));
                                                   break label544;
                                                }

                                                var40.putInt(var1, (long)var48, var61);
                                                break label543;
                                             }

                                             var49 = a6.w(var45);
                                             break label544;
                                          }

                                          var49 = a6.s(var45);
                                          break label544;
                                       }

                                       var49 = a6.E(var45, var50);
                                       break label544;
                                    }

                                    var49 = a6.G(var45, var52);
                                    break label544;
                                 }

                                 var49 = a6.M(var45, var54);
                                 break label544;
                              }

                              var49 = a6.J(var45);
                              break label544;
                           }

                           var49 = a6.S(var45);
                           break label544;
                        }

                        var49 = a6.x(var45);
                        break label544;
                     }

                     var49 = a6.A(var45, (String)var55);
                     break label544;
                  }

                  var49 = a6.y(var45, (n5)var55);
                  break label544;
               }

               var42 += var61 + a6.k(var45) + a6.m(var61);
               continue;
            }

            var42 += var49;
         }

         if ((c9)this.j != null) {
            return var42 + ((o6)var1).zzbmp.a();
         } else {
            throw null;
         }
      } else {
         Unsafe var4 = n;
         int var5 = -1;
         int var6 = 0;
         int var7 = 0;

         for(int var8 = 0; var6 < this.a.length; var5 = var5) {
            int var16 = this.w(var6);
            int[] var17 = this.a;
            int var18 = var17[var6];
            int var19 = (var3 & var16) >>> 20;
            int var20;
            int var21;
            if (var19 <= 17) {
               var20 = var17[var6 + 2];
               int var39 = var20 & 1048575;
               var21 = 1 << (var20 >>> 20);
               if (var39 != var5) {
                  var8 = var4.getInt(var1, (long)var39);
                  var5 = var39;
               }
            } else {
               if (this.e && var19 >= l6.K.a() && var19 <= l6.X.a()) {
                  var20 = 1048575 & this.a[var6 + 2];
               } else {
                  var20 = 0;
               }

               var21 = 0;
            }

            label754: {
               int var26;
               label803: {
                  int var38;
                  label745: {
                     long var24;
                     label804: {
                        long var36;
                        label805: {
                           int var35;
                           label740: {
                              label739: {
                                 label738: {
                                    int var34;
                                    label737: {
                                       int var33;
                                       label736: {
                                          label735: {
                                             Object var32;
                                             label734: {
                                                label733: {
                                                   label732: {
                                                      label731: {
                                                         label730: {
                                                            int var31;
                                                            label729: {
                                                               long var29;
                                                               label728: {
                                                                  long var27;
                                                                  label727: {
                                                                     label726: {
                                                                        label725: {
                                                                           label724: {
                                                                              int var22 = var16 & 1048575;
                                                                              var24 = (long)var22;
                                                                              switch(var19) {
                                                                              case 0:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label725;
                                                                              case 1:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label726;
                                                                              case 2:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 var27 = var4.getLong(var1, var24);
                                                                                 break label727;
                                                                              case 3:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 var29 = var4.getLong(var1, var24);
                                                                                 break label728;
                                                                              case 4:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 var31 = var4.getInt(var1, var24);
                                                                                 break label729;
                                                                              case 5:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label730;
                                                                              case 6:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label731;
                                                                              case 7:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label732;
                                                                              case 8:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 var32 = var4.getObject(var1, var24);
                                                                                 if (var32 instanceof n5) {
                                                                                    break label734;
                                                                                 }
                                                                                 break label733;
                                                                              case 9:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label735;
                                                                              case 10:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }
                                                                                 break;
                                                                              case 11:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 var33 = var4.getInt(var1, var24);
                                                                                 break label736;
                                                                              case 12:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 var34 = var4.getInt(var1, var24);
                                                                                 break label737;
                                                                              case 13:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label738;
                                                                              case 14:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label739;
                                                                              case 15:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 var35 = var4.getInt(var1, var24);
                                                                                 break label740;
                                                                              case 16:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 var36 = var4.getLong(var1, var24);
                                                                                 break label805;
                                                                              case 17:
                                                                                 if ((var8 & var21) == 0) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label804;
                                                                              case 18:
                                                                              case 23:
                                                                              case 32:
                                                                                 var26 = o8.Y(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 19:
                                                                              case 24:
                                                                              case 31:
                                                                                 var26 = o8.X(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 20:
                                                                                 var26 = o8.P(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 21:
                                                                                 var26 = o8.Q(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 22:
                                                                                 var26 = o8.U(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 25:
                                                                                 var26 = o8.Z(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 26:
                                                                                 var26 = o8.k(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 27:
                                                                                 var26 = o8.l(var18, (List)var4.getObject(var1, var24), this.u(var6));
                                                                                 break label803;
                                                                              case 28:
                                                                                 var26 = o8.n(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 29:
                                                                                 var26 = o8.V(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 30:
                                                                                 var26 = o8.T(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 33:
                                                                                 var26 = o8.W(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 34:
                                                                                 var26 = o8.R(var18, (List)var4.getObject(var1, var24));
                                                                                 break label803;
                                                                              case 35:
                                                                                 var38 = o8.L((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 36:
                                                                                 var38 = o8.J((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 37:
                                                                                 var38 = o8.q((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 38:
                                                                                 var38 = o8.t((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 39:
                                                                                 var38 = o8.A((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 40:
                                                                                 var38 = o8.L((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 41:
                                                                                 var38 = o8.J((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 42:
                                                                                 var38 = o8.N((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 43:
                                                                                 var38 = o8.C((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 44:
                                                                                 var38 = o8.y((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 45:
                                                                                 var38 = o8.J((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 46:
                                                                                 var38 = o8.L((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 47:
                                                                                 var38 = o8.E((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 48:
                                                                                 var38 = o8.w((List)var4.getObject(var1, var24));
                                                                                 if (var38 <= 0) {
                                                                                    break label754;
                                                                                 }

                                                                                 if (!this.e) {
                                                                                    break label745;
                                                                                 }
                                                                                 break label724;
                                                                              case 49:
                                                                                 var26 = o8.o(var18, (List)var4.getObject(var1, var24), this.u(var6));
                                                                                 break label803;
                                                                              case 50:
                                                                                 var26 = this.l.g(var18, var4.getObject(var1, var24), this.v(var6));
                                                                                 break label803;
                                                                              case 51:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label725;
                                                                              case 52:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label726;
                                                                              case 53:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }

                                                                                 var27 = D(var1, var24);
                                                                                 break label727;
                                                                              case 54:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }

                                                                                 var29 = D(var1, var24);
                                                                                 break label728;
                                                                              case 55:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }

                                                                                 var31 = C(var1, var24);
                                                                                 break label729;
                                                                              case 56:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label730;
                                                                              case 57:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label731;
                                                                              case 58:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label732;
                                                                              case 59:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }

                                                                                 var32 = var4.getObject(var1, var24);
                                                                                 if (var32 instanceof n5) {
                                                                                    break label734;
                                                                                 }
                                                                                 break label733;
                                                                              case 60:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label735;
                                                                              case 61:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }
                                                                                 break;
                                                                              case 62:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }

                                                                                 var33 = C(var1, var24);
                                                                                 break label736;
                                                                              case 63:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }

                                                                                 var34 = C(var1, var24);
                                                                                 break label737;
                                                                              case 64:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label738;
                                                                              case 65:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label739;
                                                                              case 66:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }

                                                                                 var35 = C(var1, var24);
                                                                                 break label740;
                                                                              case 67:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }

                                                                                 var36 = D(var1, var24);
                                                                                 break label805;
                                                                              case 68:
                                                                                 if (!this.o(var1, var18, var6)) {
                                                                                    break label754;
                                                                                 }
                                                                                 break label804;
                                                                              default:
                                                                                 break label754;
                                                                              }

                                                                              var32 = var4.getObject(var1, var24);
                                                                              break label734;
                                                                           }

                                                                           var4.putInt(var1, (long)var20, var38);
                                                                           break label745;
                                                                        }

                                                                        var26 = a6.w(var18);
                                                                        break label803;
                                                                     }

                                                                     var26 = a6.s(var18);
                                                                     break label803;
                                                                  }

                                                                  var26 = a6.E(var18, var27);
                                                                  break label803;
                                                               }

                                                               var26 = a6.G(var18, var29);
                                                               break label803;
                                                            }

                                                            var26 = a6.M(var18, var31);
                                                            break label803;
                                                         }

                                                         var26 = a6.J(var18);
                                                         break label803;
                                                      }

                                                      var26 = a6.S(var18);
                                                      break label803;
                                                   }

                                                   var26 = a6.x(var18);
                                                   break label803;
                                                }

                                                var26 = a6.A(var18, (String)var32);
                                                break label803;
                                             }

                                             var26 = a6.y(var18, (n5)var32);
                                             break label803;
                                          }

                                          var26 = o8.j(var18, var4.getObject(var1, var24), this.u(var6));
                                          break label803;
                                       }

                                       var26 = a6.P(var18, var33);
                                       break label803;
                                    }

                                    var26 = a6.W(var18, var34);
                                    break label803;
                                 }

                                 var26 = a6.U(var18);
                                 break label803;
                              }

                              var26 = a6.L(var18);
                              break label803;
                           }

                           var26 = a6.Q(var18, var35);
                           break label803;
                        }

                        var26 = a6.I(var18, var36);
                        break label803;
                     }

                     var26 = a6.z(var18, (x7)var4.getObject(var1, var24), this.u(var6));
                     break label803;
                  }

                  var7 += var38 + a6.k(var18) + a6.m(var38);
                  break label754;
               }

               var7 += var26;
            }

            var6 += 3;
            var3 = 267386880;
         }

         if ((c9)this.j == null) {
            throw null;
         } else {
            int var9 = var7 + ((o6)var1).zzbmp.a();
            if (!this.c) {
               return var9;
            } else if ((d6)this.k == null) {
               throw null;
            } else {
               f6 var10 = ((b.b.b.b.d.c.o6.b)var1).zzbms;
               int var11 = 0;

               int var12;
               for(var12 = 0; var11 < var10.a.l(); ++var11) {
                  Entry var15 = var10.a.h(var11);
                  var12 += f6.h((h6)var15.getKey(), var15.getValue());
               }

               Entry var14;
               for(Iterator var13 = var10.a.m().iterator(); var13.hasNext(); var12 += f6.h((h6)var14.getKey(), var14.getValue())) {
                  var14 = (Entry)var13.next();
               }

               return var9 + var12;
            }
         }
      }
   }

   public final void g(Object var1, v9 var2) {
      c6 var3 = (c6)var2;
      if (var3 != null) {
         if (!this.d) {
            this.s(var1, var2);
         } else {
            Entry var4;
            label395: {
               if (this.c) {
                  if ((d6)this.k == null) {
                     throw null;
                  }

                  f6 var31 = ((b.b.b.b.d.c.o6.b)var1).zzbms;
                  if (!var31.a.isEmpty()) {
                     var4 = (Entry)var31.c().next();
                     break label395;
                  }
               }

               var4 = null;
            }

            int var5 = this.a.length;

            for(int var6 = 0; var6 < var5; var6 += 3) {
               int var7 = this.w(var6);
               int[] var8 = this.a;
               int var9 = var8[var6];
               if (var4 != null) {
                  this.k.a(var4);
                  throw null;
               }

               float var13;
               label439: {
                  double var11;
                  label351: {
                     label350: {
                        long var29;
                        label349: {
                           int var28;
                           label348: {
                              long var26;
                              label347: {
                                 int var25;
                                 label346: {
                                    int var24;
                                    label345: {
                                       int var23;
                                       label344: {
                                          label343: {
                                             label342: {
                                                label341: {
                                                   boolean var22;
                                                   label340: {
                                                      int var21;
                                                      label339: {
                                                         long var19;
                                                         label338: {
                                                            int var18;
                                                            label337: {
                                                               long var16;
                                                               label336: {
                                                                  long var14;
                                                                  switch((267386880 & var7) >>> 20) {
                                                                  case 0:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var11 = h9.A(var1, (long)(var7 & 1048575));
                                                                     break label351;
                                                                  case 1:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var13 = h9.z(var1, (long)(var7 & 1048575));
                                                                     break label439;
                                                                  case 2:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var14 = h9.t(var1, (long)(var7 & 1048575));
                                                                     break;
                                                                  case 3:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var16 = h9.t(var1, (long)(var7 & 1048575));
                                                                     break label336;
                                                                  case 4:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var18 = h9.r(var1, (long)(var7 & 1048575));
                                                                     break label337;
                                                                  case 5:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var19 = h9.t(var1, (long)(var7 & 1048575));
                                                                     break label338;
                                                                  case 6:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var21 = h9.r(var1, (long)(var7 & 1048575));
                                                                     break label339;
                                                                  case 7:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var22 = h9.x(var1, (long)(var7 & 1048575));
                                                                     break label340;
                                                                  case 8:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }
                                                                     break label341;
                                                                  case 9:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }
                                                                     break label342;
                                                                  case 10:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }
                                                                     break label343;
                                                                  case 11:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var23 = h9.r(var1, (long)(var7 & 1048575));
                                                                     break label344;
                                                                  case 12:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var24 = h9.r(var1, (long)(var7 & 1048575));
                                                                     break label345;
                                                                  case 13:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var25 = h9.r(var1, (long)(var7 & 1048575));
                                                                     break label346;
                                                                  case 14:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var26 = h9.t(var1, (long)(var7 & 1048575));
                                                                     break label347;
                                                                  case 15:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var28 = h9.r(var1, (long)(var7 & 1048575));
                                                                     break label348;
                                                                  case 16:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }

                                                                     var29 = h9.t(var1, (long)(var7 & 1048575));
                                                                     break label349;
                                                                  case 17:
                                                                     if (!this.n(var1, var6)) {
                                                                        continue;
                                                                     }
                                                                     break label350;
                                                                  case 18:
                                                                     o8.c(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 19:
                                                                     o8.i(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 20:
                                                                     o8.m(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 21:
                                                                     o8.p(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 22:
                                                                     o8.z(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 23:
                                                                     o8.u(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 24:
                                                                     o8.F(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 25:
                                                                     o8.O(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 26:
                                                                     o8.a(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2);
                                                                     continue;
                                                                  case 27:
                                                                     o8.b(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, this.u(var6));
                                                                     continue;
                                                                  case 28:
                                                                     o8.g(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2);
                                                                     continue;
                                                                  case 29:
                                                                     o8.B(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 30:
                                                                     o8.M(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 31:
                                                                     o8.K(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 32:
                                                                     o8.x(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 33:
                                                                     o8.D(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 34:
                                                                     o8.r(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, false);
                                                                     continue;
                                                                  case 35:
                                                                     o8.c(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 36:
                                                                     o8.i(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 37:
                                                                     o8.m(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 38:
                                                                     o8.p(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 39:
                                                                     o8.z(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 40:
                                                                     o8.u(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 41:
                                                                     o8.F(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 42:
                                                                     o8.O(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 43:
                                                                     o8.B(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 44:
                                                                     o8.M(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 45:
                                                                     o8.K(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 46:
                                                                     o8.x(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 47:
                                                                     o8.D(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 48:
                                                                     o8.r(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, true);
                                                                     continue;
                                                                  case 49:
                                                                     o8.h(var8[var6], (List)h9.B(var1, (long)(var7 & 1048575)), var2, this.u(var6));
                                                                     continue;
                                                                  case 50:
                                                                     this.l(var2, var9, h9.B(var1, (long)(var7 & 1048575)), var6);
                                                                     continue;
                                                                  case 51:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var11 = A(var1, (long)(var7 & 1048575));
                                                                     break label351;
                                                                  case 52:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var13 = B(var1, (long)(var7 & 1048575));
                                                                     break label439;
                                                                  case 53:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var14 = D(var1, (long)(var7 & 1048575));
                                                                     break;
                                                                  case 54:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var16 = D(var1, (long)(var7 & 1048575));
                                                                     break label336;
                                                                  case 55:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var18 = C(var1, (long)(var7 & 1048575));
                                                                     break label337;
                                                                  case 56:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var19 = D(var1, (long)(var7 & 1048575));
                                                                     break label338;
                                                                  case 57:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var21 = C(var1, (long)(var7 & 1048575));
                                                                     break label339;
                                                                  case 58:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var22 = E(var1, (long)(var7 & 1048575));
                                                                     break label340;
                                                                  case 59:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }
                                                                     break label341;
                                                                  case 60:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }
                                                                     break label342;
                                                                  case 61:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }
                                                                     break label343;
                                                                  case 62:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var23 = C(var1, (long)(var7 & 1048575));
                                                                     break label344;
                                                                  case 63:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var24 = C(var1, (long)(var7 & 1048575));
                                                                     break label345;
                                                                  case 64:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var25 = C(var1, (long)(var7 & 1048575));
                                                                     break label346;
                                                                  case 65:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var26 = D(var1, (long)(var7 & 1048575));
                                                                     break label347;
                                                                  case 66:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var28 = C(var1, (long)(var7 & 1048575));
                                                                     break label348;
                                                                  case 67:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }

                                                                     var29 = D(var1, (long)(var7 & 1048575));
                                                                     break label349;
                                                                  case 68:
                                                                     if (!this.o(var1, var9, var6)) {
                                                                        continue;
                                                                     }
                                                                     break label350;
                                                                  default:
                                                                     continue;
                                                                  }

                                                                  var3.D(var9, var14);
                                                                  continue;
                                                               }

                                                               var3.d(var9, var16);
                                                               continue;
                                                            }

                                                            var3.v(var9, var18);
                                                            continue;
                                                         }

                                                         var3.s(var9, var19);
                                                         continue;
                                                      }

                                                      var3.B(var9, var21);
                                                      continue;
                                                   }

                                                   var3.r(var9, var22);
                                                   continue;
                                                }

                                                j(var9, h9.B(var1, (long)(var7 & 1048575)), var2);
                                                continue;
                                             }

                                             var3.g(var9, h9.B(var1, (long)(var7 & 1048575)), this.u(var6));
                                             continue;
                                          }

                                          var3.e(var9, (n5)h9.B(var1, (long)(var7 & 1048575)));
                                          continue;
                                       }

                                       var3.x(var9, var23);
                                       continue;
                                    }

                                    var3.M(var9, var24);
                                    continue;
                                 }

                                 var3.L(var9, var25);
                                 continue;
                              }

                              var3.F(var9, var26);
                              continue;
                           }

                           var3.z(var9, var28);
                           continue;
                        }

                        var3.l(var9, var29);
                        continue;
                     }

                     var3.n(var9, h9.B(var1, (long)(var7 & 1048575)), this.u(var6));
                     continue;
                  }

                  var3.b(var9, var11);
                  continue;
               }

               var3.c(var9, var13);
            }

            if (var4 == null) {
               k(this.j, var1, var2);
            } else {
               this.k.b(var2, var4);
               throw null;
            }
         }
      } else {
         throw null;
      }
   }
}
