package b.b.b.b.d.c;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

final class c6 implements v9 {
   private final a6 a;

   private c6(a6 var1) {
      p6.d(var1, "output");
      this.a = var1;
      var1.a = this;
   }

   public static c6 a(a6 var0) {
      c6 var1 = var0.a;
      return var1 != null ? var1 : new c6(var0);
   }

   public final void A(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (!var3) {
         while(var4 < var2.size()) {
            a6 var5 = this.a;
            double var6 = (Double)var2.get(var4);
            if (var5 == null) {
               throw null;
            }

            long var8 = Double.doubleToRawLongBits(var6);
            a6.b var10 = (a6.b)var5;
            var10.g(1 | var1 << 3);
            var10.V(var8);
            ++var4;
         }

      } else {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var11 = 0;

         int var12;
         for(var12 = 0; var11 < var2.size(); ++var11) {
            (Double)var2.get(var11);
            var12 += 8;
         }

         this.a.g(var12);

         while(var4 < var2.size()) {
            a6 var13 = this.a;
            double var14 = (Double)var2.get(var4);
            if (var13 == null) {
               throw null;
            }

            var13.V(Double.doubleToRawLongBits(var14));
            ++var4;
         }

      }
   }

   public final void B(int var1, int var2) {
      a6.b var3 = (a6.b)this.a;
      var3.g(5 | var1 << 3);
      var3.j(var2);
   }

   public final void C(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var5 = 0;

         int var6;
         for(var6 = 0; var5 < var2.size(); ++var5) {
            var6 += a6.l((Integer)var2.get(var5));
         }

         this.a.g(var6);

         while(var4 < var2.size()) {
            this.a.f((Integer)var2.get(var4));
            ++var4;
         }

      } else {
         while(var4 < var2.size()) {
            this.a.H(var1, (Integer)var2.get(var4));
            ++var4;
         }

      }
   }

   public final void D(int var1, long var2) {
      a6.b var4 = (a6.b)this.a;
      var4.g(0 | var1 << 3);
      var4.R(var2);
   }

   public final void E(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var9 = 0;

         int var10;
         for(var10 = 0; var9 < var2.size(); ++var9) {
            (Boolean)var2.get(var9);
            ++var10;
         }

         this.a.g(var10);

         while(var4 < var2.size()) {
            this.a.C((byte)(Boolean)var2.get(var4));
            ++var4;
         }

      } else {
         for(int var5 = 0; var5 < var2.size(); ++var5) {
            a6 var6 = this.a;
            byte var7 = (Boolean)var2.get(var5);
            a6.b var8 = (a6.b)var6;
            var8.g(0 | var1 << 3);
            var8.C((byte)var7);
         }

      }
   }

   public final void F(int var1, long var2) {
      a6.b var4 = (a6.b)this.a;
      var4.g(1 | var1 << 3);
      var4.V(var2);
   }

   public final void G(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var9 = 0;

         int var10;
         for(var10 = 0; var9 < var2.size(); ++var9) {
            var10 += a6.m((Integer)var2.get(var9));
         }

         this.a.g(var10);

         while(var4 < var2.size()) {
            this.a.g((Integer)var2.get(var4));
            ++var4;
         }

      } else {
         for(int var5 = 0; var5 < var2.size(); ++var5) {
            a6 var6 = this.a;
            int var7 = (Integer)var2.get(var5);
            a6.b var8 = (a6.b)var6;
            var8.g(0 | var1 << 3);
            var8.g(var7);
         }

      }
   }

   public final void H(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var8 = 0;

         int var9;
         for(var9 = 0; var8 < var2.size(); ++var8) {
            (Integer)var2.get(var8);
            var9 += 4;
         }

         this.a.g(var9);

         while(var4 < var2.size()) {
            this.a.j((Integer)var2.get(var4));
            ++var4;
         }

      } else {
         while(var4 < var2.size()) {
            a6 var5 = this.a;
            int var6 = (Integer)var2.get(var4);
            a6.b var7 = (a6.b)var5;
            var7.g(5 | var1 << 3);
            var7.j(var6);
            ++var4;
         }

      }
   }

   public final void I(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var9 = 0;

         int var10;
         for(var10 = 0; var9 < var2.size(); ++var9) {
            (Long)var2.get(var9);
            var10 += 8;
         }

         this.a.g(var10);

         while(var4 < var2.size()) {
            this.a.V((Long)var2.get(var4));
            ++var4;
         }

      } else {
         while(var4 < var2.size()) {
            a6 var5 = this.a;
            long var6 = (Long)var2.get(var4);
            a6.b var8 = (a6.b)var5;
            var8.g(1 | var1 << 3);
            var8.V(var6);
            ++var4;
         }

      }
   }

   public final void J(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var5 = 0;

         int var6;
         for(var6 = 0; var5 < var2.size(); ++var5) {
            var6 += a6.n((Integer)var2.get(var5));
         }

         this.a.g(var6);

         while(var4 < var2.size()) {
            this.a.h((Integer)var2.get(var4));
            ++var4;
         }

      } else {
         while(var4 < var2.size()) {
            this.a.K(var1, (Integer)var2.get(var4));
            ++var4;
         }

      }
   }

   public final void K(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var5 = 0;

         int var6;
         for(var6 = 0; var5 < var2.size(); ++var5) {
            var6 += a6.Z((Long)var2.get(var5));
         }

         this.a.g(var6);

         while(var4 < var2.size()) {
            this.a.T((Long)var2.get(var4));
            ++var4;
         }

      } else {
         while(var4 < var2.size()) {
            this.a.v(var1, (Long)var2.get(var4));
            ++var4;
         }

      }
   }

   public final void L(int var1, int var2) {
      a6.b var3 = (a6.b)this.a;
      var3.g(5 | var1 << 3);
      var3.j(var2);
   }

   public final void M(int var1, int var2) {
      this.a.H(var1, var2);
   }

   public final void b(int var1, double var2) {
      a6 var4 = this.a;
      if (var4 != null) {
         long var5 = Double.doubleToRawLongBits(var2);
         a6.b var7 = (a6.b)var4;
         var7.g(1 | var1 << 3);
         var7.V(var5);
      } else {
         throw null;
      }
   }

   public final void c(int var1, float var2) {
      a6 var3 = this.a;
      if (var3 != null) {
         int var4 = Float.floatToRawIntBits(var2);
         a6.b var5 = (a6.b)var3;
         var5.g(5 | var1 << 3);
         var5.j(var4);
      } else {
         throw null;
      }
   }

   public final void d(int var1, long var2) {
      a6.b var4 = (a6.b)this.a;
      var4.g(0 | var1 << 3);
      var4.R(var2);
   }

   public final void e(int var1, n5 var2) {
      a6.b var3 = (a6.b)this.a;
      var3.g(2 | var1 << 3);
      var3.f0(var2);
   }

   public final void f(int var1, s7 var2, Map var3) {
      Iterator var4 = var3.entrySet().iterator();
      if (var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         ((a6.b)this.a).g(2 | var1 << 3);
         var5.getKey();
         var5.getValue();
         throw null;
      }
   }

   public final void g(int var1, Object var2, m8 var3) {
      a6 var4 = this.a;
      x7 var5 = (x7)var2;
      a6.b var6 = (a6.b)var4;
      var6.g(2 | var1 << 3);
      h5 var7 = (h5)var5;
      int var8 = var7.g();
      if (var8 == -1) {
         var8 = var3.f(var7);
         var7.e(var8);
      }

      var6.g(var8);
      var3.g(var5, var6.a);
   }

   public final void h(int var1, List var2) {
      boolean var3 = var2 instanceof h7;
      int var4 = 0;
      if (var3) {
         for(h7 var8 = (h7)var2; var4 < var2.size(); ++var4) {
            Object var9 = var8.N(var4);
            if (var9 instanceof String) {
               a6 var13 = this.a;
               String var14 = (String)var9;
               a6.b var15 = (a6.b)var13;
               var15.g(2 | var1 << 3);
               var15.g0(var14);
            } else {
               a6 var10 = this.a;
               n5 var11 = (n5)var9;
               a6.b var12 = (a6.b)var10;
               var12.g(2 | var1 << 3);
               var12.f0(var11);
            }
         }

      } else {
         while(var4 < var2.size()) {
            a6 var5 = this.a;
            String var6 = (String)var2.get(var4);
            a6.b var7 = (a6.b)var5;
            var7.g(2 | var1 << 3);
            var7.g0(var6);
            ++var4;
         }

      }
   }

   public final void i(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var5 = 0;

         int var6;
         for(var6 = 0; var5 < var2.size(); ++var5) {
            var6 += a6.l((Integer)var2.get(var5));
         }

         this.a.g(var6);

         while(var4 < var2.size()) {
            this.a.f((Integer)var2.get(var4));
            ++var4;
         }

      } else {
         while(var4 < var2.size()) {
            this.a.H(var1, (Integer)var2.get(var4));
            ++var4;
         }

      }
   }

   public final void j(int var1) {
      ((a6.b)this.a).g(3 | var1 << 3);
   }

   public final void k(int var1) {
      ((a6.b)this.a).g(4 | var1 << 3);
   }

   public final void l(int var1, long var2) {
      this.a.v(var1, var2);
   }

   public final void m(int var1, Object var2) {
      if (var2 instanceof n5) {
         a6 var6 = this.a;
         n5 var7 = (n5)var2;
         a6.b var8 = (a6.b)var6;
         var8.h0(1, 3);
         var8.i0(2, var1);
         var8.e0(3, var7);
         var8.h0(1, 4);
      } else {
         a6 var3 = this.a;
         x7 var4 = (x7)var2;
         a6.b var5 = (a6.b)var3;
         var5.h0(1, 3);
         var5.i0(2, var1);
         var5.h0(3, 2);
         var5.g(var4.d());
         var4.b(var5);
         var5.h0(1, 4);
      }
   }

   public final void n(int var1, Object var2, m8 var3) {
      a6 var4 = this.a;
      x7 var5 = (x7)var2;
      a6.b var6 = (a6.b)var4;
      int var7 = var1 << 3;
      var6.g(var7 | 3);
      var3.g(var5, var4.a);
      ((a6.b)var4).g(var7 | 4);
   }

   public final void o(int var1, String var2) {
      a6.b var3 = (a6.b)this.a;
      var3.g(2 | var1 << 3);
      var3.g0(var2);
   }

   public final void p(int var1, List var2) {
      for(int var3 = 0; var3 < var2.size(); ++var3) {
         a6 var4 = this.a;
         n5 var5 = (n5)var2.get(var3);
         a6.b var6 = (a6.b)var4;
         var6.g(2 | var1 << 3);
         var6.f0(var5);
      }

   }

   public final void q(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var8 = 0;

         int var9;
         for(var9 = 0; var8 < var2.size(); ++var8) {
            (Integer)var2.get(var8);
            var9 += 4;
         }

         this.a.g(var9);

         while(var4 < var2.size()) {
            this.a.j((Integer)var2.get(var4));
            ++var4;
         }

      } else {
         while(var4 < var2.size()) {
            a6 var5 = this.a;
            int var6 = (Integer)var2.get(var4);
            a6.b var7 = (a6.b)var5;
            var7.g(5 | var1 << 3);
            var7.j(var6);
            ++var4;
         }

      }
   }

   public final void r(int var1, boolean var2) {
      a6.b var3 = (a6.b)this.a;
      var3.g(0 | var1 << 3);
      var3.C((byte)var2);
   }

   public final void s(int var1, long var2) {
      a6.b var4 = (a6.b)this.a;
      var4.g(1 | var1 << 3);
      var4.V(var2);
   }

   public final void t(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var10 = 0;

         int var11;
         for(var11 = 0; var10 < var2.size(); ++var10) {
            var11 += a6.Y((Long)var2.get(var10));
         }

         this.a.g(var11);

         while(var4 < var2.size()) {
            this.a.R((Long)var2.get(var4));
            ++var4;
         }

      } else {
         for(int var5 = 0; var5 < var2.size(); ++var5) {
            a6 var6 = this.a;
            long var7 = (Long)var2.get(var5);
            a6.b var9 = (a6.b)var6;
            var9.g(0 | var1 << 3);
            var9.R(var7);
         }

      }
   }

   public final void u(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var10 = 0;

         int var11;
         for(var11 = 0; var10 < var2.size(); ++var10) {
            var11 += a6.Y((Long)var2.get(var10));
         }

         this.a.g(var11);

         while(var4 < var2.size()) {
            this.a.R((Long)var2.get(var4));
            ++var4;
         }

      } else {
         for(int var5 = 0; var5 < var2.size(); ++var5) {
            a6 var6 = this.a;
            long var7 = (Long)var2.get(var5);
            a6.b var9 = (a6.b)var6;
            var9.g(0 | var1 << 3);
            var9.R(var7);
         }

      }
   }

   public final void v(int var1, int var2) {
      this.a.H(var1, var2);
   }

   public final void w(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (var3) {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var9 = 0;

         int var10;
         for(var10 = 0; var9 < var2.size(); ++var9) {
            (Long)var2.get(var9);
            var10 += 8;
         }

         this.a.g(var10);

         while(var4 < var2.size()) {
            this.a.V((Long)var2.get(var4));
            ++var4;
         }

      } else {
         while(var4 < var2.size()) {
            a6 var5 = this.a;
            long var6 = (Long)var2.get(var4);
            a6.b var8 = (a6.b)var5;
            var8.g(1 | var1 << 3);
            var8.V(var6);
            ++var4;
         }

      }
   }

   public final void x(int var1, int var2) {
      a6.b var3 = (a6.b)this.a;
      var3.g(0 | var1 << 3);
      var3.g(var2);
   }

   public final void y(int var1, List var2, boolean var3) {
      int var4 = 0;
      if (!var3) {
         while(var4 < var2.size()) {
            a6 var5 = this.a;
            float var6 = (Float)var2.get(var4);
            if (var5 == null) {
               throw null;
            }

            int var7 = Float.floatToRawIntBits(var6);
            a6.b var8 = (a6.b)var5;
            var8.g(5 | var1 << 3);
            var8.j(var7);
            ++var4;
         }

      } else {
         ((a6.b)this.a).g(2 | var1 << 3);
         int var9 = 0;

         int var10;
         for(var10 = 0; var9 < var2.size(); ++var9) {
            (Float)var2.get(var9);
            var10 += 4;
         }

         this.a.g(var10);

         while(var4 < var2.size()) {
            a6 var11 = this.a;
            float var12 = (Float)var2.get(var4);
            if (var11 == null) {
               throw null;
            }

            var11.j(Float.floatToRawIntBits(var12));
            ++var4;
         }

      }
   }

   public final void z(int var1, int var2) {
      this.a.K(var1, var2);
   }
}
