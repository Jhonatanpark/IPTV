package b.b.a;

public enum b {
   a,
   b,
   c;

   static {
      b var0 = new b("FEMALE", 2);
      c = var0;
      b[] var1 = new b[]{a, b, var0};
   }
}
