package b.b.a;

public enum a {
   b("Invalid Ad request."),
   c("Ad request successful, but no ad returned due to lack of ad inventory."),
   d("A network error occurred."),
   e;

   private final String a;

   static {
      a var0 = new a("INTERNAL_ERROR", 3, "There was an internal error.");
      e = var0;
      a[] var1 = new a[]{b, c, d, var0};
   }

   private a(String var3) {
      this.a = var3;
   }

   public final String toString() {
      return this.a;
   }
}
