package c.a;

public interface b extends d.a.a {
}
