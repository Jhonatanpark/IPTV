package c.a;

import com.google.android.gms.cast.framework.f;

public final class c implements b {
   private final Object a;

   private c(Object var1) {
      this.a = var1;
   }

   public static b a(Object var0) {
      f.q(var0, "instance cannot be null");
      return new c(var0);
   }

   public Object get() {
      return this.a;
   }
}
