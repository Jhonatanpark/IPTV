package c.a;

public final class a implements d.a.a {
   private static final Object c = new Object();
   private volatile d.a.a a;
   private volatile Object b;

   private a(d.a.a var1) {
      this.b = c;
      this.a = var1;
   }

   public static d.a.a a(d.a.a var0) {
      return (d.a.a)(var0 instanceof a ? var0 : new a(var0));
   }

   public static Object b(Object var0, Object var1) {
      boolean var2;
      if (var0 != c) {
         var2 = true;
      } else {
         var2 = false;
      }

      if (var2) {
         if (var0 == var1) {
            return var1;
         } else {
            StringBuilder var3 = new StringBuilder();
            var3.append("Scoped provider was invoked recursively returning different results: ");
            var3.append(var0);
            var3.append(" & ");
            var3.append(var1);
            var3.append(". This is likely due to a circular dependency.");
            throw new IllegalStateException(var3.toString());
         }
      } else {
         return var1;
      }
   }

   public Object get() {
      Object var1 = this.b;
      if (var1 == c) {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label136: {
            Object var3;
            try {
               var3 = this.b;
               if (var3 == c) {
                  var3 = this.a.get();
                  b(this.b, var3);
                  this.b = var3;
                  this.a = null;
               }
            } catch (Throwable var17) {
               var10000 = var17;
               var10001 = false;
               break label136;
            }

            label133:
            try {
               return var3;
            } catch (Throwable var16) {
               var10000 = var16;
               var10001 = false;
               break label133;
            }
         }

         while(true) {
            Throwable var2 = var10000;

            try {
               throw var2;
            } catch (Throwable var15) {
               var10000 = var15;
               var10001 = false;
               continue;
            }
         }
      } else {
         return var1;
      }
   }
}
