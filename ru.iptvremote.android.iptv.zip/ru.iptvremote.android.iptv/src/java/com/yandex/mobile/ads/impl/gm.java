package com.yandex.mobile.ads.impl;

import androidx.annotation.NonNull;

public interface gm {
   void a(@NonNull gl var1);

   void b(@NonNull gl var1);
}
