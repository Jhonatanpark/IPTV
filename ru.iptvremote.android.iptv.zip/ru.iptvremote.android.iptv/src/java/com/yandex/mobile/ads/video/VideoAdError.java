package com.yandex.mobile.ads.video;

import com.yandex.mobile.ads.impl.tw;
import com.yandex.mobile.ads.impl.tx;

public final class VideoAdError {
   private final int a;
   private final String b;
   private final String c;

   private VideoAdError(int var1, String var2) {
      this(var1, var2, (byte)0);
   }

   private VideoAdError(int var1, String var2, byte var3) {
      this.a = var1;
      this.b = var2;
      this.c = null;
   }

   public static VideoAdError createConnectionError(String var0) {
      return new VideoAdError(2, var0);
   }

   public static VideoAdError createInternalError(tx var0) {
      return new VideoAdError(1, "Internal error. Failed to parse response");
   }

   public static VideoAdError createInternalError(String var0) {
      return new VideoAdError(1, var0);
   }

   public static final VideoAdError createNoAdError(tw var0) {
      return new VideoAdError(3, var0.getMessage());
   }

   public static VideoAdError createRetriableError(String var0) {
      return new VideoAdError(4, var0);
   }

   public final int getCode() {
      return this.a;
   }

   public final String getDescription() {
      return this.b;
   }

   public final String getRawResponse() {
      return this.c;
   }

   public interface Code {
   }
}
