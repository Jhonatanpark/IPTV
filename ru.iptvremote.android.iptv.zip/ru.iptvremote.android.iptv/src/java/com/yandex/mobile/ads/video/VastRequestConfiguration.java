package com.yandex.mobile.ads.video;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.yandex.mobile.ads.impl.tm;
import com.yandex.mobile.ads.video.models.vmap.AdBreak;
import java.util.Map;

public final class VastRequestConfiguration {
   @NonNull
   private final AdBreak a;
   @Nullable
   private final Map b;

   private VastRequestConfiguration(@NonNull VastRequestConfiguration.Builder var1) {
      this.a = var1.a;
      this.b = var1.b;
   }

   // $FF: synthetic method
   VastRequestConfiguration(VastRequestConfiguration.Builder var1, byte var2) {
      this(var1);
   }

   @NonNull
   public final AdBreak getAdBreak() {
      return this.a;
   }

   @Nullable
   public final Map getParameters() {
      return this.b;
   }

   public static final class Builder {
      @NonNull
      private final AdBreak a;
      @Nullable
      private Map b;

      public Builder(@NonNull AdBreak var1) {
         this.a = var1;
         tm.a(var1, "AdBreak");
      }

      public final VastRequestConfiguration build() {
         return new VastRequestConfiguration(this, (byte)0);
      }

      @NonNull
      public final VastRequestConfiguration.Builder setParameters(@NonNull Map var1) {
         this.b = var1;
         return this;
      }
   }
}
