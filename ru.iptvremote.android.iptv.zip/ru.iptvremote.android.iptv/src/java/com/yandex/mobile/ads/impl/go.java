package com.yandex.mobile.ads.impl;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import java.util.Map;

final class go {
   static boolean a(@NonNull Map var0) {
      String var1 = (String)var0.get("yandex_mobile_metrica_uuid");
      String var2 = (String)var0.get("yandex_mobile_metrica_get_ad_url");
      return true ^ TextUtils.isEmpty(var1) && true ^ TextUtils.isEmpty(var2);
   }
}
