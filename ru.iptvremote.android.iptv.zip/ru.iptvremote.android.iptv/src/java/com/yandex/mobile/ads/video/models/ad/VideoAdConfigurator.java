package com.yandex.mobile.ads.video.models.ad;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.yandex.mobile.ads.impl.tv;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class VideoAdConfigurator {
   @NonNull
   private final VideoAd mVideoAd;

   public VideoAdConfigurator(@NonNull VideoAd var1) {
      this.mVideoAd = var1;
   }

   public void addTrackingEvents(@NonNull Map var1) {
      Iterator var2 = var1.entrySet().iterator();

      while(var2.hasNext()) {
         Entry var3 = (Entry)var2.next();
         Iterator var4 = ((List)var3.getValue()).iterator();

         while(var4.hasNext()) {
            String var5 = (String)var4.next();
            this.mVideoAd.addTrackingEvent((String)var3.getKey(), var5);
         }
      }

   }

   public void setWrapperConfiguration(@Nullable tv var1) {
      this.mVideoAd.setWrapperConfiguration(var1);
   }
}
