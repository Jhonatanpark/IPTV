package com.yandex.mobile.ads.video;

import android.content.Context;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.yandex.mobile.ads.impl.tm;

public final class BlocksInfoRequest {
   @NonNull
   private final Context a;
   @NonNull
   private final String b;
   @NonNull
   private final String c;
   @Nullable
   private final RequestListener d;

   private BlocksInfoRequest(@NonNull BlocksInfoRequest.Builder var1) {
      this.a = var1.a;
      this.b = var1.b;
      this.c = var1.d;
      this.d = var1.c;
   }

   // $FF: synthetic method
   BlocksInfoRequest(BlocksInfoRequest.Builder var1, byte var2) {
      this(var1);
   }

   @NonNull
   public final String getCategoryId() {
      return this.c;
   }

   @NonNull
   public final Context getContext() {
      return this.a;
   }

   @NonNull
   public final String getPartnerId() {
      return this.b;
   }

   @Nullable
   public final RequestListener getRequestListener() {
      return this.d;
   }

   public static final class Builder {
      @NonNull
      private final Context a;
      @NonNull
      private final String b;
      @Nullable
      private final RequestListener c;
      @NonNull
      private String d = "0";

      public Builder(@NonNull Context var1, @NonNull String var2, @Nullable RequestListener var3) {
         this.a = var1.getApplicationContext();
         this.b = var2;
         this.c = var3;
         tm.a(var2, "PageId");
      }

      public final BlocksInfoRequest build() {
         return new BlocksInfoRequest(this, (byte)0);
      }

      public final BlocksInfoRequest.Builder setCategory(@NonNull String var1) {
         if (!TextUtils.isEmpty(var1)) {
            this.d = var1;
            return this;
         } else {
            throw new IllegalArgumentException("categoryId is empty");
         }
      }
   }
}
