package com.yandex.mobile.ads.video;

import androidx.annotation.NonNull;

public interface RequestListener {
   void onFailure(@NonNull VideoAdError var1);

   void onSuccess(@NonNull Object var1);
}
