package com.yandex.mobile.ads.video;

import androidx.annotation.Nullable;

public interface VmapError {
   int getCode();

   @Nullable
   String getDescription();
}
