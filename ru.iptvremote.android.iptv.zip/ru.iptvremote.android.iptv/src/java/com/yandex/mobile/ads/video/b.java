package com.yandex.mobile.ads.video;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.yandex.mobile.ads.impl.gk;
import com.yandex.mobile.ads.impl.gm;
import com.yandex.mobile.ads.impl.tq;

public final class b {
   private static final Object a = new Object();
   private static volatile b b;
   @NonNull
   private final tq c;
   @NonNull
   private final gm d;
   @Nullable
   private gm e;

   private b(@NonNull Context var1) {
      this.c = tq.a(var1);
      this.d = gk.a(var1);
   }

   @NonNull
   private gm a() {
      gm var1 = this.e;
      return var1 != null ? var1 : this.d;
   }

   @NonNull
   public static b a(@NonNull Context var0) {
      if (b == null) {
         Object var1 = a;
         synchronized(var1){}

         Throwable var10000;
         boolean var10001;
         label144: {
            try {
               if (b == null) {
                  b = new b(var0);
               }
            } catch (Throwable var15) {
               var10000 = var15;
               var10001 = false;
               break label144;
            }

            label141:
            try {
               return b;
            } catch (Throwable var14) {
               var10000 = var14;
               var10001 = false;
               break label141;
            }
         }

         while(true) {
            Throwable var2 = var10000;

            try {
               throw var2;
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               continue;
            }
         }
      } else {
         return b;
      }
   }

   final void a(@NonNull Context var1, @NonNull BlocksInfoRequest var2) {
      gm var3 = this.a();
      this.c.a(var1, var2, var3);
   }

   final void a(@NonNull Context var1, @NonNull VideoAdRequest var2) {
      gm var3 = this.a();
      this.c.a(var1, var2, var3);
   }
}
