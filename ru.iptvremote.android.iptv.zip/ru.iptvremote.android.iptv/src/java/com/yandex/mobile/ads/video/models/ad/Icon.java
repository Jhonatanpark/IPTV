package com.yandex.mobile.ads.video.models.ad;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.yandex.mobile.ads.impl.tm;
import java.util.Arrays;
import java.util.Iterator;

public class Icon implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      // $FF: synthetic method
      public final Object createFromParcel(Parcel var1) {
         return new Icon(var1);
      }
   };
   private String mApiFramework;
   private Long mDuration;
   private Integer mHeight;
   private Icon.IconHorizontalPosition mHorizontalPosition;
   private Long mOffset;
   private String mProgram;
   private Icon.IconResourceType mResourceType;
   private String mResourceUrl;
   private Icon.IconVerticalPosition mVerticalPosition;
   private Integer mWidth;
   private Integer mX;
   private Integer mY;

   public Icon() {
   }

   private Icon(Parcel var1) {
      this.mResourceUrl = var1.readString();
      int var2 = var1.readInt();
      Icon.IconResourceType var3;
      if (var2 == -1) {
         var3 = null;
      } else {
         var3 = Icon.IconResourceType.values()[var2];
      }

      this.mResourceType = var3;
      this.mProgram = var1.readString();
      this.mWidth = (Integer)var1.readValue(Integer.class.getClassLoader());
      this.mHeight = (Integer)var1.readValue(Integer.class.getClassLoader());
      int var4 = var1.readInt();
      Icon.IconHorizontalPosition var5;
      if (var4 == -1) {
         var5 = null;
      } else {
         var5 = Icon.IconHorizontalPosition.values()[var4];
      }

      this.mHorizontalPosition = var5;
      int var6 = var1.readInt();
      Icon.IconVerticalPosition var7;
      if (var6 == -1) {
         var7 = null;
      } else {
         var7 = Icon.IconVerticalPosition.values()[var6];
      }

      this.mVerticalPosition = var7;
      this.mApiFramework = var1.readString();
      this.mOffset = (Long)var1.readValue(Long.class.getClassLoader());
      this.mDuration = (Long)var1.readValue(Long.class.getClassLoader());
      this.mX = (Integer)var1.readValue(Integer.class.getClassLoader());
      this.mY = (Integer)var1.readValue(Integer.class.getClassLoader());
   }

   // $FF: synthetic method
   Icon(Parcel var1, Object var2) {
      this(var1);
   }

   public int describeContents() {
      return 0;
   }

   public String getApiFramework() {
      return this.mApiFramework;
   }

   public Long getDuration() {
      return this.mDuration;
   }

   public Integer getHeight() {
      return this.mHeight;
   }

   public Icon.IconHorizontalPosition getHorizontalPosition() {
      return this.mHorizontalPosition;
   }

   public Long getOffset() {
      return this.mOffset;
   }

   public String getProgram() {
      return this.mProgram;
   }

   public Icon.IconResourceType getResourceType() {
      return this.mResourceType;
   }

   public String getResourceUrl() {
      return this.mResourceUrl;
   }

   public Icon.IconVerticalPosition getVerticalPosition() {
      return this.mVerticalPosition;
   }

   public Integer getWidth() {
      return this.mWidth;
   }

   public Integer getXPosition() {
      return this.mX;
   }

   public Integer getYPosition() {
      return this.mY;
   }

   public void setApiFramework(String var1) {
      this.mApiFramework = var1;
   }

   public void setDuration(String var1) {
      this.mDuration = tm.a(var1);
   }

   public void setHeight(String var1) {
      this.mHeight = tm.b(var1);
   }

   public void setHorizontalPosition(String var1) {
      Icon.IconHorizontalPosition var2 = Icon.IconHorizontalPosition.getPosition(var1);
      this.mHorizontalPosition = var2;
      if (var2 == Icon.IconHorizontalPosition.ICON_HORIZONTAL_POSITION_LEFT_OFFSET) {
         this.mX = tm.b(var1);
      }

   }

   public void setOffset(String var1) {
      this.mOffset = tm.a(var1);
   }

   public void setProgram(String var1) {
      this.mProgram = var1;
   }

   public void setResourceType(String var1) {
      this.mResourceType = Icon.IconResourceType.getConvertType(var1);
   }

   public void setResourceUrl(String var1) {
      this.mResourceUrl = var1;
   }

   public void setVerticalPosition(String var1) {
      Icon.IconVerticalPosition var2 = Icon.IconVerticalPosition.getPosition(var1);
      this.mVerticalPosition = var2;
      if (var2 == Icon.IconVerticalPosition.ICON_VERTICAL_POSITION_TOP_OFFSET) {
         this.mY = tm.b(var1);
      }

   }

   public void setWidth(String var1) {
      this.mWidth = tm.b(var1);
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeString(this.mResourceUrl);
      Icon.IconResourceType var3 = this.mResourceType;
      int var4 = -1;
      int var5;
      if (var3 == null) {
         var5 = -1;
      } else {
         var5 = var3.ordinal();
      }

      var1.writeInt(var5);
      var1.writeString(this.mProgram);
      var1.writeValue(this.mWidth);
      var1.writeValue(this.mHeight);
      Icon.IconHorizontalPosition var6 = this.mHorizontalPosition;
      int var7;
      if (var6 == null) {
         var7 = -1;
      } else {
         var7 = var6.ordinal();
      }

      var1.writeInt(var7);
      Icon.IconVerticalPosition var8 = this.mVerticalPosition;
      if (var8 != null) {
         var4 = var8.ordinal();
      }

      var1.writeInt(var4);
      var1.writeString(this.mApiFramework);
      var1.writeValue(this.mOffset);
      var1.writeValue(this.mDuration);
      var1.writeValue(this.mX);
      var1.writeValue(this.mY);
   }

   public static enum IconHorizontalPosition {
      ICON_HORIZONTAL_POSITION_LEFT("left"),
      ICON_HORIZONTAL_POSITION_LEFT_OFFSET,
      ICON_HORIZONTAL_POSITION_RIGHT("right");

      public final String horizontalPosition;

      static {
         Icon.IconHorizontalPosition var0 = new Icon.IconHorizontalPosition("ICON_HORIZONTAL_POSITION_LEFT_OFFSET", 2, "leftOffset");
         ICON_HORIZONTAL_POSITION_LEFT_OFFSET = var0;
         Icon.IconHorizontalPosition[] var1 = new Icon.IconHorizontalPosition[]{ICON_HORIZONTAL_POSITION_LEFT, ICON_HORIZONTAL_POSITION_RIGHT, var0};
      }

      private IconHorizontalPosition(String var3) {
         this.horizontalPosition = var3;
      }

      private static Icon.IconHorizontalPosition getPosition(String var0) {
         if ("left".equals(var0)) {
            return ICON_HORIZONTAL_POSITION_LEFT;
         } else {
            return "right".equals(var0) ? ICON_HORIZONTAL_POSITION_RIGHT : ICON_HORIZONTAL_POSITION_LEFT_OFFSET;
         }
      }
   }

   public static enum IconResourceType {
      HTML_RESOURCE,
      IFRAME_RESOURCE("IFrameResource"),
      STATIC_RESOURCE("StaticResource");

      public final String resourceType;

      static {
         Icon.IconResourceType var0 = new Icon.IconResourceType("HTML_RESOURCE", 2, "HTMLResource");
         HTML_RESOURCE = var0;
         Icon.IconResourceType[] var1 = new Icon.IconResourceType[]{STATIC_RESOURCE, IFRAME_RESOURCE, var0};
      }

      private IconResourceType(String var3) {
         this.resourceType = var3;
      }

      public static boolean contains(String var0) {
         Iterator var1 = Arrays.asList(values()).iterator();

         do {
            if (!var1.hasNext()) {
               return false;
            }
         } while(!((Icon.IconResourceType)var1.next()).resourceType.equals(var0));

         return true;
      }

      private static Icon.IconResourceType getConvertType(String var0) {
         Iterator var1 = Arrays.asList(values()).iterator();

         Icon.IconResourceType var2;
         do {
            if (!var1.hasNext()) {
               return null;
            }

            var2 = (Icon.IconResourceType)var1.next();
         } while(!var2.resourceType.equals(var0));

         return var2;
      }
   }

   public static enum IconVerticalPosition {
      ICON_VERTICAL_POSITION_BOTTOM("bottom"),
      ICON_VERTICAL_POSITION_TOP("top"),
      ICON_VERTICAL_POSITION_TOP_OFFSET;

      public final String verticalPosition;

      static {
         Icon.IconVerticalPosition var0 = new Icon.IconVerticalPosition("ICON_VERTICAL_POSITION_TOP_OFFSET", 2, "topOffset");
         ICON_VERTICAL_POSITION_TOP_OFFSET = var0;
         Icon.IconVerticalPosition[] var1 = new Icon.IconVerticalPosition[]{ICON_VERTICAL_POSITION_TOP, ICON_VERTICAL_POSITION_BOTTOM, var0};
      }

      private IconVerticalPosition(String var3) {
         this.verticalPosition = var3;
      }

      private static Icon.IconVerticalPosition getPosition(String var0) {
         if ("top".equals(var0)) {
            return ICON_VERTICAL_POSITION_TOP;
         } else {
            return "bottom".equals(var0) ? ICON_VERTICAL_POSITION_BOTTOM : ICON_VERTICAL_POSITION_TOP_OFFSET;
         }
      }
   }
}
