package com.yandex.mobile.ads.video.models.ad;

import androidx.annotation.NonNull;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class CreativeConfigurator {
   @NonNull
   private final Creative mCreative;

   public CreativeConfigurator(@NonNull Creative var1) {
      this.mCreative = var1;
   }

   public void addIcons(@NonNull Collection var1) {
      this.mCreative.addIcons(var1);
   }

   public void addTrackingEvents(@NonNull Map var1) {
      Iterator var2 = var1.entrySet().iterator();

      while(var2.hasNext()) {
         Entry var3 = (Entry)var2.next();
         Iterator var4 = ((List)var3.getValue()).iterator();

         while(var4.hasNext()) {
            String var5 = (String)var4.next();
            this.mCreative.addTrackingEvent((String)var3.getKey(), var5);
         }
      }

   }
}
