package com.yandex.mobile.ads.video.models.blocksinfo;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public final class Block implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      // $FF: synthetic method
      public final Object createFromParcel(Parcel var1) {
         return new Block(var1);
      }
   };
   private int mDuration;
   private String mId;
   private int mPositionsCount;
   private int mStartTime;
   private Block.Type mType;

   private Block() {
   }

   private Block(Parcel var1) {
      this.mId = var1.readString();
      int var2 = var1.readInt();
      Block.Type var3;
      if (var2 == -1) {
         var3 = null;
      } else {
         var3 = Block.Type.values()[var2];
      }

      this.mType = var3;
      this.mStartTime = var1.readInt();
      this.mDuration = var1.readInt();
      this.mPositionsCount = var1.readInt();
   }

   // $FF: synthetic method
   Block(Parcel var1, Object var2) {
      this(var1);
   }

   private void setDuration(String var1) {
      try {
         this.mDuration = Integer.valueOf(var1);
      } catch (Exception var2) {
      }

   }

   private void setId(String var1) {
      this.mId = var1;
   }

   private void setPositionsCount(String var1) {
      try {
         this.mPositionsCount = Integer.valueOf(var1);
      } catch (Exception var2) {
      }

   }

   private void setStartTime(String var1) {
      try {
         this.mStartTime = Integer.valueOf(var1);
      } catch (Exception var2) {
      }

   }

   private void setType(String var1) {
      this.mType = Block.Type.getByType(var1);
   }

   public final int describeContents() {
      return 0;
   }

   public final boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null) {
         if (Block.class != var1.getClass()) {
            return false;
         } else {
            Block var2 = (Block)var1;
            if (this.mDuration != var2.mDuration) {
               return false;
            } else if (this.mPositionsCount != var2.mPositionsCount) {
               return false;
            } else if (this.mStartTime != var2.mStartTime) {
               return false;
            } else {
               String var3 = this.mId;
               if (var3 != null) {
                  if (!var3.equals(var2.mId)) {
                     return false;
                  }
               } else if (var2.mId != null) {
                  return false;
               }

               return this.mType == var2.mType;
            }
         }
      } else {
         return false;
      }
   }

   public final int getDuration() {
      return this.mDuration;
   }

   public final String getId() {
      return this.mId;
   }

   public final int getPositionsCount() {
      return this.mPositionsCount;
   }

   public final int getStartTime() {
      return this.mStartTime;
   }

   public final Block.Type getType() {
      return this.mType;
   }

   public final int hashCode() {
      String var1 = this.mId;
      int var2;
      if (var1 != null) {
         var2 = var1.hashCode();
      } else {
         var2 = 0;
      }

      int var3 = var2 * 31;
      Block.Type var4 = this.mType;
      int var5 = 0;
      if (var4 != null) {
         var5 = var4.hashCode();
      }

      return 31 * (31 * (31 * (var3 + var5) + this.mStartTime) + this.mDuration) + this.mPositionsCount;
   }

   public final void writeToParcel(Parcel var1, int var2) {
      var1.writeString(this.mId);
      Block.Type var3 = this.mType;
      int var4;
      if (var3 == null) {
         var4 = -1;
      } else {
         var4 = var3.ordinal();
      }

      var1.writeInt(var4);
      var1.writeInt(this.mStartTime);
      var1.writeInt(this.mDuration);
      var1.writeInt(this.mPositionsCount);
   }

   public static enum Type {
      MIDROLL("midroll"),
      OVERLAYROLL,
      PAUSEROLL("pauseroll"),
      POSTROLL("postroll"),
      PREROLL("preroll");

      private final String mType;

      static {
         Block.Type var0 = new Block.Type("OVERLAYROLL", 4, "overlayroll");
         OVERLAYROLL = var0;
         Block.Type[] var1 = new Block.Type[]{PREROLL, MIDROLL, POSTROLL, PAUSEROLL, var0};
      }

      private Type(String var3) {
         this.mType = var3;
      }

      public static Block.Type getByType(String var0) {
         Block.Type[] var1 = values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            Block.Type var4 = var1[var3];
            if (var4.mType.equals(var0)) {
               return var4;
            }
         }

         return null;
      }

      public final String toString() {
         return this.mType;
      }
   }
}
