package com.yandex.mobile.ads.impl;

import androidx.annotation.NonNull;
import com.yandex.mobile.ads.impl.gn.1;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public final class gn {
   @NonNull
   private final fo a;
   @NonNull
   private final List b;

   public gn(@NonNull fo var1) {
      this.a = var1;
      this.b = new CopyOnWriteArrayList();
   }

   // $FF: synthetic method
   static List a(gn var0) {
      return var0.b;
   }

   // $FF: synthetic method
   static void a(gn var0, Map var1) {
      var0.a.a((String)var1.get("yandex_mobile_metrica_uuid"));
      var0.a.c((String)var1.get("yandex_mobile_metrica_get_ad_url"));
      var0.a.d((String)var1.get("yandex_mobile_metrica_device_id"));
   }

   public final void a(@NonNull gm var1) {
      Iterator var2 = this.b.iterator();

      while(var2.hasNext()) {
         var1.b((gl)var2.next());
      }

   }

   public final void a(@NonNull gm var1, @NonNull gn.a var2) {
      1 var3 = new 1(this, var2);
      this.b.add(var3);
      var1.a(var3);
   }

   public interface a {
      void a();

      void a(@NonNull String var1);
   }
}
