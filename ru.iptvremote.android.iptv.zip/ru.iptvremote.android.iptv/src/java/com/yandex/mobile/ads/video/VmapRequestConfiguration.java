package com.yandex.mobile.ads.video;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.yandex.mobile.ads.impl.tm;

public final class VmapRequestConfiguration {
   @NonNull
   private final String a;
   @NonNull
   private final String b;

   private VmapRequestConfiguration(@NonNull VmapRequestConfiguration.Builder var1) {
      this.a = var1.b;
      this.b = var1.a;
   }

   // $FF: synthetic method
   VmapRequestConfiguration(VmapRequestConfiguration.Builder var1, byte var2) {
      this(var1);
   }

   @NonNull
   public final String getCategoryId() {
      return this.a;
   }

   @NonNull
   public final String getPageId() {
      return this.b;
   }

   public static final class Builder {
      @NonNull
      private final String a;
      @NonNull
      private String b;

      public Builder(@NonNull String var1) {
         this.a = var1;
         this.b = "0";
         tm.a(var1, "PageId");
      }

      public final VmapRequestConfiguration build() {
         return new VmapRequestConfiguration(this, (byte)0);
      }

      public final VmapRequestConfiguration.Builder setCategory(@NonNull String var1) {
         if (!TextUtils.isEmpty(var1)) {
            this.b = var1;
            return this;
         } else {
            throw new IllegalArgumentException("Passed categoryId is empty");
         }
      }
   }
}
