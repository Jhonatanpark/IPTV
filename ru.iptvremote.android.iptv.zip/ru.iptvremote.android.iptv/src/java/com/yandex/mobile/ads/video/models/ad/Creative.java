package com.yandex.mobile.ads.video.models.ad;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.Pair;
import androidx.annotation.Nullable;
import com.yandex.mobile.ads.impl.ie;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

public class Creative implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      // $FF: synthetic method
      public final Object createFromParcel(Parcel var1) {
         return new Creative(var1);
      }
   };
   private final ArrayList mClickThroughEvents = new ArrayList();
   private int mDurationMillis;
   private List mIcons = new ArrayList();
   private String mId;
   private List mMediaFiles = new ArrayList();
   @Nullable
   private SkipOffset mSkipOffset;
   private Map mTrackingEvents = new HashMap();

   private Creative() {
   }

   public Creative(Parcel var1) {
      this.mId = var1.readString();
      this.mDurationMillis = var1.readInt();
      var1.readTypedList(this.mMediaFiles, MediaFile.CREATOR);
      this.mTrackingEvents = new HashMap();
      int var2 = var1.readInt();
      int var3 = 0;

      for(int var4 = 0; var4 < var2; ++var4) {
         String var7 = var1.readString();
         ArrayList var8 = var1.readArrayList(Creative.class.getClassLoader());
         this.mTrackingEvents.put(var7, var8);
      }

      for(int var5 = var1.readInt(); var3 < var5; ++var3) {
         this.mClickThroughEvents.add(var1.readString());
      }

   }

   private void addClickThroughUrls(Collection var1) {
      this.mClickThroughEvents.addAll(ie.a(var1));
   }

   private void addMediaFile(MediaFile var1) {
      this.mMediaFiles.add(var1);
   }

   private void addMediaFiles(Collection var1) {
      Iterator var2 = ie.a(var1).iterator();

      while(var2.hasNext()) {
         this.addMediaFile((MediaFile)var2.next());
      }

   }

   private void addTrackingEvents(Collection var1) {
      Iterator var2 = ie.a(var1).iterator();

      while(var2.hasNext()) {
         Pair var3 = (Pair)var2.next();
         this.addTrackingEvent((String)var3.first, (String)var3.second);
      }

   }

   private void setDurationHHMMSS(String var1) {
      try {
         SimpleDateFormat var2 = new SimpleDateFormat("hh:mm:ss", Locale.US);
         this.mDurationMillis = (int)(var2.parse(var1).getTime() - var2.parse("00:00:00").getTime());
      } catch (ParseException var3) {
      }

   }

   private void setDurationMillis(int var1) {
      this.mDurationMillis = var1;
   }

   private void setId(String var1) {
      this.mId = var1;
   }

   private void setSkipOffset(@Nullable SkipOffset var1) {
      this.mSkipOffset = var1;
   }

   void addIcons(Collection var1) {
      this.mIcons.addAll(ie.a(var1));
   }

   void addTrackingEvent(String var1, String var2) {
      Object var3 = (List)this.mTrackingEvents.get(var1);
      if (var3 == null) {
         var3 = new ArrayList();
         this.mTrackingEvents.put(var1, var3);
      }

      ((List)var3).add(var2);
   }

   public int describeContents() {
      return 0;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null) {
         if (Creative.class != var1.getClass()) {
            return false;
         } else {
            Creative var2 = (Creative)var1;
            if (this.mDurationMillis != var2.mDurationMillis) {
               return false;
            } else {
               ArrayList var3 = this.mClickThroughEvents;
               if (var3 != null) {
                  if (!var3.equals(var2.mClickThroughEvents)) {
                     return false;
                  }
               } else if (var2.mClickThroughEvents != null) {
                  return false;
               }

               String var4 = this.mId;
               if (var4 != null) {
                  if (!var4.equals(var2.mId)) {
                     return false;
                  }
               } else if (var2.mId != null) {
                  return false;
               }

               List var5 = this.mMediaFiles;
               if (var5 != null) {
                  if (!var5.equals(var2.mMediaFiles)) {
                     return false;
                  }
               } else if (var2.mMediaFiles != null) {
                  return false;
               }

               Map var6 = this.mTrackingEvents;
               Map var7 = var2.mTrackingEvents;
               if (var6 != null) {
                  if (!var6.equals(var7)) {
                     return false;
                  }
               } else if (var7 != null) {
                  return false;
               }

               return true;
            }
         }
      } else {
         return false;
      }
   }

   public String getClickThroughUrl() {
      return this.mClickThroughEvents.isEmpty() ? null : (String)this.mClickThroughEvents.get(0);
   }

   public int getDurationMillis() {
      return this.mDurationMillis;
   }

   public List getIcons() {
      return Collections.unmodifiableList(this.mIcons);
   }

   public String getId() {
      return this.mId;
   }

   public List getMediaFiles() {
      return Collections.unmodifiableList(this.mMediaFiles);
   }

   @Nullable
   public SkipOffset getSkipOffset() {
      return this.mSkipOffset;
   }

   public Map getTrackingEvents() {
      return Collections.unmodifiableMap(this.mTrackingEvents);
   }

   public int hashCode() {
      String var1 = this.mId;
      int var2;
      if (var1 != null) {
         var2 = var1.hashCode();
      } else {
         var2 = 0;
      }

      int var3 = 31 * (var2 * 31 + this.mDurationMillis);
      List var4 = this.mMediaFiles;
      int var5;
      if (var4 != null) {
         var5 = var4.hashCode();
      } else {
         var5 = 0;
      }

      int var6 = 31 * (var3 + var5);
      Map var7 = this.mTrackingEvents;
      int var8;
      if (var7 != null) {
         var8 = var7.hashCode();
      } else {
         var8 = 0;
      }

      int var9 = 31 * (var6 + var8);
      ArrayList var10 = this.mClickThroughEvents;
      int var11 = 0;
      if (var10 != null) {
         var11 = var10.hashCode();
      }

      return var9 + var11;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeString(this.mId);
      var1.writeInt(this.mDurationMillis);
      var1.writeTypedList(this.mMediaFiles);
      var1.writeInt(this.mTrackingEvents.size());
      Iterator var3 = this.mTrackingEvents.entrySet().iterator();

      while(var3.hasNext()) {
         Entry var5 = (Entry)var3.next();
         var1.writeString((String)var5.getKey());
         var1.writeList((List)var5.getValue());
      }

      var1.writeInt(this.mClickThroughEvents.size());
      Iterator var4 = this.mClickThroughEvents.iterator();

      while(var4.hasNext()) {
         var1.writeString((String)var4.next());
      }

   }
}
