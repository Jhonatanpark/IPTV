package com.yandex.mobile.ads.video;

import com.yandex.mobile.ads.impl.tu;

final class a$1 implements Runnable {
   // $FF: synthetic field
   final tu a;
   // $FF: synthetic field
   final a b;

   a$1(a var1, tu var2) {
      this.b = var1;
      this.a = var2;
   }

   public final void run() {
      Object var1 = com.yandex.mobile.ads.video.a.b();
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            if (com.yandex.mobile.ads.video.a.a(this.b) != null) {
               com.yandex.mobile.ads.video.a.a(this.b).onRawVideoAdLoaded(this.a.b());
               com.yandex.mobile.ads.video.a.a(this.b).onVideoAdLoaded(this.a.a().b());
            }
         } catch (Throwable var15) {
            var10000 = var15;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            return;
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var2 = var10000;

         try {
            throw var2;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            continue;
         }
      }
   }
}
