package com.yandex.mobile.ads.impl;

import androidx.annotation.NonNull;
import java.util.Map;

public interface gl {
   void a(@NonNull String var1);

   void a(@NonNull Map var1);
}
