package com.yandex.mobile.ads.video.models.blocksinfo;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import b.a.a.a.a;
import com.yandex.mobile.ads.impl.ie;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public final class BlocksInfo implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      // $FF: synthetic method
      public final Object createFromParcel(Parcel var1) {
         return new BlocksInfo(var1);
      }
   };
   private static final int INVALID_POSITIVE_VALUE = -1;
   private List mBlocks;
   private int mBufferEmptyLimit;
   private int mBufferFullTimeout;
   private String mCategoryId;
   private String mCategoryName;
   private int mFirstBuffTimeout;
   private String mPartnerId;
   private String mSessionId;
   private boolean mShowSkipTimeLeft;
   private boolean mShowTimeLeft;
   private String mSkin;
   private int mSkinTimeout;
   private int mSkipDelay;
   private String mTitle;
   private boolean mVPaidEnabled;
   private int mVastTimeout;
   private int mVersion;
   private int mVideoTimeout;
   private int mVpaidTimeout;
   private int mWrapperMaxCount;
   private int mWrapperTimeout;

   private BlocksInfo() {
      this.mVPaidEnabled = false;
      this.mSkipDelay = -1;
      this.mSkinTimeout = -1;
      this.mVpaidTimeout = -1;
      this.mWrapperTimeout = -1;
      this.mVideoTimeout = -1;
      this.mVastTimeout = -1;
      this.mShowTimeLeft = false;
      this.mShowSkipTimeLeft = false;
      this.mBufferFullTimeout = -1;
      this.mWrapperMaxCount = -1;
      this.mFirstBuffTimeout = -1;
      this.mBlocks = new ArrayList();
   }

   private BlocksInfo(Parcel var1) {
      this.mVPaidEnabled = false;
      this.mSkipDelay = -1;
      this.mSkinTimeout = -1;
      this.mVpaidTimeout = -1;
      this.mWrapperTimeout = -1;
      this.mVideoTimeout = -1;
      this.mVastTimeout = -1;
      this.mShowTimeLeft = false;
      this.mShowSkipTimeLeft = false;
      this.mBufferFullTimeout = -1;
      this.mWrapperMaxCount = -1;
      this.mFirstBuffTimeout = -1;
      this.mBlocks = new ArrayList();
      this.mVersion = var1.readInt();
      this.mPartnerId = var1.readString();
      this.mSessionId = var1.readString();
      this.mCategoryId = var1.readString();
      this.mCategoryName = var1.readString();
      this.mSkin = var1.readString();
      boolean var2;
      if (var1.readByte() != 0) {
         var2 = true;
      } else {
         var2 = false;
      }

      this.mVPaidEnabled = var2;
      this.mBufferEmptyLimit = var1.readInt();
      this.mTitle = var1.readString();
      this.mSkipDelay = var1.readInt();
      this.mSkinTimeout = var1.readInt();
      this.mVpaidTimeout = var1.readInt();
      this.mWrapperTimeout = var1.readInt();
      this.mVideoTimeout = var1.readInt();
      this.mVastTimeout = var1.readInt();
      boolean var3;
      if (var1.readByte() != 0) {
         var3 = true;
      } else {
         var3 = false;
      }

      this.mShowTimeLeft = var3;
      byte var4 = var1.readByte();
      boolean var5 = false;
      if (var4 != 0) {
         var5 = true;
      }

      this.mShowSkipTimeLeft = var5;
      this.mBufferFullTimeout = var1.readInt();
      this.mWrapperMaxCount = var1.readInt();
      this.mFirstBuffTimeout = var1.readInt();
      var1.readTypedList(this.mBlocks, Block.CREATOR);
   }

   // $FF: synthetic method
   BlocksInfo(Parcel var1, Object var2) {
      this(var1);
   }

   private void addBlock(Block var1) {
      this.mBlocks.add(var1);
   }

   private void addBlocks(Collection var1) {
      Iterator var2 = ie.a(var1).iterator();

      while(var2.hasNext()) {
         this.addBlock((Block)var2.next());
      }

   }

   private static boolean parseBooleanWithDefault(String var0, boolean var1) {
      try {
         var1 = Boolean.parseBoolean(var0);
      } catch (Exception var2) {
      }

      return var1;
   }

   private static int parsePositiveIntOrInvalidValue(String var0) {
      try {
         int var1 = Integer.parseInt(var0);
         return var1;
      } catch (Exception var2) {
         return -1;
      }
   }

   private void setBufferEmptyLimit(String var1) {
      this.mBufferEmptyLimit = parsePositiveIntOrInvalidValue(var1);
   }

   private void setBufferFullTimeout(String var1) {
      this.mBufferFullTimeout = parsePositiveIntOrInvalidValue(var1);
   }

   private void setCategoryId(String var1) {
      this.mCategoryId = var1;
   }

   private void setCategoryName(String var1) {
      this.mCategoryName = var1;
   }

   private void setFirstBuffTimeout(String var1) {
      this.mFirstBuffTimeout = parsePositiveIntOrInvalidValue(var1);
   }

   private void setPartnerId(String var1) {
      this.mPartnerId = var1;
   }

   private void setSessionId(String var1) {
      this.mSessionId = var1;
   }

   private void setShowSkipTimeLeft(String var1) {
      this.mShowSkipTimeLeft = parseBooleanWithDefault(var1, this.mShowSkipTimeLeft);
   }

   private void setShowTimeLeft(String var1) {
      this.mShowTimeLeft = parseBooleanWithDefault(var1, this.mShowTimeLeft);
   }

   private void setSkin(String var1) {
      this.mSkin = var1;
   }

   private void setSkinTimeout(String var1) {
      this.mSkinTimeout = parsePositiveIntOrInvalidValue(var1);
   }

   private void setSkipDelay(String var1) {
      this.mSkipDelay = parsePositiveIntOrInvalidValue(var1);
   }

   private void setTitle(String var1) {
      this.mTitle = var1;
   }

   private void setVPaidEnabled(String var1) {
      this.mVPaidEnabled = parseBooleanWithDefault(var1, this.mVPaidEnabled);
   }

   private void setVastTimeout(String var1) {
      this.mVastTimeout = parsePositiveIntOrInvalidValue(var1);
   }

   private void setVersion(String var1) {
      this.mVersion = parsePositiveIntOrInvalidValue(var1);
   }

   private void setVideoTimeout(String var1) {
      this.mVideoTimeout = parsePositiveIntOrInvalidValue(var1);
   }

   private void setVpaidTimeout(String var1) {
      this.mVpaidTimeout = parsePositiveIntOrInvalidValue(var1);
   }

   private void setWrapperMaxCount(String var1) {
      this.mWrapperMaxCount = parsePositiveIntOrInvalidValue(var1);
   }

   private void setWrapperTimeout(String var1) {
      this.mWrapperTimeout = parsePositiveIntOrInvalidValue(var1);
   }

   public final int describeContents() {
      return 0;
   }

   public final boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null) {
         if (BlocksInfo.class != var1.getClass()) {
            return false;
         } else {
            BlocksInfo var2 = (BlocksInfo)var1;
            if (this.mBufferEmptyLimit != var2.mBufferEmptyLimit) {
               return false;
            } else if (this.mBufferFullTimeout != var2.mBufferFullTimeout) {
               return false;
            } else if (this.mFirstBuffTimeout != var2.mFirstBuffTimeout) {
               return false;
            } else if (this.mVPaidEnabled != var2.mVPaidEnabled) {
               return false;
            } else if (this.mShowSkipTimeLeft != var2.mShowSkipTimeLeft) {
               return false;
            } else if (this.mShowTimeLeft != var2.mShowTimeLeft) {
               return false;
            } else if (this.mSkinTimeout != var2.mSkinTimeout) {
               return false;
            } else if (this.mSkipDelay != var2.mSkipDelay) {
               return false;
            } else if (this.mVastTimeout != var2.mVastTimeout) {
               return false;
            } else if (this.mVersion != var2.mVersion) {
               return false;
            } else if (this.mVideoTimeout != var2.mVideoTimeout) {
               return false;
            } else if (this.mVpaidTimeout != var2.mVpaidTimeout) {
               return false;
            } else if (this.mWrapperMaxCount != var2.mWrapperMaxCount) {
               return false;
            } else if (this.mWrapperTimeout != var2.mWrapperTimeout) {
               return false;
            } else {
               List var3 = this.mBlocks;
               if (var3 != null) {
                  if (!var3.equals(var2.mBlocks)) {
                     return false;
                  }
               } else if (var2.mBlocks != null) {
                  return false;
               }

               String var4 = this.mCategoryId;
               if (var4 != null) {
                  if (!var4.equals(var2.mCategoryId)) {
                     return false;
                  }
               } else if (var2.mCategoryId != null) {
                  return false;
               }

               String var5 = this.mCategoryName;
               if (var5 != null) {
                  if (!var5.equals(var2.mCategoryName)) {
                     return false;
                  }
               } else if (var2.mCategoryName != null) {
                  return false;
               }

               String var6 = this.mPartnerId;
               if (var6 != null) {
                  if (!var6.equals(var2.mPartnerId)) {
                     return false;
                  }
               } else if (var2.mPartnerId != null) {
                  return false;
               }

               String var7 = this.mSessionId;
               if (var7 != null) {
                  if (!var7.equals(var2.mSessionId)) {
                     return false;
                  }
               } else if (var2.mSessionId != null) {
                  return false;
               }

               String var8 = this.mSkin;
               if (var8 != null) {
                  if (!var8.equals(var2.mSkin)) {
                     return false;
                  }
               } else if (var2.mSkin != null) {
                  return false;
               }

               String var9 = this.mTitle;
               String var10 = var2.mTitle;
               if (var9 != null) {
                  if (!var9.equals(var10)) {
                     return false;
                  }
               } else if (var10 != null) {
                  return false;
               }

               return true;
            }
         }
      } else {
         return false;
      }
   }

   public final List getBlocks() {
      return this.mBlocks;
   }

   public final int getBufferEmptyLimit() {
      return this.mBufferEmptyLimit;
   }

   public final int getBufferFullTimeout() {
      return this.mBufferFullTimeout;
   }

   public final String getCategoryId() {
      return this.mCategoryId;
   }

   public final String getCategoryName() {
      return this.mCategoryName;
   }

   public final int getFirstBuffTimeout() {
      return this.mFirstBuffTimeout;
   }

   public final String getPartnerId() {
      return this.mPartnerId;
   }

   public final String getSessionId() {
      return this.mSessionId;
   }

   public final String getSkin() {
      return this.mSkin;
   }

   public final int getSkinTimeout() {
      return this.mSkinTimeout;
   }

   public final int getSkipDelay() {
      return this.mSkipDelay;
   }

   public final String getTitle() {
      return this.mTitle;
   }

   public final int getVastTimeout() {
      return this.mVastTimeout;
   }

   public final int getVersion() {
      return this.mVersion;
   }

   public final int getVideoTimeout() {
      return this.mVideoTimeout;
   }

   public final int getVpaidTimeout() {
      return this.mVpaidTimeout;
   }

   public final int getWrapperMaxCount() {
      return this.mWrapperMaxCount;
   }

   public final int getWrapperTimeout() {
      return this.mWrapperTimeout;
   }

   public final int hashCode() {
      int var1 = 31 * this.mVersion;
      String var2 = this.mPartnerId;
      int var3;
      if (var2 != null) {
         var3 = var2.hashCode();
      } else {
         var3 = 0;
      }

      int var4 = 31 * (var1 + var3);
      String var5 = this.mSessionId;
      int var6;
      if (var5 != null) {
         var6 = var5.hashCode();
      } else {
         var6 = 0;
      }

      int var7 = 31 * (var4 + var6);
      String var8 = this.mCategoryId;
      int var9;
      if (var8 != null) {
         var9 = var8.hashCode();
      } else {
         var9 = 0;
      }

      int var10 = 31 * (var7 + var9);
      String var11 = this.mCategoryName;
      int var12;
      if (var11 != null) {
         var12 = var11.hashCode();
      } else {
         var12 = 0;
      }

      int var13 = 31 * (var10 + var12);
      String var14 = this.mSkin;
      int var15;
      if (var14 != null) {
         var15 = var14.hashCode();
      } else {
         var15 = 0;
      }

      int var16 = 31 * (31 * (31 * (var13 + var15) + this.mVPaidEnabled) + this.mBufferEmptyLimit);
      String var17 = this.mTitle;
      int var18;
      if (var17 != null) {
         var18 = var17.hashCode();
      } else {
         var18 = 0;
      }

      int var19 = 31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (var16 + var18) + this.mSkipDelay) + this.mSkinTimeout) + this.mVpaidTimeout) + this.mWrapperTimeout) + this.mVideoTimeout) + this.mVastTimeout) + this.mShowTimeLeft) + this.mShowSkipTimeLeft) + this.mBufferFullTimeout) + this.mWrapperMaxCount) + this.mFirstBuffTimeout);
      List var20 = this.mBlocks;
      int var21 = 0;
      if (var20 != null) {
         var21 = var20.hashCode();
      }

      return var19 + var21;
   }

   public final boolean isVPaidEnabled() {
      return this.mVPaidEnabled;
   }

   public final boolean showSkipTimeLeft() {
      return this.mShowSkipTimeLeft;
   }

   public final boolean showTimeLeft() {
      return this.mShowTimeLeft;
   }

   public final String toString() {
      StringBuilder var1 = new StringBuilder("mVersion=");
      var1.append(this.mVersion);
      var1.append('\'');
      var1.append("\nmPartnerId='");
      a.o(var1, this.mPartnerId, '\'', "\nmSessionId='");
      a.o(var1, this.mSessionId, '\'', "\nmCategoryId='");
      a.o(var1, this.mCategoryId, '\'', "\nmCategoryName='");
      a.o(var1, this.mCategoryName, '\'', "\nmSkin='");
      a.o(var1, this.mSkin, '\'', "\nmVPaidEnabled=");
      var1.append(this.mVPaidEnabled);
      var1.append("\nmBufferEmptyLimit=");
      var1.append(this.mBufferEmptyLimit);
      var1.append("\nmTitle='");
      a.o(var1, this.mTitle, '\'', "\nmSkipDelay=");
      var1.append(this.mSkipDelay);
      var1.append("\nmSkinTimeout=");
      var1.append(this.mSkinTimeout);
      var1.append("\nmVpaidTimeout=");
      var1.append(this.mVpaidTimeout);
      var1.append("\nmWrapperTimeout=");
      var1.append(this.mWrapperTimeout);
      var1.append("\nmVideoTimeout=");
      var1.append(this.mVideoTimeout);
      var1.append("\nmVastTimeout=");
      var1.append(this.mVastTimeout);
      var1.append("\nmShowTimeLeft=");
      var1.append(this.mShowTimeLeft);
      var1.append("\nmShowSkipTimeLeft=");
      var1.append(this.mShowSkipTimeLeft);
      var1.append("\nmBufferFullTimeout=");
      var1.append(this.mBufferFullTimeout);
      var1.append("\nmWrapperMaxCount=");
      var1.append(this.mWrapperMaxCount);
      var1.append("\nmFirstBuffTimeout=");
      var1.append(this.mFirstBuffTimeout);
      var1.append("\nmBlocks.size()=");
      var1.append(this.mBlocks.size());
      return var1.toString();
   }

   public final void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.mVersion);
      var1.writeString(this.mPartnerId);
      var1.writeString(this.mSessionId);
      var1.writeString(this.mCategoryId);
      var1.writeString(this.mCategoryName);
      var1.writeString(this.mSkin);
      var1.writeByte(this.mVPaidEnabled);
      var1.writeInt(this.mBufferEmptyLimit);
      var1.writeString(this.mTitle);
      var1.writeInt(this.mSkipDelay);
      var1.writeInt(this.mSkinTimeout);
      var1.writeInt(this.mVpaidTimeout);
      var1.writeInt(this.mWrapperTimeout);
      var1.writeInt(this.mVideoTimeout);
      var1.writeInt(this.mVastTimeout);
      var1.writeByte(this.mShowTimeLeft);
      var1.writeByte(this.mShowSkipTimeLeft);
      var1.writeInt(this.mBufferFullTimeout);
      var1.writeInt(this.mWrapperMaxCount);
      var1.writeInt(this.mFirstBuffTimeout);
      var1.writeTypedList(this.mBlocks);
   }
}
