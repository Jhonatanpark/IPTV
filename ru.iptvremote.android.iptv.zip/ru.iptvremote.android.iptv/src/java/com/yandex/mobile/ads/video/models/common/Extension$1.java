package com.yandex.mobile.ads.video.models.common;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import androidx.annotation.NonNull;

final class Extension$1 implements Creator {
   // $FF: synthetic method
   public final Object createFromParcel(@NonNull Parcel var1) {
      return new Extension(var1);
   }
}
