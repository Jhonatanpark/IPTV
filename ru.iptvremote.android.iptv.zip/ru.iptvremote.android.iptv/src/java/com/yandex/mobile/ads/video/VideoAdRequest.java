package com.yandex.mobile.ads.video;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.yandex.mobile.ads.impl.ie;
import com.yandex.mobile.ads.impl.tm;
import com.yandex.mobile.ads.video.models.blocksinfo.BlocksInfo;
import java.util.List;

public final class VideoAdRequest {
   @NonNull
   private final Context a;
   @NonNull
   private final BlocksInfo b;
   @NonNull
   private final String c;
   @NonNull
   private final String d;
   @NonNull
   private final String e;
   @NonNull
   private final VideoAdRequest.Charset f;
   @Nullable
   private final RequestListener g;
   private final int h;
   private final int i;
   private final int j;
   @Nullable
   private final String k;
   @Nullable
   private final String l;
   @Nullable
   private final String m;
   @Nullable
   private final String n;
   @Nullable
   private final String o;
   @Nullable
   private final String p;
   @Nullable
   private final String q;
   @Nullable
   private final String r;

   private VideoAdRequest(VideoAdRequest.Builder var1) {
      this.a = var1.a;
      this.g = var1.f;
      this.b = var1.b;
      this.c = var1.e;
      this.d = var1.c;
      this.e = var1.d;
      VideoAdRequest.Charset var2;
      if (var1.j != null) {
         var2 = var1.j;
      } else {
         var2 = VideoAdRequest.Charset.a;
      }

      this.f = var2;
      this.i = var1.h;
      this.j = var1.i;
      this.k = var1.k;
      this.l = var1.l;
      this.m = var1.m;
      this.n = var1.n;
      this.h = var1.g;
      this.o = var1.o;
      this.p = var1.p;
      this.q = var1.q;
      this.r = var1.r;
   }

   // $FF: synthetic method
   VideoAdRequest(VideoAdRequest.Builder var1, byte var2) {
      this(var1);
   }

   private static String a(int var0) {
      return var0 >= 0 ? Integer.toString(var0) : null;
   }

   @NonNull
   public final String getBlockId() {
      return this.c;
   }

   @NonNull
   public final BlocksInfo getBlocksInfo() {
      return this.b;
   }

   @NonNull
   public final VideoAdRequest.Charset getCharset() {
      return this.f;
   }

   @NonNull
   public final Context getContext() {
      return this.a;
   }

   @Nullable
   public final String getExtParams() {
      return this.r;
   }

   @Nullable
   public final String getGenreId() {
      return this.o;
   }

   @Nullable
   public final String getGenreName() {
      return this.p;
   }

   public final String getMaxBitrate() {
      return a(this.h);
   }

   @NonNull
   public final String getPageRef() {
      return this.e;
   }

   public final String getPlayerHeightPix() {
      return a(this.j);
   }

   public final String getPlayerWidthPix() {
      return a(this.i);
   }

   @Nullable
   public final String getPublisherId() {
      return this.m;
   }

   @Nullable
   public final String getPublisherName() {
      return this.n;
   }

   @Nullable
   public final RequestListener getRequestListener() {
      return this.g;
   }

   @Nullable
   public final String getTagsList() {
      return this.q;
   }

   @NonNull
   public final String getTargetRef() {
      return this.d;
   }

   @Nullable
   public final String getVideoContentId() {
      return this.k;
   }

   @Nullable
   public final String getVideoContentName() {
      return this.l;
   }

   public static final class Builder {
      @NonNull
      private final Context a;
      @NonNull
      private final BlocksInfo b;
      @NonNull
      private final String c;
      @NonNull
      private final String d;
      @NonNull
      private final String e;
      @Nullable
      private final RequestListener f;
      private int g = -1;
      private int h = -1;
      private int i = -1;
      @Nullable
      private VideoAdRequest.Charset j;
      @Nullable
      private String k;
      @Nullable
      private String l;
      @Nullable
      private String m;
      @Nullable
      private String n;
      @Nullable
      private String o;
      @Nullable
      private String p;
      @Nullable
      private String q;
      @Nullable
      private String r;

      public Builder(@NonNull Context var1, @NonNull BlocksInfo var2, @Nullable RequestListener var3, @NonNull String var4, @NonNull String var5, @NonNull String var6) {
         this.a = var1.getApplicationContext();
         this.b = var2;
         this.f = var3;
         this.c = var4;
         this.d = var5;
         this.e = var6;
         tm.a(var2, "BlocksInfo");
         tm.a(this.e, "BlockId");
         tm.a(this.c, "TargetRef");
         tm.a(this.d, "PageRef");
      }

      public final VideoAdRequest build() {
         return new VideoAdRequest(this, (byte)0);
      }

      public final VideoAdRequest.Builder setCharset(@Nullable VideoAdRequest.Charset var1) {
         this.j = var1;
         return this;
      }

      public final VideoAdRequest.Builder setContentId(String var1) {
         this.k = var1;
         return this;
      }

      public final VideoAdRequest.Builder setContentName(String var1) {
         this.l = var1;
         return this;
      }

      public final VideoAdRequest.Builder setExtendedParams(String var1) {
         this.r = var1;
         return this;
      }

      public final VideoAdRequest.Builder setGenreIds(@Nullable List var1) {
         this.o = ie.a(var1);
         return this;
      }

      public final VideoAdRequest.Builder setGenreNames(@Nullable List var1) {
         this.p = ie.a(var1);
         return this;
      }

      public final VideoAdRequest.Builder setMaxBitrate(int var1) {
         this.g = var1;
         return this;
      }

      public final VideoAdRequest.Builder setPlayerSize(int var1, int var2) {
         this.h = var1;
         this.i = var2;
         return this;
      }

      public final VideoAdRequest.Builder setPublisherId(@Nullable String var1) {
         this.m = var1;
         return this;
      }

      public final VideoAdRequest.Builder setPublisherName(@Nullable String var1) {
         this.n = var1;
         return this;
      }

      public final VideoAdRequest.Builder setTagsList(@Nullable List var1) {
         this.q = ie.a(var1);
         return this;
      }
   }

   public static enum Charset {
      a("utf8"),
      b("cp1251"),
      c("koi8r"),
      d;

      private final String e;

      static {
         VideoAdRequest.Charset var0 = new VideoAdRequest.Charset("KOI_8U", 3, "koi8u");
         d = var0;
         VideoAdRequest.Charset[] var1 = new VideoAdRequest.Charset[]{a, b, c, var0};
      }

      private Charset(String var3) {
         this.e = var3;
      }

      public final String getValue() {
         return this.e;
      }
   }
}
