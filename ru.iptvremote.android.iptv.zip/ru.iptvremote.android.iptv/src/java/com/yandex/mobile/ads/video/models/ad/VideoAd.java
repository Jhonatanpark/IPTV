package com.yandex.mobile.ads.video.models.ad;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.yandex.mobile.ads.impl.ie;
import com.yandex.mobile.ads.impl.tv;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public final class VideoAd implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      // $FF: synthetic method
      public final Object createFromParcel(Parcel var1) {
         return new VideoAd(var1);
      }
   };
   private static final String ERROR = "error";
   private String mAdSystem;
   private String mAdTitle;
   private List mCreatives;
   private String mDescription;
   private String mSurvey;
   private Map mTrackingEvents;
   private String mVastAdTagUri;
   private final boolean mWrapper;
   @Nullable
   private tv mWrapperConfiguration;

   private VideoAd(Parcel var1) {
      this.mCreatives = new ArrayList();
      this.mTrackingEvents = new HashMap();
      int var2 = var1.readInt();
      int var3 = 0;
      byte var4 = 1;
      if (var2 != var4) {
         var4 = 0;
      }

      this.mWrapper = (boolean)var4;
      this.mAdSystem = var1.readString();
      this.mAdTitle = var1.readString();
      this.mDescription = var1.readString();
      this.mSurvey = var1.readString();
      this.mVastAdTagUri = var1.readString();
      var1.readTypedList(this.mCreatives, Creative.CREATOR);
      this.mTrackingEvents = new HashMap();

      for(int var5 = var1.readInt(); var3 < var5; ++var3) {
         String var6 = var1.readString();
         ArrayList var7 = var1.readArrayList(VideoAd.class.getClassLoader());
         this.mTrackingEvents.put(var6, var7);
      }

   }

   // $FF: synthetic method
   VideoAd(Parcel var1, Object var2) {
      this(var1);
   }

   private VideoAd(Boolean var1) {
      this.mCreatives = new ArrayList();
      this.mTrackingEvents = new HashMap();
      this.mWrapper = var1;
   }

   private void addCreative(Creative var1) {
      this.mCreatives.add(var1);
   }

   private void addCreatives(Collection var1) {
      Iterator var2 = ie.a(var1).iterator();

      while(var2.hasNext()) {
         this.addCreative((Creative)var2.next());
      }

   }

   private void addError(String var1) {
      this.addTrackingEvent("error", var1);
   }

   private void addImpression(String var1) {
      this.addTrackingEvent("impression", var1);
   }

   private void addImpressions(Collection var1) {
      Iterator var2 = ie.a(var1).iterator();

      while(var2.hasNext()) {
         this.addImpression((String)var2.next());
      }

   }

   private void setAdSystem(String var1) {
      this.mAdSystem = var1;
   }

   private void setAdTitle(String var1) {
      this.mAdTitle = var1;
   }

   private void setDescription(String var1) {
      this.mDescription = var1;
   }

   private void setSurvey(String var1) {
      this.mSurvey = var1;
   }

   private void setVastAdTagUri(String var1) {
      this.mVastAdTagUri = var1;
   }

   final void addTrackingEvent(String var1, String var2) {
      Object var3 = (List)this.mTrackingEvents.get(var1);
      if (var3 == null) {
         var3 = new ArrayList();
         this.mTrackingEvents.put(var1, var3);
      }

      if (!TextUtils.isEmpty(var2)) {
         ((List)var3).add(var2);
      }

   }

   public final int describeContents() {
      return 0;
   }

   public final boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null) {
         if (VideoAd.class != var1.getClass()) {
            return false;
         } else {
            VideoAd var2 = (VideoAd)var1;
            if (this.mWrapper != var2.mWrapper) {
               return false;
            } else {
               String var3 = this.mAdSystem;
               if (var3 != null) {
                  if (!var3.equals(var2.mAdSystem)) {
                     return false;
                  }
               } else if (var2.mAdSystem != null) {
                  return false;
               }

               String var4 = this.mAdTitle;
               if (var4 != null) {
                  if (!var4.equals(var2.mAdTitle)) {
                     return false;
                  }
               } else if (var2.mAdTitle != null) {
                  return false;
               }

               if (!this.mCreatives.equals(var2.mCreatives)) {
                  return false;
               } else {
                  String var5 = this.mDescription;
                  if (var5 != null) {
                     if (!var5.equals(var2.mDescription)) {
                        return false;
                     }
                  } else if (var2.mDescription != null) {
                     return false;
                  }

                  String var6 = this.mSurvey;
                  if (var6 != null) {
                     if (!var6.equals(var2.mSurvey)) {
                        return false;
                     }
                  } else if (var2.mSurvey != null) {
                     return false;
                  }

                  if (!this.mTrackingEvents.equals(var2.mTrackingEvents)) {
                     return false;
                  } else {
                     String var7 = this.mVastAdTagUri;
                     String var8 = var2.mVastAdTagUri;
                     if (var7 != null) {
                        if (!var7.equals(var8)) {
                           return false;
                        }
                     } else if (var8 != null) {
                        return false;
                     }

                     return true;
                  }
               }
            }
         }
      } else {
         return false;
      }
   }

   public final String getAdSystem() {
      return this.mAdSystem;
   }

   public final String getAdTitle() {
      return this.mAdTitle;
   }

   public final List getCreatives() {
      return this.mCreatives;
   }

   public final String getDescription() {
      return this.mDescription;
   }

   public final String getSurvey() {
      return this.mSurvey;
   }

   public final Map getTrackingEvents() {
      return Collections.unmodifiableMap(this.mTrackingEvents);
   }

   public final String getVastAdTagUri() {
      return this.mVastAdTagUri;
   }

   @Nullable
   final tv getWrapperConfiguration() {
      return this.mWrapperConfiguration;
   }

   public final int hashCode() {
      String var1 = this.mAdSystem;
      int var2;
      if (var1 != null) {
         var2 = var1.hashCode();
      } else {
         var2 = 0;
      }

      int var3 = 31 * (var2 * 31 + this.mWrapper);
      String var4 = this.mAdTitle;
      int var5;
      if (var4 != null) {
         var5 = var4.hashCode();
      } else {
         var5 = 0;
      }

      int var6 = 31 * (var3 + var5);
      String var7 = this.mDescription;
      int var8;
      if (var7 != null) {
         var8 = var7.hashCode();
      } else {
         var8 = 0;
      }

      int var9 = 31 * (var6 + var8);
      String var10 = this.mSurvey;
      int var11;
      if (var10 != null) {
         var11 = var10.hashCode();
      } else {
         var11 = 0;
      }

      int var12 = 31 * (var9 + var11);
      String var13 = this.mVastAdTagUri;
      int var14 = 0;
      if (var13 != null) {
         var14 = var13.hashCode();
      }

      return 31 * (31 * (var12 + var14) + this.mCreatives.hashCode()) + this.mTrackingEvents.hashCode();
   }

   public final boolean isWrapper() {
      return this.mWrapper;
   }

   final void setWrapperConfiguration(@Nullable tv var1) {
      this.mWrapperConfiguration = var1;
   }

   public final void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.mWrapper);
      var1.writeString(this.mAdSystem);
      var1.writeString(this.mAdTitle);
      var1.writeString(this.mDescription);
      var1.writeString(this.mSurvey);
      var1.writeString(this.mVastAdTagUri);
      var1.writeTypedList(this.mCreatives);
      var1.writeInt(this.mTrackingEvents.size());
      Iterator var3 = this.mTrackingEvents.entrySet().iterator();

      while(var3.hasNext()) {
         Entry var4 = (Entry)var3.next();
         var1.writeString((String)var4.getKey());
         var1.writeList((List)var4.getValue());
      }

   }
}
