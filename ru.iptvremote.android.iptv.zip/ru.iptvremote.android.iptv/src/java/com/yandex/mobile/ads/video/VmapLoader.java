package com.yandex.mobile.ads.video;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.yandex.mobile.ads.impl.tn;
import com.yandex.mobile.ads.impl.ts;
import com.yandex.mobile.ads.impl.to.a;
import com.yandex.mobile.ads.video.models.vmap.Vmap;

public final class VmapLoader {
   @NonNull
   private final tn a;
   @NonNull
   private final ts b;

   public VmapLoader(@NonNull Context var1) {
      this.a = new tn(var1);
      this.b = new ts();
   }

   public final void cancelLoading() {
      this.b.a();
   }

   public final void loadVmap(@NonNull Context var1, @NonNull VmapRequestConfiguration var2) {
      tn var3 = this.a;
      ts var4 = this.b;
      var3.a(var1, (new a("v1", var2.getCategoryId(), var2.getPageId())).a(), var4);
   }

   public final void setOnVmapLoadedListener(@Nullable VmapLoader.OnVmapLoadedListener var1) {
      this.b.a(var1);
   }

   public abstract static class OnVmapLoadedListener {
      public abstract void onVmapFailedToLoad(@NonNull VmapError var1);

      public abstract void onVmapLoaded(@NonNull Vmap var1);
   }
}
