package com.yandex.mobile.ads.video;

import android.content.Context;
import androidx.annotation.NonNull;

public final class YandexVideoAds {
   private YandexVideoAds() {
   }

   public static void loadBlocksInfo(@NonNull BlocksInfoRequest var0) {
      Context var1 = var0.getContext();
      b.a(var1).a(var1, var0);
   }

   public static void loadVideoAds(@NonNull VideoAdRequest var0) {
      Context var1 = var0.getContext();
      b.a(var1).a(var1, var0);
   }
}
