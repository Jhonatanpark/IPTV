package com.yandex.mobile.ads.video.models.ad;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public final class MediaFile implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      // $FF: synthetic method
      public final Object createFromParcel(Parcel var1) {
         return new MediaFile(var1);
      }
   };
   public int mBitrate;
   private MediaFile.DeliveryMethod mDeliveryMethod;
   private int mHeight;
   private String mId;
   private String mMimeType;
   private String mUri;
   private int mWidth;

   private MediaFile() {
   }

   private MediaFile(Parcel var1) {
      this.mId = var1.readString();
      this.mUri = var1.readString();
      int var2 = var1.readInt();
      MediaFile.DeliveryMethod var3;
      if (var2 == -1) {
         var3 = null;
      } else {
         var3 = MediaFile.DeliveryMethod.values()[var2];
      }

      this.mDeliveryMethod = var3;
      this.mHeight = var1.readInt();
      this.mWidth = var1.readInt();
      this.mMimeType = var1.readString();
   }

   // $FF: synthetic method
   MediaFile(Parcel var1, Object var2) {
      this(var1);
   }

   private void setBitrate(String var1) {
      try {
         this.mBitrate = Integer.valueOf(var1);
      } catch (Exception var2) {
      }

   }

   private void setDeliveryMethod(String var1) {
      this.mDeliveryMethod = MediaFile.DeliveryMethod.getByMethod(var1);
   }

   private void setHeight(String var1) {
      try {
         this.mHeight = Integer.valueOf(var1);
      } catch (Exception var2) {
      }

   }

   private void setId(String var1) {
      this.mId = var1;
   }

   private void setUri(String var1) {
      this.mUri = var1;
   }

   private void setWidth(String var1) {
      try {
         this.mWidth = Integer.valueOf(var1);
      } catch (Exception var2) {
      }

   }

   public final int describeContents() {
      return 0;
   }

   public final boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null) {
         if (MediaFile.class != var1.getClass()) {
            return false;
         } else {
            MediaFile var2 = (MediaFile)var1;
            if (this.mHeight != var2.mHeight) {
               return false;
            } else if (this.mWidth != var2.mWidth) {
               return false;
            } else if (this.mDeliveryMethod != var2.mDeliveryMethod) {
               return false;
            } else {
               String var3 = this.mId;
               if (var3 != null) {
                  if (!var3.equals(var2.mId)) {
                     return false;
                  }
               } else if (var2.mId != null) {
                  return false;
               }

               String var4 = this.mMimeType;
               if (var4 != null) {
                  if (!var4.equals(var2.mMimeType)) {
                     return false;
                  }
               } else if (var2.mMimeType != null) {
                  return false;
               }

               String var5 = this.mUri;
               String var6 = var2.mUri;
               if (var5 != null) {
                  if (!var5.equals(var6)) {
                     return false;
                  }
               } else if (var6 != null) {
                  return false;
               }

               return true;
            }
         }
      } else {
         return false;
      }
   }

   public final int getBitrate() {
      return this.mBitrate;
   }

   public final MediaFile.DeliveryMethod getDeliveryMethod() {
      return this.mDeliveryMethod;
   }

   public final int getHeight() {
      return this.mHeight;
   }

   public final String getId() {
      return this.mId;
   }

   public final String getMimeType() {
      return this.mMimeType;
   }

   public final String getUri() {
      return this.mUri;
   }

   public final int getWidth() {
      return this.mWidth;
   }

   public final int hashCode() {
      String var1 = this.mId;
      int var2;
      if (var1 != null) {
         var2 = var1.hashCode();
      } else {
         var2 = 0;
      }

      int var3 = var2 * 31;
      String var4 = this.mUri;
      int var5;
      if (var4 != null) {
         var5 = var4.hashCode();
      } else {
         var5 = 0;
      }

      int var6 = 31 * (var3 + var5);
      MediaFile.DeliveryMethod var7 = this.mDeliveryMethod;
      int var8;
      if (var7 != null) {
         var8 = var7.hashCode();
      } else {
         var8 = 0;
      }

      int var9 = 31 * (31 * (31 * (var6 + var8) + this.mHeight) + this.mWidth);
      String var10 = this.mMimeType;
      int var11 = 0;
      if (var10 != null) {
         var11 = var10.hashCode();
      }

      return var9 + var11;
   }

   public final void setMimeType(String var1) {
      this.mMimeType = var1;
   }

   public final void writeToParcel(Parcel var1, int var2) {
      var1.writeString(this.mId);
      var1.writeString(this.mUri);
      MediaFile.DeliveryMethod var3 = this.mDeliveryMethod;
      int var4;
      if (var3 == null) {
         var4 = -1;
      } else {
         var4 = var3.ordinal();
      }

      var1.writeInt(var4);
      var1.writeInt(this.mHeight);
      var1.writeInt(this.mWidth);
      var1.writeString(this.mMimeType);
   }

   public static enum DeliveryMethod {
      PROGRESSIVE,
      STREAMING("streaming");

      private String mDeliveryMethod;

      static {
         MediaFile.DeliveryMethod var0 = new MediaFile.DeliveryMethod("PROGRESSIVE", 1, "progressive");
         PROGRESSIVE = var0;
         MediaFile.DeliveryMethod[] var1 = new MediaFile.DeliveryMethod[]{STREAMING, var0};
      }

      private DeliveryMethod(String var3) {
         this.mDeliveryMethod = var3;
      }

      public static MediaFile.DeliveryMethod getByMethod(String var0) {
         MediaFile.DeliveryMethod[] var1 = values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            MediaFile.DeliveryMethod var4 = var1[var3];
            if (var4.mDeliveryMethod.equals(var0)) {
               return var4;
            }
         }

         return null;
      }
   }
}
