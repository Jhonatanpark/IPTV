package com.yandex.mobile.ads.video.models.ad;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.yandex.mobile.ads.impl.tv;

public class WrapperConfigurationProvider {
   @NonNull
   private final VideoAd mWrapperAd;

   public WrapperConfigurationProvider(@NonNull VideoAd var1) {
      this.mWrapperAd = var1;
   }

   @Nullable
   public tv getWrapperConfiguration() {
      return this.mWrapperAd.getWrapperConfiguration();
   }
}
