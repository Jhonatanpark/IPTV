package com.yandex.mobile.ads.video;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.yandex.mobile.ads.impl.tn;
import java.util.List;

public final class VideoAdLoader {
   @NonNull
   private final tn a;
   @NonNull
   private final a b;

   public VideoAdLoader(@NonNull Context var1) {
      this.a = new tn(var1);
      this.b = new a();
   }

   public final void cancelLoading() {
      this.b.a();
   }

   public final void loadAd(@NonNull Context var1, @NonNull VastRequestConfiguration var2) {
      this.a.a(var1, var2, this.b);
   }

   public final void setOnVideoAdLoadedListener(@Nullable VideoAdLoader.OnVideoAdLoadedListener var1) {
      this.b.a(var1);
   }

   public abstract static class OnVideoAdLoadedListener {
      void onRawVideoAdLoaded(@Nullable String var1) {
      }

      public abstract void onVideoAdFailedToLoad(@NonNull VideoAdError var1);

      public abstract void onVideoAdLoaded(@NonNull List var1);
   }
}
