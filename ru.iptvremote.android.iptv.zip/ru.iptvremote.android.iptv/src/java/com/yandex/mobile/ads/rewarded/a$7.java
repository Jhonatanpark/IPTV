package com.yandex.mobile.ads.rewarded;

import com.yandex.mobile.ads.impl.if;

final class a$7 implements Runnable {
   // $FF: synthetic field
   final a a;

   a$7(a var1) {
      this.a = var1;
   }

   public final void run() {
      Object var1 = com.yandex.mobile.ads.rewarded.a.a(this.a);
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            if (com.yandex.mobile.ads.rewarded.a.b(this.a) != null) {
               if.a(com.yandex.mobile.ads.rewarded.a.b(this.a), "onAdImpressionTracked", new Object[0]);
            }
         } catch (Throwable var16) {
            var10000 = var16;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            return;
         } catch (Throwable var15) {
            var10000 = var15;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var2 = var10000;

         try {
            throw var2;
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            continue;
         }
      }
   }
}
