package com.yandex.mobile.ads.video.models.ad;

import androidx.annotation.NonNull;

public class SkipOffset {
   @NonNull
   private final String mValue;

   private SkipOffset(@NonNull String var1) {
      this.mValue = var1;
   }

   @NonNull
   public String getRawValue() {
      return this.mValue;
   }
}
