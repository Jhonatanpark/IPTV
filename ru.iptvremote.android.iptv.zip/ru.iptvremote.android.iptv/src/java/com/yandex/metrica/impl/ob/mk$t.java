package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$t extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("CREATE TABLE IF NOT EXISTS preferences (key TEXT PRIMARY KEY,value TEXT,type INTEGER)");
      var1.execSQL("ALTER TABLE reports ADD COLUMN custom_type INTEGER DEFAULT 0");
   }
}
