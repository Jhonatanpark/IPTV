package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;
import androidx.annotation.NonNull;
import java.util.Locale;

public class mk$y extends mj {
   public void a(@NonNull SQLiteDatabase var1) {
      Locale var2 = Locale.US;
      Object[] var3 = new Object[]{"reports", "first_occurrence_status", ap.a.d};
      var1.execSQL(String.format(var2, "ALTER TABLE %s ADD COLUMN %s INTEGER DEFAULT %d", var3));
      var1.execSQL("CREATE TABLE IF NOT EXISTS binary_data (data_key TEXT PRIMARY KEY,value BLOB)");
   }
}
