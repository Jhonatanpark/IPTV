package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$w extends mj {
   public void a(SQLiteDatabase var1) {
      StringBuilder var2 = new StringBuilder();
      var2.append("ALTER TABLE ");
      var2.append("sessions");
      var2.append(" ADD COLUMN ");
      var2.append("obtained_before_first_sync");
      var2.append(" INTEGER DEFAULT 0");
      var1.execSQL(var2.toString());
   }
}
