package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;
import com.yandex.metrica.impl.ob.mi.a.b;

public class mk$f extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("DROP TABLE IF EXISTS device_id_info");
      var1.execSQL("DROP TABLE IF EXISTS api_level_info");
      var1.execSQL("DROP TABLE IF EXISTS preferences");
      var1.execSQL("DROP TABLE IF EXISTS startup");
      var1.execSQL(b.b);
      var1.execSQL(com.yandex.metrica.impl.ob.mi.a.a.b);
      var1.execSQL("DROP TABLE IF EXISTS permissions");
   }
}
