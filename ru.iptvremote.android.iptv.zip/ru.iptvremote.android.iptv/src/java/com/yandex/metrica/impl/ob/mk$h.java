package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$h extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("DROP TABLE IF EXISTS api_level_info");
      var1.execSQL("DROP TABLE IF EXISTS device_id_info");
   }
}
