package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$r extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("ALTER TABLE reports ADD COLUMN truncated INTEGER DEFAULT 0");
   }
}
