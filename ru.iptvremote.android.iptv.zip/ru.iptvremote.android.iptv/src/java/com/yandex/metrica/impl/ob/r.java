package com.yandex.metrica.impl.ob;

import androidx.annotation.Nullable;
import java.util.concurrent.TimeUnit;

public interface r {
   public static class a {
      public static final long a;
      private long b;
      private long c;
      @Nullable
      private Object d;

      static {
         a = TimeUnit.SECONDS.toMillis(10L);
      }

      public a() {
         this(a);
      }

      public a(long var1) {
         this.c = 0L;
         this.d = null;
         this.b = var1;
      }

      private void d() {
         this.c = System.currentTimeMillis();
      }

      @Nullable
      public Object a() {
         return this.d;
      }

      public void a(Object var1) {
         this.d = var1;
         this.d();
      }

      public final boolean a(long var1) {
         long var3 = System.currentTimeMillis() - this.c;
         return var3 > var1 || var3 < 0L;
      }

      public final boolean b() {
         return this.d == null;
      }

      public final boolean c() {
         return this.a(this.b);
      }
   }
}
