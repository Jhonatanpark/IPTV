package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;
import com.yandex.metrica.impl.ob.mi.a.b;

public class mk$e extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("CREATE TABLE IF NOT EXISTS preferences (key TEXT PRIMARY KEY,value TEXT,type INTEGER)");
      var1.execSQL("CREATE TABLE IF NOT EXISTS startup (key TEXT PRIMARY KEY,value TEXT,type INTEGER)");
      var1.execSQL(b.a);
      var1.execSQL(com.yandex.metrica.impl.ob.mi.a.a.a);
      var1.execSQL("CREATE TABLE IF NOT EXISTS binary_data (data_key TEXT PRIMARY KEY,value BLOB)");
   }
}
