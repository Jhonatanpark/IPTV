package com.yandex.metrica.impl.ob;

import androidx.annotation.Nullable;

public class abb extends abe {
   private static final abb a = new abb();

   private abb() {
      this("");
   }

   public abb(@Nullable String var1) {
      super(var1);
   }

   public static abb h() {
      return a;
   }

   protected boolean d() {
      super.d();
      return false;
   }

   public String f() {
      return "AppMetricaInternal";
   }
}
