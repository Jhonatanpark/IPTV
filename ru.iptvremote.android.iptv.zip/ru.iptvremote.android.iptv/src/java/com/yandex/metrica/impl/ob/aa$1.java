package com.yandex.metrica.impl.ob;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;

final class aa$1 implements Creator {
   public aa a(Parcel var1) {
      Bundle var2 = var1.readBundle(ab.class.getClassLoader());
      aa var3 = aa.a((new aa()).a(var2.getInt("CounterReport.Type", com.yandex.metrica.impl.ob.al.a.a.a())).b(var2.getInt("CounterReport.CustomType")).c(dh.b(var2.getString("CounterReport.Value"), "")).a(var2.getString("CounterReport.UserInfo")).e(var2.getString("CounterReport.Environment")).b(var2.getString("CounterReport.Event")), aa.c(var2)).c(var2.getInt("CounterReport.TRUNCATED")).d(var2.getString("CounterReport.ProfileID")).a(var2.getLong("CounterReport.CreationElapsedRealtime")).b(var2.getLong("CounterReport.CreationTimestamp")).a(ap.a(var2.getInt("CounterReport.UniquenessStatus")));
      ba var4 = (ba)var2.getParcelable("CounterReport.IdentifiersData");
      if (var4 != null) {
         var3.a(var4);
      }

      return var3;
   }

   public aa[] a(int var1) {
      return new aa[var1];
   }

   // $FF: synthetic method
   public Object createFromParcel(Parcel var1) {
      return this.a(var1);
   }

   // $FF: synthetic method
   public Object[] newArray(int var1) {
      return this.a(var1);
   }
}
