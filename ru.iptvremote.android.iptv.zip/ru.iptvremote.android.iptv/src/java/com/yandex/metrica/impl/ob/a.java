package com.yandex.metrica.impl.ob;

public final class a {
   private final byte[] a;
   private int b;
   private int c;
   private int d;
   private int e;
   private int f;
   private int g = Integer.MAX_VALUE;
   private int h;
   private int i = 64;
   private int j = 67108864;

   private a(byte[] var1, int var2, int var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3 + var2;
      this.e = var2;
   }

   public static long a(long var0) {
      return var0 >>> 1 ^ -(var0 & 1L);
   }

   public static a a(byte[] var0, int var1, int var2) {
      return new a(var0, var1, var2);
   }

   public static int c(int var0) {
      return var0 >>> 1 ^ -(var0 & 1);
   }

   private void v() {
      int var1 = this.c + this.d;
      this.c = var1;
      int var2 = this.g;
      if (var1 > var2) {
         int var3 = var1 - var2;
         this.d = var3;
         this.c = var1 - var3;
      } else {
         this.d = 0;
      }
   }

   public int a() {
      if (this.s()) {
         this.f = 0;
         return 0;
      } else {
         int var1 = this.n();
         this.f = var1;
         if (var1 != 0) {
            return var1;
         } else {
            throw com.yandex.metrica.impl.ob.d.d();
         }
      }
   }

   public void a(int var1) {
      if (this.f != var1) {
         throw com.yandex.metrica.impl.ob.d.e();
      }
   }

   public void a(e var1) {
      int var2 = this.n();
      if (this.h < this.i) {
         int var3 = this.d(var2);
         ++this.h;
         var1.a(this);
         this.a(0);
         this.h += -1;
         this.e(var3);
      } else {
         throw com.yandex.metrica.impl.ob.d.g();
      }
   }

   public void b() {
      int var1;
      do {
         var1 = this.a();
      } while(var1 != 0 && this.b(var1));

   }

   public boolean b(int var1) {
      int var2 = com.yandex.metrica.impl.ob.g.a(var1);
      if (var2 != 0) {
         if (var2 != 1) {
            if (var2 != 2) {
               if (var2 != 3) {
                  if (var2 != 4) {
                     if (var2 == 5) {
                        this.p();
                        return true;
                     } else {
                        throw com.yandex.metrica.impl.ob.d.f();
                     }
                  } else {
                     return false;
                  }
               } else {
                  this.b();
                  this.a(com.yandex.metrica.impl.ob.g.a(com.yandex.metrica.impl.ob.g.b(var1), 4));
                  return true;
               }
            } else {
               this.h(this.n());
               return true;
            }
         } else {
            this.q();
            return true;
         }
      } else {
         this.g();
         return true;
      }
   }

   public double c() {
      return Double.longBitsToDouble(this.q());
   }

   public float d() {
      return Float.intBitsToFloat(this.p());
   }

   public int d(int var1) {
      if (var1 >= 0) {
         int var2 = var1 + this.e;
         int var3 = this.g;
         if (var2 <= var3) {
            this.g = var2;
            this.v();
            return var3;
         } else {
            throw com.yandex.metrica.impl.ob.d.a();
         }
      } else {
         throw com.yandex.metrica.impl.ob.d.b();
      }
   }

   public long e() {
      return this.o();
   }

   public void e(int var1) {
      this.g = var1;
      this.v();
   }

   public long f() {
      return this.o();
   }

   public void f(int var1) {
      int var2 = this.e;
      int var3 = this.b;
      if (var1 <= var2 - var3) {
         if (var1 >= 0) {
            this.e = var3 + var1;
         } else {
            throw new IllegalArgumentException(b.a.a.a.a.c("Bad position ", var1));
         }
      } else {
         StringBuilder var4 = new StringBuilder();
         var4.append("Position ");
         var4.append(var1);
         var4.append(" is beyond current ");
         var4.append(this.e - this.b);
         throw new IllegalArgumentException(var4.toString());
      }
   }

   public int g() {
      return this.n();
   }

   public byte[] g(int var1) {
      if (var1 >= 0) {
         int var2 = this.e;
         int var3 = var2 + var1;
         int var4 = this.g;
         if (var3 <= var4) {
            if (var1 <= this.c - var2) {
               byte[] var5 = new byte[var1];
               System.arraycopy(this.a, var2, var5, 0, var1);
               this.e += var1;
               return var5;
            } else {
               throw com.yandex.metrica.impl.ob.d.a();
            }
         } else {
            this.h(var4 - var2);
            throw com.yandex.metrica.impl.ob.d.a();
         }
      } else {
         throw com.yandex.metrica.impl.ob.d.b();
      }
   }

   public void h(int var1) {
      if (var1 >= 0) {
         int var2 = this.e;
         int var3 = var2 + var1;
         int var4 = this.g;
         if (var3 <= var4) {
            if (var1 <= this.c - var2) {
               this.e = var2 + var1;
            } else {
               throw com.yandex.metrica.impl.ob.d.a();
            }
         } else {
            this.h(var4 - var2);
            throw com.yandex.metrica.impl.ob.d.a();
         }
      } else {
         throw com.yandex.metrica.impl.ob.d.b();
      }
   }

   public boolean h() {
      return this.n() != 0;
   }

   public String i() {
      int var1 = this.n();
      if (var1 <= this.c - this.e && var1 > 0) {
         String var2 = new String(this.a, this.e, var1, "UTF-8");
         this.e += var1;
         return var2;
      } else {
         return new String(this.g(var1), "UTF-8");
      }
   }

   public byte[] j() {
      int var1 = this.n();
      int var2 = this.c;
      int var3 = this.e;
      if (var1 <= var2 - var3 && var1 > 0) {
         byte[] var4 = new byte[var1];
         System.arraycopy(this.a, var3, var4, 0, var1);
         this.e += var1;
         return var4;
      } else {
         return this.g(var1);
      }
   }

   public int k() {
      return this.n();
   }

   public int l() {
      return c(this.n());
   }

   public long m() {
      return a(this.o());
   }

   public int n() {
      byte var1 = this.u();
      if (var1 >= 0) {
         return var1;
      } else {
         int var2 = var1 & 127;
         byte var3 = this.u();
         int var10;
         if (var3 >= 0) {
            var10 = var3 << 7;
         } else {
            var2 |= (var3 & 127) << 7;
            byte var4 = this.u();
            if (var4 >= 0) {
               var10 = var4 << 14;
            } else {
               var2 |= (var4 & 127) << 14;
               byte var5 = this.u();
               if (var5 < 0) {
                  int var6 = var2 | (var5 & 127) << 21;
                  byte var7 = this.u();
                  int var8 = var6 | var7 << 28;
                  if (var7 < 0) {
                     for(int var9 = 0; var9 < 5; ++var9) {
                        if (this.u() >= 0) {
                           return var8;
                        }
                     }

                     throw com.yandex.metrica.impl.ob.d.c();
                  }

                  return var8;
               }

               var10 = var5 << 21;
            }
         }

         return var2 | var10;
      }
   }

   public long o() {
      int var1 = 0;

      for(long var2 = 0L; var1 < 64; var1 += 7) {
         byte var5 = this.u();
         var2 |= (long)(var5 & 127) << var1;
         if ((var5 & 128) == 0) {
            return var2;
         }
      }

      d var4 = com.yandex.metrica.impl.ob.d.c();
      throw var4;
   }

   public int p() {
      byte var1 = this.u();
      byte var2 = this.u();
      byte var3 = this.u();
      byte var4 = this.u();
      return var1 & 255 | (var2 & 255) << 8 | (var3 & 255) << 16 | (var4 & 255) << 24;
   }

   public long q() {
      byte var1 = this.u();
      byte var2 = this.u();
      byte var3 = this.u();
      byte var4 = this.u();
      byte var5 = this.u();
      byte var6 = this.u();
      byte var7 = this.u();
      byte var8 = this.u();
      return 255L & (long)var1 | (255L & (long)var2) << 8 | (255L & (long)var3) << 16 | (255L & (long)var4) << 24 | (255L & (long)var5) << 32 | (255L & (long)var6) << 40 | (255L & (long)var7) << 48 | (255L & (long)var8) << 56;
   }

   public int r() {
      int var1 = this.g;
      return var1 == Integer.MAX_VALUE ? -1 : var1 - this.e;
   }

   public boolean s() {
      return this.e == this.c;
   }

   public int t() {
      return this.e - this.b;
   }

   public byte u() {
      int var1 = this.e;
      if (var1 != this.c) {
         byte[] var2 = this.a;
         this.e = var1 + 1;
         return var2[var1];
      } else {
         throw com.yandex.metrica.impl.ob.d.a();
      }
   }
}
