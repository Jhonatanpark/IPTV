package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$j extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("DROP TABLE IF EXISTS GeoLocationInfo");
   }
}
