package com.yandex.metrica.impl.ob;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

public class mk$q extends mj {
   private static final String a;

   static {
      StringBuilder var0 = b.a.a.a.a.j("CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY,name TEXT,value TEXT,number INTEGER,type INTEGER,time INTEGER,session_id TEXT,wifi_network_info TEXT DEFAULT '',cell_info TEXT DEFAULT '',location_info TEXT DEFAULT '',error_environment TEXT,user_info TEXT,session_type INTEGER DEFAULT ");
      var0.append(jy.a.a());
      var0.append(",");
      var0.append("app_environment");
      var0.append(" TEXT DEFAULT '");
      b.a.a.a.a.p(var0, "{}", "',", "app_environment_revision", " INTEGER DEFAULT ");
      var0.append(0L);
      var0.append(" )");
      a = var0.toString();
   }

   public void a(SQLiteDatabase var1) {
      var1.execSQL("ALTER TABLE reports ADD COLUMN app_environment TEXT DEFAULT '{}'");
      StringBuilder var2 = new StringBuilder();
      var2.append("ALTER TABLE ");
      var2.append("reports");
      var2.append(" ADD COLUMN ");
      var2.append("app_environment_revision");
      var2.append(" INTEGER DEFAULT 0");
      var1.execSQL(var2.toString());
      var1.execSQL("ALTER TABLE reports RENAME TO reports_backup");
      var1.execSQL(a);
      Object var8 = null;
      boolean var17 = false;

      Cursor var10;
      try {
         var17 = true;
         var10 = var1.rawQuery("SELECT * FROM reports_backup", (String[])null);
         var17 = false;
      } finally {
         if (var17) {
            dl.a((Cursor)var8);
         }
      }

      while(true) {
         try {
            if (!var10.moveToNext()) {
               break;
            }

            ContentValues var11 = new ContentValues();
            DatabaseUtils.cursorRowToContentValues(var10, var11);
            String var12 = var11.getAsString("environment");
            var11.remove("environment");
            var11.put("error_environment", var12);
            var1.insert("reports", (String)null, var11);
         } finally {
            ;
         }
      }

      dl.a(var10);
      var1.execSQL("DROP TABLE reports_backup");
   }
}
