package com.yandex.metrica.impl.ob;

public class mm extends mp {
   private final th a = new th("init_event_pref_key");
   private final th b = new th("first_event_pref_key");
   private final th c = new th("first_event_description_key");
   private final th d = new th("preload_info_auto_tracking_enabled");

   public mm(lx var1) {
      super(var1);
   }

   private void a(th var1) {
      this.r(var1.b()).q();
   }

   public String a(String var1) {
      return this.c(this.a.b(), var1);
   }

   public void a() {
      this.b(this.a.b(), "DONE").q();
   }

   public void a(boolean var1) {
      this.a(this.d.b(), var1).q();
   }

   public String b(String var1) {
      return this.c(this.b.b(), var1);
   }

   public void b() {
      this.b(this.b.b(), "DONE").q();
   }

   public boolean b(boolean var1) {
      return this.b(this.d.b(), var1);
   }

   public void c(String var1) {
      this.b(this.c.b(), var1).q();
   }

   public boolean c() {
      return this.a((String)null) != null;
   }

   public String d(String var1) {
      return this.c(this.c.b(), var1);
   }

   public boolean d() {
      return this.b((String)null) != null;
   }

   public void e() {
      this.a(this.c);
   }
}
