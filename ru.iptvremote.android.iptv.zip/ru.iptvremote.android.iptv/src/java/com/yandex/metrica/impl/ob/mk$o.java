package com.yandex.metrica.impl.ob;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import com.yandex.metrica.impl.ob.mi.g;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import org.json.JSONObject;

public class mk$o extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("CREATE TABLE IF NOT EXISTS sessions_BACKUP (id INTEGER,start_time INTEGER,connection_type INTEGER,network_type TEXT,country_code INTEGER,operator_id INTEGER,lac INTEGER,report_request_parameters TEXT );");
      StringBuilder var2 = new StringBuilder();
      String var3 = "id";
      var2.append(var3);
      var2.append(",");
      var2.append("start_time");
      b.a.a.a.a.p(var2, ",", "connection_type", ",", "network_type");
      b.a.a.a.a.p(var2, ",", "country_code", ",", "operator_id");
      var2.append(",");
      var2.append("lac");
      var2.append(",");
      var2.append("report_request_parameters");
      StringBuilder var11 = new StringBuilder();
      var11.append("INSERT INTO ");
      var11.append("sessions_BACKUP");
      var11.append(" SELECT ");
      var11.append(var2);
      var11.append(" FROM ");
      var11.append("sessions");
      var11.append(";");
      var1.execSQL(var11.toString());
      var1.execSQL("DROP TABLE sessions;");
      var1.execSQL(g.b);
      Cursor var19 = null;

      label566: {
         Throwable var10000;
         label565: {
            boolean var10001;
            try {
               var19 = var1.rawQuery("SELECT * FROM sessions_BACKUP", (String[])null);
            } catch (Throwable var95) {
               var10000 = var95;
               var10001 = false;
               break label565;
            }

            label562:
            while(true) {
               ContentValues var21;
               ArrayList var22;
               ContentValues var26;
               Iterator var27;
               try {
                  if (!var19.moveToNext()) {
                     break label566;
                  }

                  var21 = new ContentValues();
                  DatabaseUtils.cursorRowToContentValues(var19, var21);
                  var22 = new ArrayList();
                  var22.add(var3);
                  var22.add("start_time");
                  var22.add("report_request_parameters");
                  var26 = new ContentValues(var21);
                  var27 = var21.valueSet().iterator();
               } catch (Throwable var91) {
                  var10000 = var91;
                  var10001 = false;
                  break;
               }

               while(true) {
                  Entry var38;
                  try {
                     if (!var27.hasNext()) {
                        break;
                     }

                     var38 = (Entry)var27.next();
                  } catch (Throwable var93) {
                     var10000 = var93;
                     var10001 = false;
                     break label562;
                  }

                  try {
                     if (!var22.contains(var38.getKey())) {
                        var26.remove((String)var38.getKey());
                     }
                  } catch (Throwable var94) {
                     var10000 = var94;
                     var10001 = false;
                     break label562;
                  }

                  var3 = var3;
               }

               Iterator var29;
               try {
                  var29 = var22.iterator();
               } catch (Throwable var90) {
                  var10000 = var90;
                  var10001 = false;
                  break;
               }

               while(true) {
                  try {
                     if (!var29.hasNext()) {
                        break;
                     }

                     var21.remove((String)var29.next());
                  } catch (Throwable var92) {
                     var10000 = var92;
                     var10001 = false;
                     break label562;
                  }
               }

               try {
                  JSONObject var30 = new JSONObject();
                  var30.put("conn_type", var21.getAsInteger("connection_type"));
                  var30.putOpt("net_type", var21.get("network_type"));
                  var30.putOpt("operator_id", var21.get("operator_id"));
                  var30.putOpt("lac", var21.get("lac"));
                  var30.putOpt("country_code", var21.get("country_code"));
                  var26.put("network_info", var30.toString());
                  var1.insertOrThrow("sessions", (String)null, var26);
               } catch (Throwable var89) {
                  var10000 = var89;
                  var10001 = false;
                  break;
               }

               var3 = var3;
            }
         }

         Throwable var20 = var10000;
         dl.a(var19);
         throw var20;
      }

      dl.a(var19);
      var1.execSQL("DROP TABLE sessions_BACKUP;");
      var1.execSQL("ALTER TABLE reports ADD COLUMN wifi_network_info TEXT DEFAULT ''");
      var1.execSQL("ALTER TABLE reports ADD COLUMN cell_info TEXT DEFAULT ''");
      var1.execSQL("ALTER TABLE reports ADD COLUMN location_info TEXT DEFAULT ''");
   }
}
