package com.yandex.metrica.impl.ob;

public interface ra {
   void a();
}
