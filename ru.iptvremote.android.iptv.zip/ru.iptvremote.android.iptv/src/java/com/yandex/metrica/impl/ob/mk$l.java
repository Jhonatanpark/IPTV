package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;
import com.yandex.metrica.impl.ob.mi.a.b;

public class mk$l extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL(b.a);
   }
}
