package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;
import com.yandex.metrica.impl.ob.mi.f;
import com.yandex.metrica.impl.ob.mi.g;

public class mk$c extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL(f.b);
      var1.execSQL(g.b);
      var1.execSQL("CREATE TABLE IF NOT EXISTS preferences (key TEXT PRIMARY KEY,value TEXT,type INTEGER)");
      var1.execSQL("CREATE TABLE IF NOT EXISTS binary_data (data_key TEXT PRIMARY KEY,value BLOB)");
   }
}
