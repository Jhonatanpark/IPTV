package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$d extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("DROP TABLE IF EXISTS reports");
      var1.execSQL("DROP TABLE IF EXISTS sessions");
      var1.execSQL("DROP TABLE IF EXISTS preferences");
   }
}
