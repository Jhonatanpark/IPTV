package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;
import com.yandex.metrica.impl.ob.mi.e;

public class mk$g extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("CREATE TABLE IF NOT EXISTS api_level_info (API_LEVEL INT )");
      var1.insert("api_level_info", "API_LEVEL", e.a());
   }
}
