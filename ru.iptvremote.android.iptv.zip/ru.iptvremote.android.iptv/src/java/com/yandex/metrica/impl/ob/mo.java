package com.yandex.metrica.impl.ob;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.Collections;
import java.util.List;

public class mo extends mp {
   public static final String a;
   @Deprecated
   public static final th b = new th("COLLECT_INSTALLED_APPS");
   static final th c = new th("DEPRECATED_NATIVE_CRASHES_CHECKED");
   private static final th d = new th("IDENTITY_SEND_TIME");
   private static final th e = new th("PERMISSIONS_CHECK_TIME");
   private static final th f = new th("USER_INFO");
   private static final th g = new th("PROFILE_ID");
   private static final th h = new th("APP_ENVIRONMENT");
   private static final th i = new th("APP_ENVIRONMENT_REVISION");
   private static final th j = new th("LAST_MIGRATION_VERSION");
   private static final th k = new th("LAST_APP_VERSION_WITH_FEATURES");
   private static final th l = new th("APPLICATION_FEATURES");
   private static final th m = new th("CURRENT_SESSION_ID");
   private static final th n = new th("ATTRIBUTION_ID");
   private static final th o = new th("LAST_STAT_SENDING_DISABLED_REPORTING_TIMESTAMP");
   private static final th p = new th("NEXT_EVENT_GLOBAL_NUMBER");
   private static final th q = new th("LAST_REQUEST_ID");
   private static final th r = new th("CERTIFICATES_SHA1_FINGERPRINTS");
   private static final ml s = new ml();

   public mo(lx var1) {
      super(var1);
   }

   public int a() {
      return this.b(p.b(), 0);
   }

   public int a(int var1) {
      return this.b(s.a(var1), 0);
   }

   public long a(long var1) {
      return this.b(d.b(), var1);
   }

   public mo a(int var1, int var2) {
      return (mo)this.a(s.a(var1), var2);
   }

   public mo a(com.yandex.metrica.impl.ob.i.a param1) {
      // $FF: Couldn't be decompiled
   }

   public mo a(String var1) {
      return (mo)this.b(f.b(), var1);
   }

   public mo a(String var1, String var2) {
      return (mo)this.b((new th("SESSION_", var1)).b(), var2);
   }

   public mo a(List var1) {
      return (mo)this.a(r.b(), var1);
   }

   public long b() {
      return this.b(e.b(), 0L);
   }

   public mo b(int var1) {
      return (mo)this.a(p.b(), var1);
   }

   public mo b(long var1) {
      return (mo)this.a(d.b(), var1);
   }

   public mo b(String var1) {
      return (mo)this.b(l.b(), var1);
   }

   public int c() {
      return this.b(k.b(), -1);
   }

   public mo c(int var1) {
      return (mo)this.a(k.b(), var1);
   }

   public mo c(long var1) {
      return (mo)this.a(e.b(), var1);
   }

   public String c(String var1) {
      return this.c((new th("SESSION_", var1)).b(), "");
   }

   public com.yandex.metrica.impl.ob.i.a d() {
      // $FF: Couldn't be decompiled
   }

   @NonNull
   public mo d(int var1) {
      return (mo)this.a(n.b(), var1);
   }

   public mo d(long var1) {
      return (mo)this.a(j.b(), var1);
   }

   public mo d(@Nullable String var1) {
      return (mo)this.b(g.b(), var1);
   }

   public mo e(int var1) {
      return (mo)this.a(q.b(), var1);
   }

   @NonNull
   public mo e(long var1) {
      return (mo)this.a(m.b(), var1);
   }

   public String e() {
      return this.c(l.b(), "");
   }

   public mo f(long var1) {
      return (mo)this.a(o.b(), var1);
   }

   public String f() {
      return this.c(f.b(), a);
   }

   public long g() {
      return this.b(j.b(), 0L);
   }

   @Nullable
   public String h() {
      return this.s(g.b());
   }

   public int i() {
      return this.b(n.b(), 1);
   }

   public long j() {
      return this.b(m.b(), -1L);
   }

   public long k() {
      return this.b(o.b(), 0L);
   }

   public int l() {
      return this.b(q.b(), -1);
   }

   public boolean m() {
      return this.b(c.b(), false);
   }

   public mo n() {
      return (mo)this.a(c.b(), true);
   }

   @NonNull
   public List o() {
      return this.b(r.b(), Collections.emptyList());
   }
}
