package com.yandex.metrica.impl.ob;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.LinkedList;
import java.util.List;

public class mn extends mp {
   static final th a = new th("UUID");
   static final th b = new th("DEVICE_ID_POSSIBLE");
   static final th c = new th("DEVICE_ID");
   static final th d = new th("DEVICE_ID_HASH");
   static final th e = new th("AD_URL_GET");
   static final th f = new th("AD_URL_REPORT");
   static final th g = new th("CUSTOM_HOSTS");
   static final th h = new th("SERVER_TIME_OFFSET");
   static final th i = new th("STARTUP_REQUEST_TIME");
   static final th j = new th("CLIDS");
   static final th k = new th("CLIENT_CLIDS");
   static final th l = new th("REFERRER");
   static final th m = new th("DEFERRED_DEEP_LINK_WAS_CHECKED");
   static final th n = new th("REFERRER_FROM_PLAY_SERVICES_WAS_CHECKED");
   static final th o = new th("DEPRECATED_NATIVE_CRASHES_CHECKED");
   static final th p = new th("API_LEVEL");
   static final th q = new th("ADS_REQUESTED_CONTEXT");
   static final th r = new th("CONTEXT_HISTORY");
   static final th s = new th("ACCESS_CONFIG");
   static final th t = new th("LAST_UI_CONTEXT_ID");

   public mn(lx var1) {
      super(var1);
   }

   public long a(long var1) {
      return this.b(h.a(), var1);
   }

   public mn a(@Nullable aag param1) {
      // $FF: Couldn't be decompiled
   }

   public mn a(List var1) {
      String var2 = abc.a(var1);
      return (mn)this.b(g.b(), var2);
   }

   public String a() {
      return this.c(b.b(), "");
   }

   public String a(String var1) {
      return this.c(a.b(), var1);
   }

   public boolean a(boolean var1) {
      return this.b(q.b(), var1);
   }

   public long b(long var1) {
      return this.b(i.b(), var1);
   }

   public mn b(@NonNull List var1) {
      return (mn)this.a(r.b(), var1);
   }

   public mn b(boolean var1) {
      return (mn)this.a(q.b(), var1);
   }

   public String b(String var1) {
      return this.c(c.b(), var1);
   }

   public List b() {
      String var1 = this.c(g.b(), (String)null);
      return TextUtils.isEmpty(var1) ? null : abc.c(var1);
   }

   public long c(long var1) {
      return this.b(p.b(), var1);
   }

   public String c() {
      return this.c(l.b(), (String)null);
   }

   public String c(String var1) {
      return this.c(d.b(), var1);
   }

   public mn d(long var1) {
      return (mn)this.a(h.b(), var1);
   }

   public String d(String var1) {
      return this.c(e.b(), var1);
   }

   public boolean d() {
      return this.b(m.b(), false);
   }

   public mn e(long var1) {
      return (mn)this.a(i.b(), var1);
   }

   public String e(String var1) {
      return this.c(f.b(), var1);
   }

   public boolean e() {
      return this.b(n.b(), false);
   }

   public mn f() {
      return (mn)this.a(m.b(), true);
   }

   public mn f(long var1) {
      return (mn)this.a(p.b(), var1);
   }

   public String f(String var1) {
      return this.c(j.b(), var1);
   }

   public long g(long var1) {
      return this.b(t.b(), var1);
   }

   public mn g() {
      return (mn)this.a(n.b(), true);
   }

   public mn g(String var1) {
      return (mn)this.b(a.b(), var1);
   }

   public mn h(long var1) {
      return (mn)this.a(t.b(), var1);
   }

   public mn h(String var1) {
      return (mn)this.b(c.b(), var1);
   }

   @NonNull
   public List h() {
      LinkedList var1 = new LinkedList();
      List var2 = this.b(r.b(), var1);
      return (List)(var2 == null ? var1 : var2);
   }

   @Nullable
   public aag i() {
      // $FF: Couldn't be decompiled
   }

   public mn i(String var1) {
      return (mn)this.b(d.b(), var1);
   }

   public mn j(String var1) {
      return (mn)this.b(e.b(), var1);
   }

   public mn k(String var1) {
      return (mn)this.b(f.b(), var1);
   }

   public mn l(String var1) {
      return (mn)this.b(j.b(), var1);
   }

   public mn m(String var1) {
      return (mn)this.b(b.b(), var1);
   }

   public mn n(String var1) {
      return (mn)this.b(l.b(), var1);
   }

   public mn o(@Nullable String var1) {
      return (mn)this.b(k.b(), var1);
   }

   @Nullable
   public String p(@Nullable String var1) {
      return this.c(k.b(), var1);
   }
}
