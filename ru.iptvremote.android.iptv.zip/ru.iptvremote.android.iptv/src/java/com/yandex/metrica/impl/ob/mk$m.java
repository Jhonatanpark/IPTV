package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$m extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL(com.yandex.metrica.impl.ob.mi.a.a.a);
   }
}
