package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;
import java.util.Locale;

public class mk$x extends mj {
   public void a(SQLiteDatabase var1) {
      Locale var2 = Locale.US;
      Object[] var3 = new Object[]{"reports", "encrypting_mode", acl.a.a()};
      var1.execSQL(String.format(var2, "ALTER TABLE %s ADD COLUMN %s INTEGER DEFAULT %d", var3));
      Locale var4 = Locale.US;
      Object[] var5 = new Object[]{"reports", "encrypting_mode", acl.b.a(), "type", com.yandex.metrica.impl.ob.al.a.p.a()};
      var1.execSQL(String.format(var4, "UPDATE %s SET %s = %d where %s=%d", var5));
      var1.execSQL("ALTER TABLE reports ADD COLUMN profile_id TEXT ");
   }
}
