package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$p extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("ALTER TABLE reports ADD COLUMN environment TEXT ");
      var1.execSQL("ALTER TABLE reports ADD COLUMN user_info TEXT ");
      StringBuilder var2 = new StringBuilder();
      var2.append("ALTER TABLE ");
      var2.append("reports");
      var2.append(" ADD COLUMN ");
      var2.append("session_type");
      var2.append(" INTEGER DEFAULT ");
      var2.append(jy.a.a());
      var1.execSQL(var2.toString());
      StringBuilder var9 = new StringBuilder();
      var9.append("UPDATE ");
      var9.append("reports");
      var9.append(" SET ");
      var9.append("session_type");
      var9.append(" = ");
      var9.append(jy.b.a());
      var9.append(" WHERE ");
      var9.append("session_id");
      var9.append(" = ");
      var9.append(-2L);
      var1.execSQL(var9.toString());
      var1.execSQL("ALTER TABLE sessions ADD COLUMN server_time_offset INTEGER ");
      StringBuilder var20 = new StringBuilder();
      var20.append("ALTER TABLE ");
      var20.append("sessions");
      var20.append(" ADD COLUMN ");
      var20.append("type");
      var20.append(" INTEGER DEFAULT ");
      var20.append(jy.a.a());
      var1.execSQL(var20.toString());
      StringBuilder var27 = new StringBuilder();
      var27.append("UPDATE ");
      var27.append("sessions");
      var27.append(" SET ");
      var27.append("type");
      var27.append(" = ");
      var27.append(jy.b.a());
      var27.append(" WHERE ");
      var27.append("id");
      var27.append(" = ");
      var27.append(-2L);
      var1.execSQL(var27.toString());
   }
}
