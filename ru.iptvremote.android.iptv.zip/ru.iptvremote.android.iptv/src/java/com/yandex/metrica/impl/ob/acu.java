package com.yandex.metrica.impl.ob;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;

public interface acu extends act {
   @NonNull
   Handler a();

   @NonNull
   Looper b();
}
