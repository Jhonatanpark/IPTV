package com.yandex.metrica.impl.ob;

import androidx.annotation.NonNull;

public class aac implements zq {
   private final int a;

   public aac(int var1) {
      this.a = var1;
   }

   public void a(@NonNull aad var1) {
      if (var1.a.length() > this.a) {
         int var2 = var1.a.length();
         int var3 = this.a;
         int var4 = var2 - var3;
         String var5 = var1.a.substring(0, var3);
         var1.a = var5;
         var1.c = var4 + var5.length();
      }

   }
}
