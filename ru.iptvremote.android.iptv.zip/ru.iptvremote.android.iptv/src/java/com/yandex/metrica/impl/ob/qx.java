package com.yandex.metrica.impl.ob;

import android.content.Context;
import android.location.LocationListener;
import android.os.Looper;
import androidx.annotation.NonNull;
import java.util.concurrent.TimeUnit;

public abstract class qx {
   static final long a;
   @NonNull
   protected final Context b;
   @NonNull
   protected final sp c;
   @NonNull
   protected final LocationListener d;
   @NonNull
   protected final Looper e;

   static {
      a = TimeUnit.SECONDS.toMillis(1L);
   }

   public qx(@NonNull Context var1, @NonNull LocationListener var2, @NonNull sp var3, @NonNull Looper var4) {
      this.b = var1;
      this.d = var2;
      this.c = var3;
      this.e = var4;
   }

   public abstract boolean a();

   public abstract void b();

   public abstract void c();
}
