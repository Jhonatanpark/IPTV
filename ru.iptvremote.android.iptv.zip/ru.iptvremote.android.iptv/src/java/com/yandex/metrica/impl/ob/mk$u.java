package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$u extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("CREATE TABLE IF NOT EXISTS preferences (key TEXT PRIMARY KEY,value TEXT,type INTEGER)");
      var1.execSQL("ALTER TABLE reports ADD COLUMN wifi_access_point TEXT ");
   }
}
