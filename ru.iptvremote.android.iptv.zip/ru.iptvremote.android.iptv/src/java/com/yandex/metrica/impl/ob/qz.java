package com.yandex.metrica.impl.ob;

public interface qz {
   void a();
}
