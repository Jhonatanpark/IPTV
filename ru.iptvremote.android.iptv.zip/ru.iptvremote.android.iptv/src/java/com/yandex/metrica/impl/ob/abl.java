package com.yandex.metrica.impl.ob;

import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.yandex.metrica.impl.ob.uu.c.e;

public class abl extends abe {
   private static final int[] a = new int[]{3, 6, 4};
   private static final abl b = new abl();

   public abl() {
      this("");
   }

   public abl(@Nullable String var1) {
      super(var1);
   }

   private boolean a(com.yandex.metrica.impl.ob.uu.c.e.a var1) {
      int[] var2 = a;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         int var5 = var2[var4];
         if (var1.d == var5) {
            return true;
         }
      }

      return false;
   }

   private String b(com.yandex.metrica.impl.ob.uu.c.e.a var1) {
      if (var1.d == 3 && TextUtils.isEmpty(var1.e)) {
         return "Native crash of app";
      } else if (var1.d == 4) {
         StringBuilder var2 = new StringBuilder(var1.e);
         if (var1.f != null) {
            String var3 = new String(var1.f);
            if (!TextUtils.isEmpty(var3)) {
               var2.append(" with value ");
               var2.append(var3);
            }
         }

         return var2.toString();
      } else {
         return var1.e;
      }
   }

   public static abl h() {
      return b;
   }

   public void a(aa var1, String var2) {
      if (al.b(var1.g())) {
         StringBuilder var3 = new StringBuilder(var2);
         var3.append(": ");
         var3.append(var1.d());
         if (al.c(var1.g()) && !TextUtils.isEmpty(var1.e())) {
            var3.append(" with value ");
            var3.append(var1.e());
         }

         this.a(var3.toString());
      }

   }

   public void a(com.yandex.metrica.impl.ob.uu.c.e.a var1, String var2) {
      if (this.a(var1)) {
         StringBuilder var3 = b.a.a.a.a.k(var2, ": ");
         var3.append(this.b(var1));
         this.a(var3.toString());
      }

   }

   public void a(e var1, String var2) {
      com.yandex.metrica.impl.ob.uu.c.e.a[] var3 = var1.d;
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         this.a(var3[var5], var2);
      }

   }

   public String f() {
      return "AppMetrica";
   }
}
