package com.yandex.metrica.impl.ob;

import android.widget.TextView;
import androidx.annotation.NonNull;
import com.yandex.metrica.impl.ob.aam.c;

public class aab implements aae {
   private final int a;

   public aab(int var1) {
      this.a = var1;
   }

   @NonNull
   public c a() {
      return c.a;
   }

   public boolean a(@NonNull TextView var1) {
      CharSequence var2 = var1.getText();
      return var2 != null && var2.length() > this.a;
   }
}
