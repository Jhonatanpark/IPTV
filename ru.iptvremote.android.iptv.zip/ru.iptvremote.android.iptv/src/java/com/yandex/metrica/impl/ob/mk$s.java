package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$s extends mj {
   public void a(SQLiteDatabase var1) {
      var1.execSQL("ALTER TABLE reports ADD COLUMN connection_type INTEGER DEFAULT 2");
      var1.execSQL("ALTER TABLE reports ADD COLUMN cellular_connection_type TEXT ");
   }
}
