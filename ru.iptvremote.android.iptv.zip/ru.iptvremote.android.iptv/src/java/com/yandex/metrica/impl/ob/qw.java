package com.yandex.metrica.impl.ob;

import android.location.LocationManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

public class qw {
   @NonNull
   public final po a;
   @NonNull
   public final yb b;
   @Nullable
   public final LocationManager c;
   @Nullable
   public final ql d;
   @NonNull
   public final rm e;
   @NonNull
   public final pn f;

   @VisibleForTesting
   qw(@NonNull po var1, @NonNull yb var2, @Nullable ql var3, @Nullable LocationManager var4, @NonNull rm var5, @NonNull pn var6) {
      this.a = var1;
      this.b = var2;
      this.d = var3;
      this.c = var4;
      this.e = var5;
      this.f = var6;
   }

   public static qw a(@NonNull rh var0, @NonNull rm var1, @NonNull pn var2, @Nullable LocationManager var3) {
      qw var4 = new qw(var0.a, var0.b, var0.c, var3, var1, var2);
      return var4;
   }
}
