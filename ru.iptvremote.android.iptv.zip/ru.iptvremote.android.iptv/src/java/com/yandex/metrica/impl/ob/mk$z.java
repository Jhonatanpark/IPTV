package com.yandex.metrica.impl.ob;

import android.database.sqlite.SQLiteDatabase;

public class mk$z extends mj {
   public void a(SQLiteDatabase var1) {
      StringBuilder var2 = new StringBuilder();
      var2.append("ALTER TABLE ");
      var2.append("sessions");
      var2.append(" ADD COLUMN ");
      var2.append("report_request_parameters");
      var2.append(" TEXT DEFAULT ''");
      var1.execSQL(var2.toString());
   }
}
