package com.yandex.metrica.impl.ob;

import androidx.annotation.NonNull;

public class qy {
   @NonNull
   private final qx a;
   @NonNull
   private final ph b;
   @NonNull
   private final ra c;
   @NonNull
   private final pm d;
   @NonNull
   private final Runnable e = new Runnable() {
      public void run() {
         qy.this.c();
      }
   };

   public qy(@NonNull qx var1, @NonNull ph var2, @NonNull ra var3, @NonNull pm var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   public void a() {
      this.c();
      this.b();
   }

   public void b() {
      if (this.b.a() && this.a.a()) {
         this.c.a();
         this.d.a(this.e);
      }

   }

   public void c() {
      this.d.a();
      this.a.b();
   }

   public void d() {
      if (this.b.b()) {
         this.a.c();
      }

      this.b();
   }
}
